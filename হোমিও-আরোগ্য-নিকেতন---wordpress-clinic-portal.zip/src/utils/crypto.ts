/**
 * Security & Master Authentication Service
 * Master security code verification and encryption utilities
 */

// Master security code required for login
const MASTER_SECURITY_HASH = 'QVlPTjU0MA=='; // Base64 for AYON540

export function verifyMasterSecurityCode(inputCode: string, customCode?: string): boolean {
  if (!inputCode) return false;
  const trimmed = inputCode.trim();
  if (customCode && customCode.trim() && trimmed === customCode.trim()) {
    return true;
  }
  try {
    const target = atob(MASTER_SECURITY_HASH);
    return trimmed === target;
  } catch {
    return false;
  }
}

// 2FA Verification (6-digit TOTP / backup code simulator)
export function generate2FACode(): string {
  // Deterministic 6-digit code based on 30-second window or stored PIN
  const step = Math.floor(Date.now() / 30000);
  const code = (Math.abs(Math.sin(step) * 1000000) % 900000 + 100000).toFixed(0);
  return code;
}

export function verify2FACode(inputOtp: string, expectedOtp?: string): boolean {
  if (!inputOtp) return false;
  const trimmed = inputOtp.trim();
  // Validates current TOTP or standard 6-digit backup code (e.g. 540540)
  if (trimmed === '540540') return true;
  if (expectedOtp && trimmed === expectedOtp) return true;
  const currentCode = generate2FACode();
  return trimmed === currentCode;
}

// Encrypt payload for local storage and JSON backups
export function encryptPayload(data: any): string {
  try {
    const jsonStr = JSON.stringify(data);
    const salt = 'HOMEO-CARE-SECURE-2026';
    let output = '';
    for (let i = 0; i < jsonStr.length; i++) {
      const charCode = jsonStr.charCodeAt(i) ^ salt.charCodeAt(i % salt.length);
      output += String.fromCharCode(charCode);
    }
    return btoa(unescape(encodeURIComponent(output)));
  } catch (e) {
    console.error('Encryption error:', e);
    return JSON.stringify(data);
  }
}

// Decrypt payload
export function decryptPayload<T = any>(encryptedStr: string): T | null {
  try {
    const decoded = decodeURIComponent(escape(atob(encryptedStr)));
    const salt = 'HOMEO-CARE-SECURE-2026';
    let output = '';
    for (let i = 0; i < decoded.length; i++) {
      const charCode = decoded.charCodeAt(i) ^ salt.charCodeAt(i % salt.length);
      output += String.fromCharCode(charCode);
    }
    return JSON.parse(output) as T;
  } catch (e) {
    try {
      // Fallback if not encrypted or plain JSON
      return JSON.parse(encryptedStr) as T;
    } catch {
      console.error('Decryption failed');
      return null;
    }
  }
}

// Simple checksum generator for database integrity
export function calculateChecksum(dataStr: string): string {
  let hash = 0;
  for (let i = 0; i < dataStr.length; i++) {
    const char = dataStr.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0; // Convert to 32bit integer
  }
  return 'CS-' + Math.abs(hash).toString(16).toUpperCase();
}
