import { Doctor, Appointment, Prescription, Patient, ChamberSettings, AuditLog, MateriaMedicaItem, AdminAccountProfile, PatientReview } from '../types.ts';

export const INITIAL_ADMIN_PROFILE: AdminAccountProfile = {
  name: 'ড. সুমন কুমার',
  username: 'admin',
  email: 'sumonkumar.nc052@gmail.com',
  phone: '০১৭৭৫-৯৮৪৫২০',
  designation: 'চিফ কনসালট্যান্ট ও ক্লাসিকাল হোমিওপ্যাথি গবেষক',
  qualifications: 'BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট), PGT (ভারত)',
  avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80',
  bio: '২৪ বছরেরও বেশি সময় ধরে ক্রনিক ও জটিল রোগের ক্লাসিকাল পদ্ধতিতে হোমিওপ্যাথি চিকিৎসা দিয়ে আসছেন। চেম্বার সুপার অ্যাডমিনিস্ট্রেটর।',
  masterSecurityCode: 'AYON540',
  twoFactorPin: '540540',
  role: 'সুপার অ্যাডমিন (Super Administrator)',
  lastLoginDate: 'আজ'
};

export const INITIAL_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'ড. সুমন কুমার',
    qualification: 'BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট), PGT (ক্লাসিকাল হোমিওপ্যাথি - ভারত)',
    designation: 'চিফ কনসালট্যান্ট ও ক্লাসিকাল হোমিওপ্যাথি গবেষক',
    specialties: ['জটিল ক্রনিক ব্যাধি', 'হাঁপানি ও এলার্জি', 'বাত ও মেরুদণ্ডের ব্যথা', 'পিত্ত ও কিডনি পাথর'],
    experienceYears: 24,
    consultationFee: 700,
    followupFee: 400,
    visitingDays: ['শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার'],
    visitingHours: 'বিকাল ৫:০০ - রাত ৯:৩০',
    phone: '০১৭৭৫-৯৮৪৫২০',
    email: 'dr.sumon.homeo@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80',
    bio: '২৪ বছরেরও বেশি সময় ধরে দীর্ঘমেয়াদী এবং জটিল রোগের ক্লাসিকাল পদ্ধতিতে হোমিওপ্যাথি চিকিৎসা দিয়ে আসছেন। সফলভাবে হাজারো রোগীকে অপারেশন ব্যতীত আরোগ্য লাভ করিয়েছেন।'
  },
  {
    id: 'doc-2',
    name: 'ড. তানজিলা আক্তার',
    qualification: 'BHMS (রাজশাহী বিশ্ববিদ্যালয়), ট্রেইন্ড ইন পেডিয়াট্রিক হোমিওপ্যাথি',
    designation: 'সহযোগী কনসালট্যান্ট - মা ও শিশু রোগ বিশেষজ্ঞ',
    specialties: ['শিশুদের ঘনঘন সর্দি-কাশি ও টনসিল', 'মহিলাদের হরমোনজনিত সমস্যা', 'মাইগ্রেন ও অনিদ্রা'],
    experienceYears: 12,
    consultationFee: 500,
    followupFee: 300,
    visitingDays: ['শনিবার', 'রবিবার', 'মঙ্গলবার', 'বুধবার'],
    visitingHours: 'সকাল ১০:০০ - দুপুর ১:০০',
    phone: '০১৮১৬-৩৩৪২৫১',
    email: 'dr.tanzila.homeo@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1594824813627-2c90c749a177?w=400&auto=format&fit=crop&q=80',
    bio: 'মা ও শিশুদের মৃদু এবং নিরাপদ প্রাকৃতিক হোমিওপ্যাথিক চিকিৎসায় বিশেষভাবে সমাদৃত। শিশুদের রোগ প্রতিরোধ ক্ষমতা বৃদ্ধিতে কার্যকর চিকিৎসা প্রদান করেন।'
  },
  {
    id: 'doc-3',
    name: 'ড. সুব্রত বিশ্বাস',
    qualification: 'DHMS (বাংলাদেশ হোমিওপ্যাথি বোর্ড), বিশেষ প্রশিক্ষণ চর্মরোগ ও গ্যাস্ট্রো',
    designation: 'কনসালট্যান্ট - চর্ম ও এলার্জি বিভাগ',
    specialties: ['একজিমা ও সোরিয়াসিস', 'মেছতা ও ব্রন', 'আইবিএস (IBS) ও গ্যাস্ট্রিক আলসার', 'চুল পড়া ও অ্যালোপেসিয়া'],
    experienceYears: 16,
    consultationFee: 600,
    followupFee: 350,
    visitingDays: ['রবিবার', 'সোমবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার'],
    visitingHours: 'সন্ধ্যা ৬:০০ - রাত ১০:০০',
    phone: '০১৯১১-৮৮৭৭৬৬',
    email: 'dr.subrata.homeo@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80',
    bio: 'চর্মরোগের মূলে গিয়ে ভেতরের ভারসাম্য ফিরিয়ে আনতে বিশেষভাবে অভিজ্ঞ। কোনো প্রকার মলম ছাড়াই অভ্যন্তরীণ ওষুধের দ্বারা চর্মরোগ সম্পূর্ণ নিরাময়ে কাজ করেন।'
  }
];

export const INITIAL_SETTINGS: ChamberSettings = {
  chamberName: 'হোমিও আরোগ্য নিকেতন ও রিসার্চ সেন্টার',
  tagline: 'প্রাকৃতিক ও ক্লাসিকাল পদ্ধতিতে স্থায়ী আরোগ্যের বিশ্বস্ত ঠিকানা',
  address: 'বাড়ি #৪৫, রোড #০৭, সেক্টর #১১, উত্তরা, ঢাকা-১২৩০',
  city: 'ঢাকা',
  phone: '০১৭৭৫-৯৮৪৫২০',
  emergencyPhone: '০১৬৭৮-৯৯০০১১',
  email: 'info@homeocare-arogya.com',
  visitingHours: 'শনি থেকে বৃহস্পতি: সকাল ১০:০০ - দুপুর ১:০০ এবং বিকাল ৫:০০ - রাত ১০:০০ (শুক্রবার বন্ধ)',
  regularFee: 700,
  followupFee: 400,
  noticeActive: true,
  noticeText: '📢 জরুরি ঘোষণা: আগামী শুক্রবার চেম্বারের সাপ্তাহিক ছুটি। তবে অনলাইন অ্যাপয়েন্টমেন্ট বুকিং ও ই-প্রেসক্রিপশন পোর্টাল ২৪/৭ সার্বক্ষণিক চালু আছে।',
  twoFactorEnabled: false,
  encryptionEnabled: true,
  autoBackupDaily: true,
  offlineSyncEnabled: true,
  darkThemeDefault: false,
  defaultDietInstructions: 'ওষুধ সেবনের ৩০ মিনিট পূর্বে ও পরে মুখ সম্পূর্ণ পরিষ্কার রাখবেন। কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করবেন। কাঁচা পিঁয়াজ, রসুন ও তীব্র কফি সম্পূর্ণ বর্জনীয়।',
  defaultRestrictions: [
    'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
    'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন',
    'ধূমপান, জর্দা ও তামাক জাতীয় দ্রব্য নিষিদ্ধ',
    'তেঁতুল, আচার ও অতিরিক্ত টক খাবার বর্জনীয়',
    'অতিরিক্ত তেল-মসলাযুক্ত ও বাসি খাবার বর্জনীয়',
    'ফ্রিজের অতিরিক্ত ঠান্ডা পানি বা আইসক্রিম নিষিদ্ধ'
  ],
  footerBio: 'ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।',
  footerContactHeading: 'যোগাযোগ ও চেম্বার ঠিকানা',
  footerQuickLinksHeading: 'রোগী সেবা ও পোর্টাল',
  footerQuickLinks: [
    { id: 'f-link-1', label: 'অনলাইন অ্যাপয়েন্টমেন্ট বুকিং', actionType: 'booking', enabled: true },
    { id: 'f-link-2', label: 'প্রেসক্রিপশন ও ওষুধের ইতিহাস অনুসন্ধান', actionType: 'lookup', enabled: true },
    { id: 'f-link-3', label: 'ডাক্তারদের প্রোফাইল ও সময়সূচী', actionType: 'doctors', url: '#doctors', enabled: true },
    { id: 'f-link-4', label: 'হোমিও মেটেরিয়া মেডিকা হ্যান্ডবুক', actionType: 'materia-medica', url: '#materia-medica', enabled: true }
  ],
  footerAppHeading: 'মোবাইল অ্যাপ ও ডাউনলোড',
  footerAppDesc: 'এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন অথবা বিল্ড ফোল্ডার থেকে APK ডাউনলোড করুন।',
  footerAppBtnText: 'ডাউনলোড APK (v1.0.4)',
  copyrightText: 'হোমিও আরোগ্য নিকেতন ও রিসার্চ সেন্টার — সর্বস্বত্ব সংরক্ষিত।',
  footerBottomTagline: 'অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ',
  footerBottomBadge: 'WordPress 6.7 & HomeoPress Theme',
  headerBadgeText: 'ডিজিটাল হোমিও ক্লিনিক',
  headerNavLinks: [
    { id: 'h-link-1', label: 'হোম', actionType: 'section', target: '#home', enabled: true },
    { id: 'h-link-2', label: 'ডাক্তারগণ', actionType: 'section', target: '#doctors', enabled: true },
    { id: 'h-link-3', label: 'সেবাসমূহ', actionType: 'section', target: '#services', enabled: true },
    { id: 'h-link-4', label: 'রোগীর রিভিউ', actionType: 'section', target: '#reviews', enabled: true },
    { id: 'h-link-5', label: 'মেটেরিয়া মেডিকা', actionType: 'section', target: '#materia-medica', enabled: true },
    { id: 'h-link-6', label: 'প্রেসক্রিপশন অনুসন্ধান', actionType: 'modal', target: 'lookup', enabled: true },
    { id: 'h-link-7', label: 'যোগাযোগ', actionType: 'section', target: '#contact', enabled: true }
  ],
  chatbotConfig: {
    botName: 'হোমিও এআই অ্যাসিস্ট্যান্ট',
    botSubtitle: 'জরুরি পরামর্শ ও সাহায্য',
    welcomeMessage: 'আসসালামু আলাইকুম! হোমিও আরোগ্য নিকেতনে আপনাকে স্বাগতম। আপনার শারীরিক সমস্যা বা চেম্বার সংক্রান্ত যে কোনো প্রশ্ন আমাকে করতে পারেন।',
    quickPrompts: [
      'গ্যাস্ট্রিক ও বুকজ্বালা উপশম',
      'চেম্বার খোলা ও ভিজিটিং সময়',
      'শিশুর ঠান্ডা ও টনসিলের চিকিৎসা',
      'ডাক্তার দেখানোর সিরিয়াল নিয়ম'
    ],
    disclaimerText: 'সতর্কতা: এটি প্রাথমিক তথ্য ও সহায়তা নির্দেশিকা। জটিল রোগে অভিজ্ঞ চিকিৎসকের প্রত্যক্ষ পরামর্শ নিন।',
    botEnabled: true,
    bookingCtaText: 'ডাক্তার অ্যাপয়েন্টমেন্ট বুক করুন',
    customQnA: [
      {
        id: 'qna-1',
        keyword: 'সিরিয়াল|বুকিং|অ্যাপয়েন্টমেন্ট|appointment|serial',
        question: 'ডাক্তার দেখানোর সিরিয়াল কীভাবে নিব?',
        answer: 'আপনি সরাসরি উপরের "সিরিয়াল নিন" বাটন অথবা চ্যাটের নিচের "ডাক্তার অ্যাপয়েন্টমেন্ট বুক করুন" বাটনে ক্লিক করে সহজেই সিরিয়াল নিতে পারবেন। চেম্বার হটলাইন: ০১৭৭৫-৯৮৪৫২০।',
        enabled: true
      },
      {
        id: 'qna-2',
        keyword: 'সময়|খোলা|কখন|টাইম|time|schedule',
        question: 'চেম্বার কখন খোলা থাকে?',
        answer: 'চেম্বার শনি থেকে বৃহস্পতি প্রতিদিন সকাল ১০:০০ - দুপুর ১:০০ এবং বিকাল ৫:০০ - রাত ১০:০০ পর্যন্ত খোলা থাকে। শুক্রবার সাপ্তাহিক ছুটি (অনলাইন পোর্টাল সার্বক্ষণিক চালু)।',
        enabled: true
      },
      {
        id: 'qna-3',
        keyword: 'ফি|টাকা|খরচ|fee|cost',
        question: 'ডাক্তারের ভিজিট বা ফি কত?',
        answer: 'প্রথমবার নতুন রোগী পরামর্শ ফি ৭০০ টাকা এবং ফলোআপ ভিজিট ফি ৪০০ টাকা। ওষুধ বাবদ খরচ ব্যবস্থাপত্র অনুযায়ী নির্ধারিত হয়।',
        enabled: true
      },
      {
        id: 'qna-4',
        keyword: 'ঠিকানা|লোকেশন|কোথায়|location|address',
        question: 'চেম্বারের ঠিকানা কোথায়?',
        answer: 'বাড়ি #৪৫, রোড #০৭, সেক্টর #১১, উত্তরা, ঢাকা-১২৩০। উত্তরা আজমপুর বাসস্ট্যান্ড থেকে রিকশায় ৫ মিনিটের পথ।',
        enabled: true
      },
      {
        id: 'qna-5',
        keyword: 'গ্যাস্ট্রিক|বদহজম|বুকজ্বালা|gas|gastric',
        question: 'গ্যাস্ট্রিক বা বুকজ্বালার হোমিও সমাধান কী?',
        answer: 'হোমিওপ্যাথিতে Nux Vomica, Carbo Veg, Robinia পেটের অম্লতা ও গ্যাস্ট্রিকে অত্যন্ত ফলপ্রসূ। ভাজাপোড়া ও কাঁচা পিঁয়াজ পরিহার করে কুসুম গরম পানি পান করুন এবং চিকিৎসকের পরামর্শ নিন।',
        enabled: true
      }
    ]
  },
  dashboardConfig: {
    welcomeTitle: 'হোমিও আরোগ্য নিকেতন ও রিসার্চ সেন্টার',
    welcomeSubtitle: 'ক্লাসিকাল হোমিওপ্যাথি ডিজিটাল প্রেসক্রিপশন, রোগী ডাটাবেস ও পেশাদার ক্লিনিকাল ম্যানেজমেন্ট সিস্টেম।',
    quickBtnText: 'নতুন প্রেসক্রিপশন তৈরি করুন',
    appointmentBtnText: 'অ্যাপয়েন্টমেন্ট ও সিরিয়াল',
    appointmentBtnAction: 'appointments',
    appointmentBtnVisible: true,
    stat1Title: 'আজকের অ্যাপয়েন্টমেন্ট',
    stat1Sub: 'নিবন্ধিত রোগী সিরিয়াল',
    stat2Title: 'মোট নিবন্ধিত রোগী',
    stat2Sub: 'আজীবন ডিজিটাল ফাইল',
    stat3Title: 'ইস্যুকৃত ডিজিটাল প্রেসক্রিপশন',
    stat3Sub: 'ই-প্রেসক্রিপশন রেকর্ড',
    stat4Title: 'চেম্বার কনসালট্যান্ট',
    stat4Sub: 'বিশেষজ্ঞ হোমিও চিকিৎসক',
    queueBoxTitle: 'আজকের রোগী কিউ ও লাইভ সিরিয়াল স্টেটাস',
    dashboardNotice: 'সতর্কতা: সকল রোগীর গোপনীয় তথ্য সংরক্ষিত। চেম্বারের অভ্যন্তরীণ ডাটাবেস পরিবর্তনের পূর্বে ব্যাকআপ নিশ্চিত করুন।'
  }
};

export const INITIAL_REVIEWS: PatientReview[] = [
  {
    id: 'rev-1',
    name: 'মোঃ হারুনুর রশীদ',
    location: 'উত্তরা সেক্টর ৭, ঢাকা',
    condition: '৩ বছরের ক্রনিক একজিমা ও শুষ্ক চর্মরোগ',
    text: 'অ্যালোপ্যাথিক স্টেরয়েড ক্রিম দিয়ে সাময়িক ভালো থাকত কিন্তু পরে আরও বেড়ে যেত। ড. সুমন কুমার স্যারের ৩ মাসের ক্লাসিকাল চিকিৎসায় এখন আমার হাত-পা একদম স্বাভাবিক ও নিখুঁত। কোনো দাগও নেই!',
    rating: 5,
    date: '১২ অক্টোবর, ২০২৬'
  },
  {
    id: 'rev-2',
    name: 'নাসরিন সুলতানা',
    location: 'মিরপুর-১০, ঢাকা',
    condition: 'ক্রনিক ব্রঙ্কাইটিস ও শ্বাসকষ্ট (অ্যাজমা)',
    text: 'ঠান্ডা বা ধুলাবালি লাগলেই রাতে ইনহেলার ছাড়া ঘুমাতে পারতাম না। ৫ মাস ধরে আরোগ্য নিকেতনের ওষুধ খেয়ে এখন ইনহেলার ছাড়াই সম্পূর্ণ সুস্থ জীবন যাপন করছি। অনলাইন প্রেসক্রিপশন সিস্টেমটিও অত্যন্ত চমৎকার।',
    rating: 5,
    date: '২৮ সেপ্টেম্বর, ২০২৬'
  },
  {
    id: 'rev-3',
    name: 'কামরুল হাসান চৌধুরী',
    location: 'ধানমন্ডি, ঢাকা',
    condition: 'ছেলের (৭ বছর) টনসিলের অপারেশন এড়ানো',
    text: 'ডাক্তাররা ছেলেকে অপারেশনের কথা বলেছিলেন। কিন্তু ড. তানজিলা আক্তারের পেডিয়াট্রিক হোমিও ওষুধে মাত্র দেড় মাসেই টনসিলের ফোলাভাব স্বাভাবিক হয়ে গেছে এবং সর্দি-কাশি কমেছে।',
    rating: 5,
    date: '০৫ অক্টোবর, ২০২৬'
  }
];

const TODAY = new Date().toISOString().split('T')[0];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-101',
    tokenNumber: 101,
    patientName: 'আনোয়ারুল হক',
    patientAge: 48,
    patientGender: 'পুরুষ',
    phone: '০১৭২১-৪৫৫৬৬৭',
    email: 'anwar.haque@gmail.com',
    address: 'মিরপুর-১০, ঢাকা',
    date: TODAY,
    timeSlot: 'বিকাল ৫:৩০ - বিকাল ৫:৫০',
    doctorId: 'doc-1',
    doctorName: 'ড. সুমন কুমার',
    symptoms: 'দীর্ঘদিন যাবত তীব্র গ্যাস্ট্রিক বুকজ্বালা, অম্ল ঢেকুর এবং পেটে গ্যাস জমা। রাতে ঘুমাতে গেলে পেটের অস্বস্তি বাড়ে।',
    chronicHistory: '৩ বছর ধরে গ্যাসট্রাইটিস ও ফ্যাটি লিভার গ্রেড-১',
    previousTreatments: 'অ্যালোপ্যাথিক পিপিআই ক্যাপসুল সাময়িক কাজ করে, পরে আবার ফিরে আসে।',
    status: 'in-consultation',
    priority: 'normal',
    consultationType: 'chamber',
    createdAt: `${TODAY}T09:15:00.000Z`,
    prescriptionId: 'rx-881'
  },
  {
    id: 'apt-102',
    tokenNumber: 102,
    patientName: 'ফরিদা ইয়াসমিন',
    patientAge: 36,
    patientGender: 'মহিলা',
    phone: '০১৮১৯-৭৮৬৬৭৭',
    email: 'farida.y@gmail.com',
    address: 'উত্তরা সেক্টর ৪, ঢাকা',
    date: TODAY,
    timeSlot: 'সন্ধ্যা ৬:০০ - সন্ধ্যা ৬:২০',
    doctorId: 'doc-1',
    doctorName: 'ড. সুমন কুমার',
    symptoms: 'হাতে ও পায়ে শুকনো একজিমা, প্রচণ্ড চুলকানি ও ত্বক ফাটা। পানির স্পর্শে চুলকানি বাড়ে।',
    chronicHistory: 'শীতকালে ও আবহাওয়া পরিবর্তনের সময় চর্মরোগ বাড়ে।',
    previousTreatments: 'স্টেরয়েড অয়েন্টমেন্ট ব্যবহার করে বন্ধ করার পর সমস্যা বেড়ে গেছে।',
    status: 'confirmed',
    priority: 'normal',
    consultationType: 'chamber',
    createdAt: `${TODAY}T10:30:00.000Z`
  },
  {
    id: 'apt-103',
    tokenNumber: 103,
    patientName: 'তানভীর আহমেদ',
    patientAge: 29,
    patientGender: 'পুরুষ',
    phone: '০১৯১২-৫৫৪৪৩৩',
    address: 'টঙ্গী, গাজীপুর',
    date: TODAY,
    timeSlot: 'সন্ধ্যা ৬:৩০ - সন্ধ্যা ৬:৫০',
    doctorId: 'doc-3',
    doctorName: 'ড. সুব্রত বিশ্বাস',
    symptoms: 'খাবারের পর পেট ফাঁপা ও ঘন ঘন পাতলা পায়খানার প্রবণতা (আইবিএস লক্ষণ)। মানসিক চাপে বৃদ্ধি।',
    chronicHistory: 'আইবিএস (IBS) ৬ মাস ধরে',
    status: 'pending',
    priority: 'normal',
    consultationType: 'chamber',
    createdAt: `${TODAY}T11:45:00.000Z`
  },
  {
    id: 'apt-104',
    tokenNumber: 104,
    patientName: 'শিশু আরিয়ান ইকবাল',
    patientAge: 6,
    patientGender: 'শিশু',
    phone: '০১৭৫৮-৯৯৮৮২২',
    address: 'বনশ্রী, ঢাকা',
    date: TODAY,
    timeSlot: 'সকাল ১১:০০ - সকাল ১১:২০',
    doctorId: 'doc-2',
    doctorName: 'ড. তানজিলা আক্তার',
    symptoms: 'হালকা ঠান্ডাতেই বারবার নাক দিয়ে পানি পড়া, রাতভর শুকনো কাশি এবং খাবার খেতে অনীহা।',
    chronicHistory: 'টনসিলের ফোলাভাব ও অ্যালার্জিক রাইনাইটিস',
    status: 'completed',
    priority: 'normal',
    consultationType: 'chamber',
    createdAt: `${TODAY}T08:20:00.000Z`,
    prescriptionId: 'rx-882'
  }
];

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: 'pat-1',
    name: 'আনোয়ারুল হক',
    phone: '০১৭২১-৪৫৫৬৬৭',
    age: 48,
    gender: 'পুরুষ',
    bloodGroup: 'B+',
    address: 'মিরপুর-১০, ঢাকা',
    firstVisitDate: '2025-08-10',
    lastVisitDate: TODAY,
    totalVisits: 5,
    chronicConditions: ['ক্রনিক গ্যাস্ট্রাইটিস', 'ফ্যাটি লিভার গ্রেড-১'],
    totalPrescriptions: 3,
    notes: 'রোগীর ঝাল খাবারের প্রতি আসক্তি রয়েছে। মানসিক কাজের চাপ বেশি।'
  },
  {
    id: 'pat-2',
    name: 'ফরিদা ইয়াসমিন',
    phone: '০১৮১৯-৭৮৬৬৭৭',
    age: 36,
    gender: 'মহিলা',
    bloodGroup: 'O+',
    address: 'উত্তরা সেক্টর ৪, ঢাকা',
    firstVisitDate: '2025-11-14',
    lastVisitDate: TODAY,
    totalVisits: 2,
    chronicConditions: ['শুকনো একজিমা', 'ঠান্ডা অ্যালার্জি'],
    totalPrescriptions: 1,
    notes: 'সাবান ও ডিটারজেন্ট ব্যবহারের কারণে ত্বকে ফুসকুড়ি ও চুলকানি দেখা দেয়।'
  },
  {
    id: 'pat-3',
    name: 'শিশু আরিয়ান ইকবাল',
    phone: '০১৭৫৮-৯৯৮৮২২',
    age: 6,
    gender: 'শিশু',
    bloodGroup: 'A+',
    address: 'বনশ্রী, ঢাকা',
    firstVisitDate: '2026-01-05',
    lastVisitDate: TODAY,
    totalVisits: 4,
    chronicConditions: ['হাইপারট্রফিড টনসিল', 'অ্যালার্জিক রাইনাইটিস'],
    totalPrescriptions: 2,
    notes: 'মৃদু হোমিওপ্যাথিক ওষুধে টনসিলের ফোলাভাব পূর্বের তুলনায় ৫০% হ্রাস পেয়েছে।'
  }
];

export const INITIAL_PRESCRIPTIONS: Prescription[] = [
  {
    id: 'rx-881',
    prescriptionCode: 'RX-2026-881',
    appointmentId: 'apt-101',
    patientId: 'pat-1',
    patientName: 'আনোয়ারুল হক',
    patientAge: 48,
    patientGender: 'পুরুষ',
    patientPhone: '০১৭২১-৪৫৫৬৬৭',
    patientAddress: 'মিরপুর-১০, ঢাকা',
    registerPageNo: 'খাতা-১, পৃষ্ঠা-৭২',
    date: TODAY,
    doctorId: 'doc-1',
    doctorName: 'ড. সুমন কুমার',
    doctorQualification: 'BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট)',
    diagnosis: 'ক্রনিক গ্যাস্ট্রাইটিস ও এসিডিটি (Chronic Gastritis with Acid Dyspepsia)',
    symptoms: ['খাবারের পর পেটে বায়ু জমা', 'অম্ল ঢেকুর', 'রাতে অস্বস্তি', 'অলস জীবনযাপন'],
    constitutionalState: 'Nux Vomica Constitution (কর্মঠ, খিটখিটে মেজাজ, অনিদ্রা)',
    medicines: [
      {
        id: 'med-1',
        name: 'Nux Vomica',
        potency: '200CH',
        dosage: '২ ফোঁটা',
        frequency: 'প্রতি রাতে ঘুমানোর পূর্বে',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পর ১ চামচ পানিতে',
        instructions: 'রাতের ওষুধ নিয়ম করে সেবন করবেন।'
      },
      {
        id: 'med-2',
        name: 'Carbo Vegetabilis',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'দিনে ২ বার (সকালে ও দুপুরে)',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে',
        instructions: 'পেট ফাঁপা ও গ্যাস উপশমে বিশেষ কার্যকর।'
      },
      {
        id: 'med-3',
        name: 'Robinia Pseudacacia',
        potency: 'Q (Mother Tincture)',
        dosage: '১০ ফোঁটা',
        frequency: 'দিনে ৩ বার',
        duration: '১৫ দিন',
        timing: 'আধা কাপ কুসুম গরম পানিতে মিশিয়ে',
        instructions: 'তীব্র অম্ল ঢেকুর ও বুকজ্বালা কমাতে নির্দেশিত।'
      }
    ],
    dietRestrictions: [
      'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
      'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন',
      'অতিরিক্ত তেল-মসলাযুক্ত খাবার ও ফাস্টফুড বর্জনীয়',
      'ধূমপান ও জর্দা বা তামাক জাতীয় দ্রব্য নিষিদ্ধ'
    ],
    lifestyleAdvice: [
      'প্রতিদিন সকালে ১৫-২০ মিনিট মুক্ত বাতাসে মৃদু হাঁটা',
      'রাতের খাবার ঘুমানোর কমপক্ষে ২ ঘণ্টা পূর্বে সম্পন্ন করা',
      'পর্যাপ্ত পরিমাণে বিশুদ্ধ কুসুম গরম পানি পান করা'
    ],
    testsAdvised: ['USG of Whole Abdomen (ফলোআপের জন্য)'],
    followUpDate: '2026-11-20',
    notes: 'ওষুধ সেবনের পর কোনো জটিলতা বা তীব্র পরিবর্তন পরিলক্ষিত হলে চেম্বার হটলাইনে ফোন দিন।',
    prescriptionImage: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800&auto=format&fit=crop&q=80',
    createdAt: `${TODAY}T17:40:00.000Z`
  },
  {
    id: 'rx-882',
    prescriptionCode: 'RX-2026-882',
    appointmentId: 'apt-104',
    patientId: 'pat-3',
    patientName: 'শিশু আরিয়ান ইকবাল',
    patientAge: 6,
    patientGender: 'শিশু',
    patientPhone: '০১৭৫৮-৯৯৮৮২২',
    patientAddress: 'বনশ্রী, ঢাকা',
    registerPageNo: 'খাতা-২, পৃষ্ঠা-১৮',
    date: TODAY,
    doctorId: 'doc-2',
    doctorName: 'ড. তানজিলা আক্তার',
    doctorQualification: 'BHMS (রাজশাহী বিশ্ববিদ্যালয়), ট্রেইন্ড ইন পেডিয়াট্রিক হোমিওপ্যাথি',
    diagnosis: 'টনসিলাইটিস ও পুনরাবৃত্তিমুখী সর্দি (Tonsillitis with recurrent cold)',
    symptoms: ['গলা ব্যথা', 'টনসিল ফোলা', 'রাতে কাশি'],
    constitutionalState: 'Baryta Carb / Calcarea Phosphorica',
    medicines: [
      {
        id: 'med-21',
        name: 'Baryta Carbonica',
        potency: '30CH',
        dosage: '৪টি মিষ্টি গ্লোবিউলস',
        frequency: 'দিনে ২ বার (সকাল ও রাত)',
        duration: '২১ দিন',
        timing: 'খাবারের ৩০ মিনিট পূর্বে চুষে খাবে',
        instructions: 'শিশুর টনসিল সঙ্কুচিত করতে বিশেষ কার্যকরী।'
      },
      {
        id: 'med-22',
        name: 'Calcarea Phosphorica',
        potency: '6X',
        dosage: '২টি ট্যাবলেট',
        frequency: 'দিনে ৩ বার চিবিয়ে বা হালকা গরম পানিতে',
        duration: '২১ দিন',
        timing: 'খাবারের পর',
        instructions: 'হাড়ের গঠন ও শারীরিক পুষ্টি বৃদ্ধিতে সহায়ক।'
      }
    ],
    dietRestrictions: [
      'ফ্রিজের ঠান্ডা পানি ও আইসক্রিম সম্পূর্ণ নিষিদ্ধ',
      'প্যাকেটজাত চিপস ও কোমল পানীয় বন্ধ রাখতে হবে'
    ],
    lifestyleAdvice: [
      'হালকা কুসুম গরম পানিতে লবণ দিয়ে কুলকুচি করা',
      'ঠান্ডা বাতাস থেকে সুরক্ষিত রাখা'
    ],
    followUpDate: '2026-11-25',
    notes: 'শিশুর ওজন ও শারীরিক বিকাশ স্বাভাবিক রয়েছে।',
    createdAt: `${TODAY}T11:30:00.000Z`
  },
  {
    id: 'rx-883',
    prescriptionCode: 'RX-2026-883',
    appointmentId: 'apt-102',
    patientId: 'pat-2',
    patientName: 'ফরিদা ইয়াসমিন',
    patientAge: 36,
    patientGender: 'মহিলা',
    patientPhone: '০১৮১৯-৭৮৬৬৭৭',
    patientAddress: 'উত্তরা সেক্টর ৪, ঢাকা',
    date: TODAY,
    doctorId: 'doc-1',
    doctorName: 'ড. সুমন কুমার',
    doctorQualification: 'BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট)',
    diagnosis: 'ক্রনিক শুষ্ক একজিমা (Chronic Dry Eczema)',
    symptoms: ['হাতে-পায়ে চুলকানি', 'ত্বক ফাটা', 'পানির স্পর্শে অস্বস্তি'],
    constitutionalState: 'Sulphur / Graphites',
    medicines: [
      {
        id: 'med-31',
        name: 'Graphites',
        potency: '200CH',
        dosage: '২ ফোঁটা',
        frequency: 'সকালে খালি পেটে সপ্তাহে ২ দিন',
        duration: '১৫ দিন',
        timing: '১ চামচ পানির সাথে',
        instructions: 'ত্বক ফাটা ও আঠালো রস নিরাময়ে কার্যকর।'
      },
      {
        id: 'med-32',
        name: 'Sulphur',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'প্রতি রবিবার সকালে ১ বার',
        duration: '১ মাস',
        timing: 'খাবারের ১ ঘণ্টা পূর্বে',
        instructions: 'চর্মরোগের মূলে কাজ করে।'
      }
    ],
    dietRestrictions: [
      'অতিরিক্ত মিষ্টি ও ইলিশ মাছ পরিহার করুন',
      'ডিটারজেন্ট ও সাবান সরাসরি খালি হাতে ব্যবহার বন্ধ রাখুন'
    ],
    lifestyleAdvice: [
      'গোসলের পর খাঁটি নারকেল তেল হালকা মালিশ করা'
    ],
    followUpDate: '2026-12-01',
    notes: 'ত্বকের চুলকানি পূর্বের তুলনায় কমেছে।',
    createdAt: `${TODAY}T10:45:00.000Z`
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    action: 'ডাটাবেস ইনিশিয়ালাইজেশন',
    details: 'হোমিও আরোগ্য নিকেতন চেম্বার সিস্টেম সফলভাবে সক্রিয় হয়েছে।',
    timestamp: `${TODAY} 08:00:12`,
    user: 'System Admin',
    ip: '127.0.0.1 (Local)',
    severity: 'info'
  },
  {
    id: 'log-2',
    action: 'মাস্টার সিকিউরিটি কনফিগারেশন',
    details: 'মাস্টার সিকিউরিটি কোড ও এনক্রিপশন সফলভাবে সংযুক্ত করা হয়েছে।',
    timestamp: `${TODAY} 08:00:15`,
    user: 'Security Module',
    ip: '192.168.1.1',
    severity: 'security'
  },
  {
    id: 'log-3',
    action: 'অ্যাপয়েন্টমেন্ট বুকিং',
    details: 'আনোয়ারুল হক (#TK-101) ড. সুমন কুমারের কাছে বুকিং করেছেন।',
    timestamp: `${TODAY} 09:15:02`,
    user: 'Patient Portal',
    ip: '103.114.98.22',
    severity: 'success'
  },
  {
    id: 'log-4',
    action: 'প্রেসক্রিপশন ইস্যু',
    details: 'প্রেসক্রিপশন কোড RX-2026-881 রোগীর জন্য তৈরি ও ডিজিটাল সিস্টেমে নিবন্ধিত।',
    timestamp: `${TODAY} 17:40:22`,
    user: 'ড. সুমন কুমার',
    ip: '192.168.1.15',
    severity: 'success'
  }
];

export const MATERIA_MEDICA_GUIDE: MateriaMedicaItem[] = [
  {
    name: 'Arnica Montana',
    commonName: 'Mountain Daisy / চোট আঘাতের মহৌষধ',
    keyIndications: 'যেকোনো ভোঁতা আঘাত, থেঁতলে যাওয়া, কালশিটে, পড়ে গিয়ে শরীরের পেশিতে তীব্র চোট ও ব্যথায় প্রথম পছন্দ। বিছানা শক্ত বোধ হওয়া।',
    modalities: 'বৃদ্ধি: নড়াচড়ায়, স্পর্শে; উপশম: বিশ্রামে, শুয়ে থাকলে।',
    commonPotencies: ['30CH', '200CH', '1M']
  },
  {
    name: 'Nux Vomica',
    commonName: 'Poison Nut / গ্যাস্ট্রিক ও পেটের রাজা',
    keyIndications: 'অতিরিক্ত মানসিক পরিশ্রম, রাতজাগা, কড়া চা-কফি, মসলাযুক্ত খাদ্যের ফলে বদহজম, অম্ল ঢেকুর, কোষ্ঠকাঠিন্য ও খিটখিটে মেজাজে অব্যর্থ।',
    modalities: 'বৃদ্ধি: সকালে, ঠান্ডায়, খাওয়ার পর; উপশম: বিশ্রামে, গরমে।',
    commonPotencies: ['30CH', '200CH']
  },
  {
    name: 'Belladonna',
    commonName: 'Deadly Nightshade / উত্তপ্ত লাল প্রদাহ',
    keyIndications: 'হঠাৎ তীব্র আক্রমণ, লালচে মুখমণ্ডল, রক্তবর্ণ চোখ, দপদপানি মাথাব্যথা এবং শুষ্ক উচ্চ তাপমাত্রার জ্বর। আলো ও শব্দে অসহ্য বোধ।',
    modalities: 'বৃদ্ধি: আলোতে, শব্দে, জার্কিং বা ঝাঁকুনিতে; উপশম: অন্ধকারে, মাথা উঁচু করে থাকলে।',
    commonPotencies: ['30CH', '200CH']
  },
  {
    name: 'Aconite Napellus',
    commonName: 'Monkshood / আকস্মিক ভয় ও তীব্র জ্বর',
    keyIndications: 'শুষ্ক উত্তুরে ঠান্ডা বাতাসে হঠাৎ অসুস্থতা, তীব্র মৃত্যুভয় ও অস্থিরতা, দ্রুত নাড়ি এবং প্রচণ্ড তৃষ্ণা। রোগের প্রথম ২৪ ঘণ্টার জরুরি ওষুধ।',
    modalities: 'বৃদ্ধি: সন্ধ্যায়, মধ্যরাতে, শুষ্ক ঠান্ডা বাতাসে; উপশম: উন্মুক্ত বাতাসে।',
    commonPotencies: ['30CH', '200CH']
  },
  {
    name: 'Thuja Occidentalis',
    commonName: 'Arbor Vitae / আঁচিল ও সাইকোটিক দোষ',
    keyIndications: 'শরীরের যেকোনো অংশের আঁচিল (Warts), টিউমার, পলিপ, চর্মরোগ ও টিকা পরবর্তী পার্শ্বপ্রতিক্রিয়া নিরাময়ে সর্বপ্রধান ওষুধ।',
    modalities: 'বৃদ্ধি: স্যাঁতসেঁতে ভেজা আবহাওয়ায়, রাতে; উপশম: উষ্ণতায়, শুষ্ক দিনে।',
    commonPotencies: ['200CH', '1M', '10M']
  },
  {
    name: 'Rhus Toxicodendron',
    commonName: 'Poison Ivy / বাতরোগ ও পেশির টান',
    keyIndications: 'বৃষ্টিতে ভেজার পর বা অতিরিক্ত ভার তোলার পর কোমর ও সন্ধির বাতব্যথা। প্রথমে নড়াচড়া করতে প্রচণ্ড কষ্ট হলেও একটানা চললে ব্যথা কমে।',
    modalities: 'বৃদ্ধি: প্রথম নড়াচড়ায়, বর্ষায়, বিশ্রামে; উপশম: অবিরাম নড়াচড়ায়, গরম সেঁকে।',
    commonPotencies: ['30CH', '200CH', '1M']
  },
  {
    name: 'Bryonia Alba',
    commonName: 'Wild Hops / শুষ্কতা ও অনড় বিশ্রাম',
    keyIndications: 'শরীরের সকল শ্লেষ্মাঝিল্লি শুষ্ক, প্রচুর পানি পিপাসা (অনেকক্ষণ পর পর বেশি পানি পান), এবং সামান্যতম নড়াচড়ায় রোগের তীব্র বৃদ্ধি।',
    modalities: 'বৃদ্ধি: যে কোনো নড়াচড়ায়; উপশম: ব্যথাতুর অঙ্গের উপর চেপে শুলে ও পূর্ণ বিশ্রামে।',
    commonPotencies: ['30CH', '200CH']
  },
  {
    name: 'Arsenicum Album',
    commonName: 'White Oxide of Arsenic / বিষাক্ততা ও দাহ',
    keyIndications: 'খাদ্যে বিষক্রিয়া, পাতলা পায়খানা, তীব্র পেট জ্বালা, সামান্য পানি বারবার পান করা, তীব্র মৃত্যুভয় ও মধ্যরাতে রোগের বৃদ্ধি।',
    modalities: 'বৃদ্ধি: মধ্যরাতে (১২টা - ২টা), ঠান্ডায়; উপশম: গরম সেঁক ও উষ্ণ পানীয় পানে।',
    commonPotencies: ['30CH', '200CH']
  }
];
