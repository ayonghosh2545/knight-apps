import React from 'react';
import { ClinicProvider, useClinic } from './context/ClinicContext.tsx';
import { WpAdminBar } from './components/WpAdminBar.tsx';
import { FrontendNavbar } from './components/FrontendNavbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { DoctorProfilesSection } from './components/DoctorProfilesSection.tsx';
import { MateriaMedicaGuide } from './components/MateriaMedicaGuide.tsx';
import { PatientReviews } from './components/PatientReviews.tsx';
import { ChamberFooter } from './components/ChamberFooter.tsx';
import { AppointmentBookingModal } from './components/AppointmentBookingModal.tsx';
import { PrescriptionPortal } from './components/PrescriptionPortal.tsx';
import { EmergencyChatbot } from './components/EmergencyChatbot.tsx';
import { GlobalSearchModal } from './components/GlobalSearchModal.tsx';
import { MasterLoginModal } from './components/MasterLoginModal.tsx';
import { WpAdminLayout } from './components/admin/WpAdminLayout.tsx';

const MainAppContent: React.FC = () => {
  const { currentView } = useClinic();

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-[#12171a] text-gray-900 dark:text-gray-100 transition-colors font-sans antialiased">
      {/* WordPress Top Admin Bar */}
      <WpAdminBar />

      {/* Primary View Routing: Frontend Theme Website vs WP Admin */}
      {currentView === 'frontend' ? (
        <div className="flex-1 flex flex-col">
          <FrontendNavbar />
          <main className="flex-1">
            <HeroSection />
            <DoctorProfilesSection />
            <MateriaMedicaGuide />
            <PatientReviews />
          </main>
          <ChamberFooter />
        </div>
      ) : (
        <WpAdminLayout />
      )}

      {/* Global Modals & Overlay Portals */}
      <AppointmentBookingModal />
      <PrescriptionPortal />
      <EmergencyChatbot />
      <GlobalSearchModal />
      <MasterLoginModal />
    </div>
  );
};

export default function App() {
  return (
    <ClinicProvider>
      <MainAppContent />
    </ClinicProvider>
  );
}
