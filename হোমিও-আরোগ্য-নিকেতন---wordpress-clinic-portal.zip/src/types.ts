export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  designation: string;
  specialties: string[];
  experienceYears: number;
  consultationFee: number;
  followupFee: number;
  visitingDays: string[];
  visitingHours: string;
  phone: string;
  email: string;
  avatar: string;
  bio: string;
}

export interface MedicineItem {
  id: string;
  name: string;
  potency: string; // e.g. 30C, 200C, 1M, Q (Mother Tincture), 6X
  dosage: string; // e.g. ২ ফোঁটা / ৪টি গ্লোবিউলস
  frequency: string; // e.g. দিনে ৩ বার / সকালে খালি পেটে
  duration: string; // e.g. ৭ দিন / ১৫ দিন / ১ মাস
  timing: string; // e.g. খাবারের ৩০ মিনিট পূর্বে / রাতে ঘুমানোর পূর্বে
  instructions?: string; // e.g. আধা কাপ কুসুম গরম পানির সাথে
}

export interface Prescription {
  id: string;
  prescriptionCode: string; // e.g. RX-2026-881
  appointmentId?: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: 'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য';
  patientPhone: string;
  patientAddress?: string;
  registerPageNo?: string; // খাতার পেজ নম্বর (Register / Ledger Book Page No.)
  date: string;
  doctorId: string;
  doctorName: string;
  doctorQualification: string;
  diagnosis: string;
  symptoms: string[];
  constitutionalState?: string;
  medicines: MedicineItem[];
  dietRestrictions: string[]; // e.g. কাঁচা পিঁয়াজ, রসুন, চা-কফি পরিহার
  lifestyleAdvice: string[];
  testsAdvised?: string[];
  followUpDate: string;
  notes?: string;
  prescriptionImage?: string; // প্রেসক্রিপশনের ছবি / স্ক্যান কপি (Base64 Data URL or Image URL)
  prescriptionImages?: string[]; // একাধিক প্রেসক্রিপশন ছবি বা রিপোর্ট
  createdAt: string;
}

export interface Appointment {
  id: string;
  tokenNumber: number; // e.g. 101, 102
  patientName: string;
  patientAge: number;
  patientGender: 'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য';
  phone: string;
  email?: string;
  address?: string;
  date: string;
  timeSlot: string;
  doctorId: string;
  doctorName: string;
  symptoms: string;
  chronicHistory?: string;
  previousTreatments?: string;
  status: 'pending' | 'confirmed' | 'in-consultation' | 'completed' | 'cancelled';
  priority: 'normal' | 'emergency';
  consultationType: 'chamber' | 'online';
  createdAt: string;
  prescriptionId?: string;
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  age: number;
  gender: 'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য';
  bloodGroup?: string;
  address: string;
  firstVisitDate: string;
  lastVisitDate: string;
  totalVisits: number;
  chronicConditions: string[];
  totalPrescriptions: number;
  notes?: string;
  email?: string;
  emergencyContact?: string;
  constitutionalType?: string;
  allergies?: string[];
}

export interface AdminAccountProfile {
  name: string;
  username: string;
  email: string;
  phone: string;
  designation: string;
  qualifications: string;
  avatarUrl: string;
  bio: string;
  masterSecurityCode: string;
  twoFactorPin: string;
  role: string;
  lastLoginDate: string;
}

export interface ChamberSettings {
  chamberName: string;
  tagline: string;
  address: string;
  city: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  visitingHours: string;
  regularFee: number;
  followupFee: number;
  noticeActive: boolean;
  noticeText: string;
  twoFactorEnabled: boolean;
  encryptionEnabled: boolean;
  autoBackupDaily: boolean;
  offlineSyncEnabled: boolean;
  darkThemeDefault: boolean;
  defaultDietInstructions?: string;
  defaultRestrictions?: string[];
  footerBio?: string;
  footerContactHeading?: string;
  footerQuickLinksHeading?: string;
  footerQuickLinks?: FooterQuickLink[];
  footerAppHeading?: string;
  footerAppDesc?: string;
  footerAppBtnText?: string;
  copyrightText?: string;
  footerBottomTagline?: string;
  footerBottomBadge?: string;
  headerBadgeText?: string;
  headerNavLinks?: HeaderNavMenuLink[];
  chatbotConfig?: ChatbotConfig;
  dashboardConfig?: DashboardConfig;
}

export interface HeaderNavMenuLink {
  id: string;
  label: string;
  actionType: 'section' | 'modal' | 'external';
  target: string;
  enabled: boolean;
}

export interface ChatbotQnA {
  id: string;
  keyword: string;
  question: string;
  answer: string;
  enabled?: boolean;
}

export interface ChatbotConfig {
  botName: string;
  botSubtitle: string;
  welcomeMessage: string;
  quickPrompts: string[];
  disclaimerText: string;
  botEnabled: boolean;
  bookingCtaText?: string;
  customQnA: ChatbotQnA[];
}

export interface DashboardConfig {
  welcomeTitle: string;
  welcomeSubtitle: string;
  quickBtnText: string;
  appointmentBtnText?: string;
  appointmentBtnAction?: 'appointments' | 'booking_modal';
  appointmentBtnVisible?: boolean;
  stat1Title: string;
  stat1Sub: string;
  stat2Title: string;
  stat2Sub: string;
  stat3Title: string;
  stat3Sub: string;
  stat4Title: string;
  stat4Sub: string;
  queueBoxTitle: string;
  dashboardNotice?: string;
}

export interface FooterQuickLink {
  id: string;
  label: string;
  actionType: 'booking' | 'lookup' | 'doctors' | 'materia-medica' | 'custom';
  url?: string;
  enabled?: boolean;
}

export interface PatientReview {
  id: string;
  name: string;
  location: string;
  condition: string;
  text: string;
  rating: number;
  date: string;
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  timestamp: string;
  user: string;
  ip: string;
  severity: 'info' | 'warning' | 'security' | 'success';
}

export interface CloudBackupSnapshot {
  id: string;
  timestamp: string;
  sizeBytes: number;
  recordsCount: number;
  checksum: string;
  note: string;
}

export interface SyncQueueItem {
  id: string;
  action: 'create' | 'update' | 'delete';
  entity: 'appointment' | 'prescription' | 'patient' | 'settings';
  data: any;
  timestamp: string;
  synced: boolean;
}

export interface MateriaMedicaItem {
  name: string;
  commonName: string;
  keyIndications: string;
  modalities: string;
  commonPotencies: string[];
}
