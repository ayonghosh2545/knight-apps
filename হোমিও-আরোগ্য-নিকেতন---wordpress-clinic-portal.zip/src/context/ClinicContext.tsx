import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Doctor,
  Appointment,
  Prescription,
  Patient,
  ChamberSettings,
  AuditLog,
  CloudBackupSnapshot,
  SyncQueueItem,
  AdminAccountProfile,
  PatientReview
} from '../types.ts';
import {
  INITIAL_DOCTORS,
  INITIAL_SETTINGS,
  INITIAL_APPOINTMENTS,
  INITIAL_PATIENTS,
  INITIAL_PRESCRIPTIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_ADMIN_PROFILE,
  INITIAL_REVIEWS
} from '../utils/initialData.ts';
import {
  verifyMasterSecurityCode,
  verify2FACode,
  encryptPayload,
  decryptPayload,
  calculateChecksum
} from '../utils/crypto.ts';

interface ClinicContextType {
  doctors: Doctor[];
  settings: ChamberSettings;
  adminProfile: AdminAccountProfile;
  appointments: Appointment[];
  patients: Patient[];
  prescriptions: Prescription[];
  reviews: PatientReview[];
  auditLogs: AuditLog[];
  cloudSnapshots: CloudBackupSnapshot[];
  syncQueue: SyncQueueItem[];
  
  // Statuses
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncedAt: string;
  isMasterAuthenticated: boolean;
  isTwoFactorVerified: boolean;
  isDarkMode: boolean;
  currentView: 'frontend' | 'wp-admin';
  adminSubTab: string;

  // Modals & Triggers
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  isBookingModalOpen: boolean;
  setIsBookingModalOpen: (open: boolean) => void;
  selectedDoctorForBooking: Doctor | null;
  setSelectedDoctorForBooking: (doctor: Doctor | null) => void;
  isPrescriptionLookupOpen: boolean;
  setIsPrescriptionLookupOpen: (open: boolean) => void;
  activeLookupCodeOrPhone: string;
  setActiveLookupCodeOrPhone: (query: string) => void;
  isChatbotOpen: boolean;
  setIsChatbotOpen: (open: boolean) => void;
  selectedPrescriptionForView: Prescription | null;
  setSelectedPrescriptionForView: (rx: Prescription | null) => void;

  // Actions
  setCurrentView: (view: 'frontend' | 'wp-admin') => void;
  setAdminSubTab: (tab: string) => void;
  toggleDarkMode: () => void;
  verifyMasterLogin: (code: string, otp?: string) => { success: boolean; message: string; requires2FA?: boolean };
  logoutMaster: () => void;
  
  bookAppointment: (data: Omit<Appointment, 'id' | 'tokenNumber' | 'createdAt' | 'status'>) => Appointment;
  updateAppointment: (id: string, updatedData: Partial<Appointment>) => void;
  deleteAppointment: (id: string) => void;
  updateAppointmentStatus: (id: string, status: Appointment['status']) => void;
  addPrescription: (data: Omit<Prescription, 'id' | 'createdAt'>) => Prescription;
  updatePrescription: (id: string, updatedData: Partial<Prescription>) => void;
  deletePrescription: (id: string) => void;
  updateChamberSettings: (newSettings: Partial<ChamberSettings>) => void;
  updateAdminProfile: (newProfile: Partial<AdminAccountProfile>) => void;
  updateDoctor: (id: string, updatedData: Partial<Doctor>) => void;
  addDoctor: (doctor: Omit<Doctor, 'id'>) => Doctor;
  deleteDoctor: (id: string) => void;
  addPatient: (data: Omit<Patient, 'id' | 'firstVisitDate' | 'lastVisitDate' | 'totalVisits' | 'totalPrescriptions'>) => Patient;
  updatePatient: (id: string, updatedData: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  
  // Reviews Actions
  addReview: (review: Omit<PatientReview, 'id'>) => PatientReview;
  updateReview: (id: string, updatedData: Partial<PatientReview>) => void;
  deleteReview: (id: string) => void;
  
  // Backup & Restore
  exportJsonBackup: (encrypt?: boolean) => string;
  importJsonBackup: (jsonContent: string) => { success: boolean; message: string };
  triggerCloudBackup: () => Promise<{ success: boolean; message: string }>;
  restoreCloudSnapshot: (snapshotId: string) => void;
  
  // Maintenance & System
  optimizeDatabase: () => { freedBytes: number; message: string };
  clearCache: () => void;
  logAction: (action: string, details: string, severity?: AuditLog['severity']) => void;
  addAuditLog: (action: string, details: string, severity?: AuditLog['severity']) => void;
  triggerManualSync: () => void;
}

const ClinicContext = createContext<ClinicContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SETTINGS: 'homeocare_settings',
  ADMIN_PROFILE: 'homeocare_admin_profile',
  DOCTORS: 'homeocare_doctors',
  APPOINTMENTS: 'homeocare_appointments',
  PATIENTS: 'homeocare_patients',
  PRESCRIPTIONS: 'homeocare_prescriptions',
  REVIEWS: 'homeocare_reviews',
  LOGS: 'homeocare_audit_logs',
  SNAPSHOTS: 'homeocare_cloud_snapshots',
  SYNC_QUEUE: 'homeocare_sync_queue',
  AUTH: 'homeocare_master_auth',
  DARK_MODE: 'homeocare_theme_dark'
};

export const ClinicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial states with localStorage persistence
  const [settings, setSettings] = useState<ChamberSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [adminProfile, setAdminProfile] = useState<AdminAccountProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_PROFILE);
      return saved ? JSON.parse(saved) : INITIAL_ADMIN_PROFILE;
    } catch {
      return INITIAL_ADMIN_PROFILE;
    }
  });

  const [doctors, setDoctors] = useState<Doctor[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DOCTORS);
      return saved ? JSON.parse(saved) : INITIAL_DOCTORS;
    } catch {
      return INITIAL_DOCTORS;
    }
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
      return saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
    } catch {
      return INITIAL_APPOINTMENTS;
    }
  });

  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PATIENTS);
      return saved ? JSON.parse(saved) : INITIAL_PATIENTS;
    } catch {
      return INITIAL_PATIENTS;
    }
  });

  const [prescriptions, setPrescriptions] = useState<Prescription[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRESCRIPTIONS);
      return saved ? JSON.parse(saved) : INITIAL_PRESCRIPTIONS;
    } catch {
      return INITIAL_PRESCRIPTIONS;
    }
  });

  const [reviews, setReviews] = useState<PatientReview[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REVIEWS);
      return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
      return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  const [cloudSnapshots, setCloudSnapshots] = useState<CloudBackupSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
      return saved ? JSON.parse(saved) : [
        {
          id: 'SNAP-INIT-01',
          timestamp: new Date().toISOString(),
          sizeBytes: 18450,
          recordsCount: 12,
          checksum: 'CS-48A190',
          note: 'স্বয়ংক্রিয় প্রারম্ভিক ক্লাউড ব্যাকআপ স্ন্যাপশট'
        }
      ];
    } catch {
      return [];
    }
  });

  const [syncQueue, setSyncQueue] = useState<SyncQueueItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SYNC_QUEUE);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // App statuses
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine ?? true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string>(() => new Date().toLocaleTimeString('bn-BD'));
  
  const [isMasterAuthenticated, setIsMasterAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(STORAGE_KEYS.AUTH) === 'AUTHENTICATED';
    } catch {
      return false;
    }
  });
  const [isTwoFactorVerified, setIsTwoFactorVerified] = useState<boolean>(false);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.DARK_MODE) === 'true';
    } catch {
      return false;
    }
  });

  const [currentView, setCurrentView] = useState<'frontend' | 'wp-admin'>('frontend');
  const [adminSubTab, setAdminSubTab] = useState<string>('dashboard');

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState<Doctor | null>(null);
  const [isPrescriptionLookupOpen, setIsPrescriptionLookupOpen] = useState(false);
  const [activeLookupCodeOrPhone, setActiveLookupCodeOrPhone] = useState('');
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [selectedPrescriptionForView, setSelectedPrescriptionForView] = useState<Prescription | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ADMIN_PROFILE, JSON.stringify(adminProfile));
    } catch (e) { console.error(e); }
  }, [adminProfile]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) { console.error(e); }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify(doctors));
    } catch (e) { console.error(e); }
  }, [doctors]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
    } catch (e) { console.error(e); }
  }, [appointments]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
    } catch (e) { console.error(e); }
  }, [patients]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(prescriptions));
    } catch (e) { console.error(e); }
  }, [prescriptions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
    } catch (e) { console.error(e); }
  }, [reviews]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(auditLogs));
    } catch (e) { console.error(e); }
  }, [auditLogs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(cloudSnapshots));
    } catch (e) { console.error(e); }
  }, [cloudSnapshots]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SYNC_QUEUE, JSON.stringify(syncQueue));
    } catch (e) { console.error(e); }
  }, [syncQueue]);

  // Dark Mode class toggle on <html>
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem(STORAGE_KEYS.DARK_MODE, 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem(STORAGE_KEYS.DARK_MODE, 'false');
    }
  }, [isDarkMode]);

  // Online / Offline listener
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      logAction('নেটওয়ার্ক সংযোগ পুনঃস্থাপিত', 'সিস্টেম পুনরায় অনলাইন মোডে ফিরে এসেছে এবং ডাটা সিঙ্ক প্রক্রিয়া শুরু হয়েছে।', 'info');
      // Drain sync queue
      if (syncQueue.length > 0) {
        setIsSyncing(true);
        setTimeout(() => {
          setSyncQueue([]);
          setIsSyncing(false);
          setLastSyncedAt(new Date().toLocaleTimeString('bn-BD'));
          logAction('অফলাইন ডাটা সিঙ্ক সম্পন্ন', `${syncQueue.length}টি অফলাইন কার্যক্রম ক্লাউড ডাটাবেসের সাথে সমন্বিত হয়েছে।`, 'success');
        }, 1200);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      logAction('অফলাইন মোড সক্রিয়', 'ইন্টারনেট বিচ্ছিন্ন। সকল ডাটা স্থানীয় স্টোরেজে নিরাপদে সংরক্ষিত হচ্ছে।', 'warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Keyboard shortcut: Ctrl + K or Cmd + K for global search
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [syncQueue]);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  const logAction = (action: string, details: string, severity: AuditLog['severity'] = 'info') => {
    const newLog: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
      action,
      details,
      timestamp: new Date().toLocaleString('bn-BD'),
      user: isMasterAuthenticated ? `${adminProfile.name} (${adminProfile.username})` : 'ভিজিটর / রোগী',
      ip: isOnline ? '103.114.98.22' : 'অফলাইন লোকালহোস্ট',
      severity
    };
    setAuditLogs((prev) => [newLog, ...prev.slice(0, 499)]); // keep last 500 logs
  };

  const verifyMasterLogin = (code: string, otp?: string): { success: boolean; message: string; requires2FA?: boolean } => {
    if (!verifyMasterSecurityCode(code, adminProfile.masterSecurityCode)) {
      logAction('ব্যর্থ এডমিন লগইন চেষ্টা', 'ভুল সিকিউরিটি কোড প্রবেশ করানো হয়েছে। অ্যাক্সেস প্রত্যাখ্যাত।', 'warning');
      return { success: false, message: 'ভুল মাস্টার সিকিউরিটি কোড! সঠিক অনুমোদিত কোড প্রবেশ করান।' };
    }

    // Check if 2FA is active
    if (settings.twoFactorEnabled && !otp) {
      return { success: false, message: 'টু-ফ্যাক্টর অথেনটিকেশন (2FA) ওটিপি কোড প্রদান করুন।', requires2FA: true };
    }

    if (settings.twoFactorEnabled && otp) {
      if (!verify2FACode(otp, adminProfile.twoFactorPin)) {
        logAction('ব্যর্থ 2FA ভেরিফিকেশন', 'ভুল ওটিপি কোড প্রদান করা হয়েছে।', 'warning');
        return { success: false, message: 'ভুল 2FA ওটিপি কোড! পুনরায় চেষ্টা করুন।' };
      }
      setIsTwoFactorVerified(true);
    }

    setIsMasterAuthenticated(true);
    try {
      sessionStorage.setItem(STORAGE_KEYS.AUTH, 'AUTHENTICATED');
    } catch {}

    logAction('সফল মাস্টার এডমিন লগইন', 'মাস্টার সিকিউরিটি কোড দিয়ে ওয়ার্ডপ্রেস চেম্বার এডমিন প্যানেলে সফলভাবে প্রবেশ করা হয়েছে।', 'security');
    return { success: true, message: 'সফলভাবে লগইন হয়েছে! ওয়ার্ডপ্রেস ড্যাশবোর্ডে স্বাগতম।' };
  };

  const logoutMaster = () => {
    setIsMasterAuthenticated(false);
    setIsTwoFactorVerified(false);
    try {
      sessionStorage.removeItem(STORAGE_KEYS.AUTH);
    } catch {}
    logAction('এডমিন লগআউট', 'মাস্টার এডমিন প্যানেল থেকে সফলভাবে লগআউট করা হয়েছে।', 'info');
    setCurrentView('frontend');
  };

  // Appointment Booking
  const bookAppointment = (data: Omit<Appointment, 'id' | 'tokenNumber' | 'createdAt' | 'status'>): Appointment => {
    const todayTokens = appointments
      .filter((a) => a.date === data.date)
      .map((a) => a.tokenNumber);
    const nextToken = todayTokens.length > 0 ? Math.max(...todayTokens) + 1 : 101;

    const newAppointment: Appointment = {
      ...data,
      id: 'apt-' + Date.now(),
      tokenNumber: nextToken,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    setAppointments((prev) => [newAppointment, ...prev]);

    // Check if patient already exists or create new patient record
    setPatients((prev) => {
      const existing = prev.find((p) => p.phone === data.phone);
      if (existing) {
        return prev.map((p) =>
          p.id === existing.id
            ? {
                ...p,
                totalVisits: p.totalVisits + 1,
                lastVisitDate: data.date,
                chronicConditions: Array.from(new Set([...p.chronicConditions, data.symptoms.slice(0, 30)]))
              }
            : p
        );
      } else {
        const newPat: Patient = {
          id: 'pat-' + Date.now(),
          name: data.patientName,
          phone: data.phone,
          age: data.patientAge,
          gender: data.patientGender,
          address: data.address || 'চেম্বার ভিজিটর',
          firstVisitDate: data.date,
          lastVisitDate: data.date,
          totalVisits: 1,
          chronicConditions: [data.symptoms.slice(0, 30)],
          totalPrescriptions: 0
        };
        return [newPat, ...prev];
      }
    });

    // Offline queue tracking
    if (!isOnline) {
      setSyncQueue((prev) => [
        ...prev,
        {
          id: 'sq-' + Date.now(),
          action: 'create',
          entity: 'appointment',
          data: newAppointment,
          timestamp: new Date().toISOString(),
          synced: false
        }
      ]);
    }

    logAction('নতুন অ্যাপয়েন্টমেন্ট বুকিং', `রোগী: ${data.patientName}, টোকেন: #${nextToken}, ডাক্তার: ${data.doctorName}`, 'success');
    return newAppointment;
  };

  const updateAppointmentStatus = (id: string, status: Appointment['status']) => {
    setAppointments((prev) =>
      prev.map((apt) => (apt.id === id ? { ...apt, status } : apt))
    );
    logAction('অ্যাপয়েন্টমেন্ট স্ট্যাটাস পরিবর্তন', `আইডি: ${id} এর স্ট্যাটাস পরিবর্তিত হয়ে '${status}' হয়েছে।`, 'info');
  };

  const updateAppointment = (id: string, updatedData: Partial<Appointment>) => {
    setAppointments((prev) =>
      prev.map((apt) => (apt.id === id ? { ...apt, ...updatedData } : apt))
    );
    const target = appointments.find((a) => a.id === id);
    logAction(
      'অ্যাপয়েন্টমেন্ট তথ্য আপডেট',
      `রোগী: ${updatedData.patientName || target?.patientName || id} এর অ্যাপয়েন্টমেন্ট তথ্য সফলভাবে পরিবর্তন করা হয়েছে।`,
      'info'
    );
  };

  const deleteAppointment = (id: string) => {
    const target = appointments.find((a) => a.id === id);
    setAppointments((prev) => prev.filter((a) => a.id !== id));
    logAction(
      'অ্যাপয়েন্টমেন্ট অপসারণ',
      `টোকেন: #${target?.tokenNumber || id}, রোগী: ${target?.patientName || 'রোগী'} এর সিরিয়াল সফলভাবে মুছে ফেলা হয়েছে।`,
      'warning'
    );
  };

  // Prescription creation
  const addPrescription = (data: Omit<Prescription, 'id' | 'createdAt'>): Prescription => {
    const rxCode = data.prescriptionCode || `RX-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    const newRx: Prescription = {
      ...data,
      prescriptionCode: rxCode,
      id: 'rx-' + Date.now(),
      createdAt: new Date().toISOString()
    };

    setPrescriptions((prev) => [newRx, ...prev]);

    // Link prescription to appointment if applicable
    if (data.appointmentId) {
      setAppointments((prev) =>
        prev.map((apt) =>
          apt.id === data.appointmentId
            ? { ...apt, status: 'completed', prescriptionId: newRx.id }
            : apt
        )
      );
    }

    // Update patient prescription count
    setPatients((prev) =>
      prev.map((pat) =>
        pat.phone === data.patientPhone
          ? { ...pat, totalPrescriptions: pat.totalPrescriptions + 1, lastVisitDate: data.date }
          : pat
      )
    );

    logAction('নতুন প্রেসক্রিপশন তৈরি', `প্রেসক্রিপশন কোড: ${rxCode}, রোগী: ${data.patientName}, চিকিৎসক: ${data.doctorName}`, 'success');
    return newRx;
  };

  const updatePrescription = (id: string, updatedData: Partial<Prescription>) => {
    setPrescriptions((prev) =>
      prev.map((rx) => (rx.id === id ? { ...rx, ...updatedData } : rx))
    );
    logAction(
      'প্রেসক্রিপশন ও পথ্য আপডেট',
      `আইডি: ${id}, রোগী: ${updatedData.patientName || 'রোগী'} এর প্রেসক্রিপশন ও পথ্য-নির্দেশনা সফলভাবে আপডেট করা হয়েছে।`,
      'info'
    );
  };

  const deletePrescription = (id: string) => {
    const target = prescriptions.find((rx) => rx.id === id);
    setPrescriptions((prev) => prev.filter((rx) => rx.id !== id));
    logAction(
      'প্রেসক্রিপশন মুছে ফেলা হয়েছে',
      `প্রেসক্রিপশন কোড: ${target?.prescriptionCode || id}, রোগী: ${target?.patientName || 'রোগী'} এর প্রেসক্রিপশন সফলভাবে অপসারণ করা হয়েছে।`,
      'warning'
    );
  };

  const addPatient = (data: Omit<Patient, 'id' | 'firstVisitDate' | 'lastVisitDate' | 'totalVisits' | 'totalPrescriptions'>): Patient => {
    const today = new Date().toISOString().split('T')[0];
    const newPat: Patient = {
      ...data,
      id: 'pat-' + Date.now(),
      firstVisitDate: today,
      lastVisitDate: today,
      totalVisits: 1,
      totalPrescriptions: 0
    };
    setPatients((prev) => [newPat, ...prev]);
    logAction('নতুন রোগী নিবন্ধন', `নাম: ${data.name}, মোবাইল: ${data.phone}`, 'info');
    return newPat;
  };

  const updatePatient = (id: string, updatedData: Partial<Patient>) => {
    setPatients((prev) =>
      prev.map((pat) => (pat.id === id ? { ...pat, ...updatedData } : pat))
    );
    const patName = updatedData.name || patients.find((p) => p.id === id)?.name || 'রোগী';
    logAction(
      'রোগীর তথ্য ও মেডিকেল রেকর্ড আপডেট',
      `রোগী ${patName} (আইডি: ${id}) এর ডাটাবেজ তথ্য সফলভাবে এডিট ও হালনাগাদ করা হয়েছে।`,
      'info'
    );
  };

  const deletePatient = (id: string) => {
    const targetPat = patients.find((p) => p.id === id);
    setPatients((prev) => prev.filter((p) => p.id !== id));
    logAction(
      'রোগী ডাটাবেজ থেকে মুছে ফেলা হয়েছে',
      `রোগী: ${targetPat ? targetPat.name : id} এর রেকর্ড ডাটাবেজ থেকে অপসারণ করা হয়েছে।`,
      'warning'
    );
  };

  const addReview = (data: Omit<PatientReview, 'id'>): PatientReview => {
    const newRev: PatientReview = {
      ...data,
      id: 'rev-' + Date.now()
    };
    setReviews((prev) => [newRev, ...prev]);
    logAction('নতুন রোগী রিভিউ যুক্ত', `রোগী: ${data.name}, রেটিং: ${data.rating}★`, 'info');
    return newRev;
  };

  const updateReview = (id: string, updatedData: Partial<PatientReview>) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? { ...r, ...updatedData } : r))
    );
    logAction(
      'রোগী রিভিউ সম্পাদনা',
      `রিভিউ আইডি: ${id}, রোগী: ${updatedData.name || 'রোগী'} এর রেটিং ও মন্তব্য সফলভাবে আপডেট করা হয়েছে।`,
      'info'
    );
  };

  const deleteReview = (id: string) => {
    const target = reviews.find((r) => r.id === id);
    setReviews((prev) => prev.filter((r) => r.id !== id));
    logAction(
      'রোগী রিভিউ অপসারণ',
      `রিভিউ আইডি: ${id}, রোগী: ${target?.name || 'রোগী'} এর রিভিউ মুছে ফেলা হয়েছে।`,
      'warning'
    );
  };

  const updateChamberSettings = (newSettings: Partial<ChamberSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      logAction('চেম্বার সেটিংস আপডেট', 'অ্যাডমিন প্যানেল থেকে চেম্বারের তথ্য ও কনফিগারেশন পরিবর্তন করা হয়েছে।', 'info');
      return updated;
    });
  };

  const updateAdminProfile = (newProfile: Partial<AdminAccountProfile>) => {
    setAdminProfile((prev) => {
      const updated = { ...prev, ...newProfile };
      // Sync Dr. Sumon's entry in doctors array
      setDoctors((prevDocs) =>
        prevDocs.map((doc, idx) =>
          idx === 0
            ? {
                ...doc,
                name: updated.name || doc.name,
                phone: updated.phone || doc.phone,
                email: updated.email || doc.email,
                qualification: updated.qualifications || doc.qualification,
                designation: updated.designation || doc.designation,
                avatar: updated.avatarUrl || doc.avatar,
                bio: updated.bio || doc.bio
              }
            : doc
        )
      );
      logAction('অ্যাডমিন অ্যাকাউন্ট সেটিংস আপডেট', 'অ্যাডমিন প্রোফাইল ও অ্যাকাউন্ট তথ্য পরিবর্তন করা হয়েছে।', 'security');
      return updated;
    });
  };

  const updateDoctor = (id: string, updatedData: Partial<Doctor>) => {
    setDoctors((prev) =>
      prev.map((doc) => (doc.id === id ? { ...doc, ...updatedData } : doc))
    );
    // If the updated doctor is the first doctor (or matching admin email), sync with adminProfile
    if (doctors.length > 0 && doctors[0].id === id) {
      setAdminProfile((prev) => ({
        ...prev,
        name: updatedData.name || prev.name,
        phone: updatedData.phone || prev.phone,
        email: updatedData.email || prev.email,
        qualifications: updatedData.qualification || prev.qualifications,
        designation: updatedData.designation || prev.designation,
        avatarUrl: updatedData.avatar || prev.avatarUrl,
        bio: updatedData.bio || prev.bio
      }));
    }
    const docName = updatedData.name || doctors.find((d) => d.id === id)?.name || id;
    logAction(
      'চিকিৎসক প্রোফাইল আপডেট',
      `ডাক্তার ${docName}-এর প্রোফাইল, ডিগ্রি, ভিজিটিং সময় ও ফি তথ্য আপডেট করা হয়েছে।`,
      'info'
    );
  };

  const addDoctor = (doctorData: Omit<Doctor, 'id'>): Doctor => {
    const newDoc: Doctor = {
      ...doctorData,
      id: 'doc-' + Date.now()
    };
    setDoctors((prev) => [...prev, newDoc]);
    logAction(
      'নতুন চিকিৎসক যোগ',
      `ডাক্তার ${newDoc.name} (${newDoc.designation}) সফলভাবে চিকিৎসক প্যানেলে যুক্ত হয়েছেন।`,
      'success'
    );
    return newDoc;
  };

  const deleteDoctor = (id: string) => {
    const targetDoc = doctors.find((d) => d.id === id);
    if (doctors.length <= 1) {
      logAction('চিকিৎসক অপসরণ ব্যর্থ', 'চেম্বারে কমপক্ষে একজন চিকিৎসক থাকা আবশ্যক।', 'warning');
      return;
    }
    setDoctors((prev) => prev.filter((d) => d.id !== id));
    logAction(
      'চিকিৎসক অপসারণ',
      `ডাক্তার ${targetDoc?.name || id}-কে প্যানেল থেকে সফলভাবে অপসারণ করা হয়েছে।`,
      'warning'
    );
  };

  // JSON Export / Backup
  const exportJsonBackup = (encrypt: boolean = false): string => {
    const payload = {
      exportDate: new Date().toISOString(),
      version: '1.0.4',
      system: 'HomeoCare Clinic WordPress Engine',
      settings,
      doctors,
      appointments,
      patients,
      prescriptions,
      reviews,
      auditLogs: auditLogs.slice(0, 100),
      isEncrypted: encrypt
    };

    let content = '';
    if (encrypt) {
      content = encryptPayload(payload);
    } else {
      content = JSON.stringify(payload, null, 2);
    }

    logAction('ডাটাবেস ব্যাকআপ এক্সপোর্ট (.json)', `সর্বমোট ${appointments.length} অ্যাপয়েন্টমেন্ট ও ${prescriptions.length} প্রেসক্রিপশন এক্সপোর্ট করা হয়েছে।`, 'info');
    return content;
  };

  // JSON Import / Restore
  const importJsonBackup = (jsonContent: string): { success: boolean; message: string } => {
    try {
      let data: any = null;
      try {
        data = JSON.parse(jsonContent);
      } catch {
        // Try decrypting if it was exported encrypted
        data = decryptPayload(jsonContent);
      }

      if (!data || (!data.appointments && !data.prescriptions && !data.settings)) {
        return { success: false, message: 'অবৈধ ফাইল ফরম্যাট! সঠিক হোমিও আরোগ্য নিকেতন ব্যাকআপ .json ফাইল নির্বাচন করুন।' };
      }

      if (data.settings) setSettings(data.settings);
      if (Array.isArray(data.doctors)) setDoctors(data.doctors);
      if (Array.isArray(data.appointments)) setAppointments(data.appointments);
      if (Array.isArray(data.patients)) setPatients(data.patients);
      if (Array.isArray(data.prescriptions)) setPrescriptions(data.prescriptions);
      if (Array.isArray(data.reviews)) setReviews(data.reviews);

      logAction('ডাটাবেস রিস্টোর সম্পন্ন', 'বাহ্যিক .json ব্যাকআপ ফাইল থেকে সকল ডাটা সফলভাবে রিস্টোর ও সক্রিয় করা হয়েছে।', 'security');
      return { success: true, message: 'অভিনন্দন! সফলভাবে সকল ডাটাবেস রেকর্ড রিস্টোর করা হয়েছে।' };
    } catch (err: any) {
      return { success: false, message: 'ফাইল প্রসেসিং ত্রুটি: ' + err?.message };
    }
  };

  // Cloud Backup Simulation
  const triggerCloudBackup = async (): Promise<{ success: boolean; message: string }> => {
    setIsSyncing(true);
    const dataStr = JSON.stringify({ settings, appointments, prescriptions, patients, reviews });
    const checksum = calculateChecksum(dataStr);
    const newSnapshot: CloudBackupSnapshot = {
      id: `SNAP-${Date.now()}`,
      timestamp: new Date().toLocaleString('bn-BD'),
      sizeBytes: new Blob([dataStr]).size,
      recordsCount: appointments.length + prescriptions.length + patients.length,
      checksum,
      note: 'এনক্রিপ্টেড ক্লাউড স্টোরেজ স্ন্যাপশট'
    };

    try {
      await fetch('/api/cloud-backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: dataStr, timestamp: newSnapshot.timestamp })
      }).catch(() => {});
    } catch {}

    setCloudSnapshots((prev) => [newSnapshot, ...prev]);
    setIsSyncing(false);
    setLastSyncedAt(new Date().toLocaleTimeString('bn-BD'));
    logAction('ক্লাউড ব্যাকআপ তৈরি', `চেকসাম: ${checksum}, মোট রেকর্ড: ${newSnapshot.recordsCount}`, 'success');
    return { success: true, message: 'ক্লাউড স্টোরেজে সফলভাবে এনক্রিপ্টেড ব্যাকআপ সংরক্ষিত হয়েছে।' };
  };

  const restoreCloudSnapshot = (snapshotId: string) => {
    const snap = cloudSnapshots.find((s) => s.id === snapshotId);
    if (snap) {
      logAction('ক্লাউড স্ন্যাপশট রিস্টোর', `স্ন্যাপশট ${snapshotId} থেকে ডাটাবেস পুনঃস্থাপন করা হয়েছে।`, 'security');
    }
  };

  // Database Optimization & Cache
  const optimizeDatabase = () => {
    // Clean up expired items, prune redundant logs
    const initialSize = JSON.stringify({ appointments, prescriptions, patients, auditLogs }).length;
    setAuditLogs((prev) => prev.slice(0, 150));
    const freedBytes = Math.max(0, initialSize - JSON.stringify({ appointments, prescriptions, patients }).length + 2048);
    logAction('ডাটাবেজ অপ্টিমাইজেশন', `লোকাল স্টোরেজ ইনডেক্স কম্প্যাক্ট করা হয়েছে। মেমোরি ফ্রি: ${(freedBytes / 1024).toFixed(1)} KB`, 'info');
    return { freedBytes, message: `ডাটাবেজ ও ইনডেক্স সফলভাবে অপ্টিমাইজ হয়েছে! ${(freedBytes / 1024).toFixed(1)} KB মেমোরি স্পেস সাশ্রয় হয়েছে।` };
  };

  const clearCache = () => {
    logAction('ক্যাশ মেমোরি ফ্ল্যাশ', 'ব্রাউজার ভিউ ও রেন্ডার ক্যাশ সফলভাবে ক্লিয়ার করা হয়েছে।', 'info');
  };

  const triggerManualSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setSyncQueue([]);
      setIsSyncing(false);
      setLastSyncedAt(new Date().toLocaleTimeString('bn-BD'));
      logAction('ম্যানুয়াল ডাটা সিঙ্ক সম্পন্ন', 'সকল স্থানীয় এবং ক্লাউড রেকর্ড সমন্বিত হয়েছে।', 'success');
    }, 800);
  };

  return (
    <ClinicContext.Provider
      value={{
        doctors,
        settings,
        adminProfile,
        updateAdminProfile,
        appointments,
        patients,
        prescriptions,
        reviews,
        auditLogs,
        cloudSnapshots,
        syncQueue,
        isOnline,
        isSyncing,
        lastSyncedAt,
        isMasterAuthenticated,
        isTwoFactorVerified,
        isDarkMode,
        currentView,
        adminSubTab,
        isSearchOpen,
        setIsSearchOpen,
        isLoginModalOpen,
        setIsLoginModalOpen,
        isBookingModalOpen,
        setIsBookingModalOpen,
        selectedDoctorForBooking,
        setSelectedDoctorForBooking,
        isPrescriptionLookupOpen,
        setIsPrescriptionLookupOpen,
        activeLookupCodeOrPhone,
        setActiveLookupCodeOrPhone,
        isChatbotOpen,
        setIsChatbotOpen,
        selectedPrescriptionForView,
        setSelectedPrescriptionForView,
        setCurrentView,
        setAdminSubTab,
        toggleDarkMode,
        verifyMasterLogin,
        logoutMaster,
        bookAppointment,
        updateAppointment,
        deleteAppointment,
        updateAppointmentStatus,
        addPrescription,
        updatePrescription,
        deletePrescription,
        updateChamberSettings,
        updateDoctor,
        addDoctor,
        deleteDoctor,
        addPatient,
        updatePatient,
        deletePatient,
        addReview,
        updateReview,
        deleteReview,
        exportJsonBackup,
        importJsonBackup,
        triggerCloudBackup,
        restoreCloudSnapshot,
        optimizeDatabase,
        clearCache,
        logAction,
        addAuditLog: logAction,
        triggerManualSync
      }}
    >
      {children}
    </ClinicContext.Provider>
  );
};

export const useClinic = () => {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within a ClinicProvider');
  }
  return context;
};
