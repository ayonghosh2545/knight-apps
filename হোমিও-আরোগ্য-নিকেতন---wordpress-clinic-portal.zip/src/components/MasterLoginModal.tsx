import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Lock,
  X,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  Eye,
  EyeOff,
  ArrowRight,
  UserCheck
} from 'lucide-react';

export const MasterLoginModal: React.FC = () => {
  const {
    isLoginModalOpen,
    setIsLoginModalOpen,
    verifyMasterLogin,
    setCurrentView,
    settings
  } = useClinic();

  const [username, setUsername] = useState('admin');
  const [securityCode, setSecurityCode] = useState('');
  const [twoFactorOtp, setTwoFactorOtp] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [requires2FA, setRequires2FA] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isLoginModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    const result = verifyMasterLogin(securityCode, requires2FA ? twoFactorOtp : undefined);

    if (result.success) {
      setIsLoginModalOpen(false);
      setSecurityCode('');
      setTwoFactorOtp('');
      setCurrentView('wp-admin');
    } else {
      if (result.requires2FA) {
        setRequires2FA(true);
      }
      setErrorMessage(result.message);
    }

    setIsSubmitting(false);
  };

  const handleClose = () => {
    setErrorMessage('');
    setSecurityCode('');
    setTwoFactorOtp('');
    setRequires2FA(false);
    setIsLoginModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#f0f0f1] dark:bg-[#1a2024] rounded-2xl max-w-md w-full shadow-2xl border border-gray-300 dark:border-gray-700 overflow-hidden text-gray-900 dark:text-white">
        
        {/* Top WordPress Icon Header */}
        <div className="bg-[#1d2327] p-6 text-center relative border-b border-gray-800">
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-full bg-white text-[#1d2327] font-serif font-black flex items-center justify-center text-3xl mx-auto shadow-lg mb-3">
            W
          </div>

          <h3 className="text-xl font-bold text-white tracking-tight">
            হোমিও আরোগ্য নিকেতন
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            ওয়ার্ডপ্রেস মাস্টার এডমিন অথেন্টিকেশন
          </p>
        </div>

        {/* Login Form Body */}
        <div className="p-6 sm:p-8">
          
          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs flex items-start space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username Input */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                ব্যবহারকারীর নাম (Username)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#2271b1] transition"
                />
              </div>
            </div>

            {/* Master Security Code (Secret Password) */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                  মাস্টার সিকিউরিটি কোড *
                </label>
              </div>

              <div className="relative">
                <input
                  type={showCode ? 'text' : 'password'}
                  placeholder="সিকিউরিটি কোড লিখুন"
                  value={securityCode}
                  onChange={(e) => setSecurityCode(e.target.value)}
                  required
                  autoFocus
                  className="w-full px-3.5 py-2.5 pr-10 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#2271b1] font-mono tracking-wider transition"
                />
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* 2FA OTP Code (Only if active or requested) */}
            {(requires2FA || settings.twoFactorEnabled) && (
              <div className="pt-1">
                <label className="block text-xs font-bold text-emerald-700 dark:text-emerald-400 mb-1.5 flex items-center space-x-1.5">
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>টু-ফ্যাক্টর অথেনটিকেশন (2FA ওটিপি কোড) *</span>
                </label>
                <input
                  type="text"
                  placeholder="৬-সংখ্যার কোড (যেমন: 540540)"
                  value={twoFactorOtp}
                  onChange={(e) => setTwoFactorOtp(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-emerald-400 dark:border-emerald-700 bg-emerald-50/50 dark:bg-emerald-950/20 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono tracking-widest text-center"
                />
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-xl shadow-md transition flex items-center justify-center space-x-2 text-sm"
              >
                <Lock className="w-4 h-4" />
                <span>ওয়ার্ডপ্রেস অ্যাডমিন প্যানেলে প্রবেশ</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </form>

          {/* Security Notice Footer */}
          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-800 text-[11px] text-gray-500 dark:text-gray-400 text-center flex items-center justify-center space-x-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>সকল এক্সেস এন্ড-টু-এন্ড এনক্রিপ্টেড এবং অডিট ট্রেইলে সংরক্ষিত।</span>
          </div>

        </div>

      </div>
    </div>
  );
};
