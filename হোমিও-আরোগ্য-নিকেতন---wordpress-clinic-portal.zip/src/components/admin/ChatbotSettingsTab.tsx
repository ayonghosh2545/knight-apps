import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { ChatbotConfig, ChatbotQnA } from '../../types.ts';
import { 
  Bot, Save, Plus, Trash2, Edit2, RotateCcw, CheckCircle, 
  HelpCircle, MessageSquare, Sparkles, Check, X, ShieldAlert,
  Send, Eye
} from 'lucide-react';

export const ChatbotSettingsTab: React.FC = () => {
  const { settings, updateChamberSettings, addAuditLog, isMasterAuthenticated } = useClinic();

  const defaultConfig: ChatbotConfig = {
    botName: 'হোমিও এআই অ্যাসিস্ট্যান্ট',
    botSubtitle: 'জরুরি পরামর্শ ও সাহায্য',
    welcomeMessage: 'আসসালামু আলাইকুম! হোমিও আরোগ্য নিকেতনে আপনাকে স্বাগতম। আপনার শারীরিক সমস্যা বা চেম্বার সংক্রান্ত যে কোনো প্রশ্ন আমাকে করতে পারেন।',
    quickPrompts: [
      'গ্যাস্ট্রিক ও বুকজ্বালা উপশম',
      'চেম্বার খোলা ও ভিজিটিং সময়',
      'শিশুর ঠান্ডা ও টনসিলের চিকিৎসা',
      'ডাক্তার দেখানোর সিরিয়াল নিয়ম'
    ],
    disclaimerText: 'সতর্কতা: এটি প্রাথমিক তথ্য ও সহায়তা নির্দেশিকা। জটিল রোগে অভিজ্ঞ চিকিৎসকের প্রত্যক্ষ পরামর্শ নিন।',
    botEnabled: true,
    bookingCtaText: 'ডাক্তার অ্যাপয়েন্টমেন্ট বুক করুন',
    customQnA: [
      {
        id: 'qna-1',
        keyword: 'সিরিয়াল|বুকিং|অ্যাপয়েন্টমেন্ট|appointment|serial',
        question: 'ডাক্তার দেখানোর সিরিয়াল কীভাবে নিব?',
        answer: 'আপনি সরাসরি উপরের "সিরিয়াল নিন" বাটন অথবা চ্যাটের নিচের "ডাক্তার অ্যাপয়েন্টমেন্ট বুক করুন" বাটনে ক্লিক করে সহজেই সিরিয়াল নিতে পারবেন। চেম্বার হটলাইন: ০১৭৭৫-৯৮৪৫২০।',
        enabled: true
      },
      {
        id: 'qna-2',
        keyword: 'সময়|খোলা|কখন|টাইম|time|schedule',
        question: 'চেম্বার কখন খোলা থাকে?',
        answer: 'চেম্বার শনি থেকে বৃহস্পতি প্রতিদিন সকাল ১০:০০ - দুপুর ১:০০ এবং বিকাল ৫:০০ - রাত ১০:০০ পর্যন্ত খোলা থাকে। শুক্রবার সাপ্তাহিক ছুটি (অনলাইন পোর্টাল সার্বক্ষণিক চালু)।',
        enabled: true
      },
      {
        id: 'qna-3',
        keyword: 'ফি|টাকা|খরচ|fee|cost',
        question: 'ডাক্তারের ভিজিট বা ফি কত?',
        answer: 'প্রথমবার নতুন রোগী পরামর্শ ফি ৭০০ টাকা এবং ফলোআপ ভিজিট ফি ৪০০ টাকা। ওষুধ বাবদ খরচ ব্যবস্থাপত্র অনুযায়ী নির্ধারিত হয়।',
        enabled: true
      },
      {
        id: 'qna-4',
        keyword: 'ঠিকানা|লোকেশন|কোথায়|location|address',
        question: 'চেম্বারের ঠিকানা কোথায়?',
        answer: 'বাড়ি #৪৫, রোড #০৭, সেক্টর #১১, উত্তরা, ঢাকা-১২৩০। উত্তরা আজমপুর বাসস্ট্যান্ড থেকে রিকশায় ৫ মিনিটের পথ।',
        enabled: true
      },
      {
        id: 'qna-5',
        keyword: 'গ্যাস্ট্রিক|বদহজম|বুকজ্বালা|gas|gastric',
        question: 'গ্যাস্ট্রিক বা বুকজ্বালার হোমিও সমাধান কী?',
        answer: 'হোমিওপ্যাথিতে Nux Vomica, Carbo Veg, Robinia পেটের অম্লতা ও গ্যাস্ট্রিকে অত্যন্ত ফলপ্রসূ। ভাজাপোড়া ও কাঁচা পিঁয়াজ পরিহার করে কুসুম গরম পানি পান করুন এবং চিকিৎসকের পরামর্শ নিন।',
        enabled: true
      }
    ]
  };

  const [config, setConfig] = useState<ChatbotConfig>(settings.chatbotConfig || defaultConfig);
  const [newPrompt, setNewPrompt] = useState('');
  const [editingPromptIdx, setEditingPromptIdx] = useState<number | null>(null);
  const [editingPromptText, setEditingPromptText] = useState('');
  
  // Custom Q&A modal state
  const [editingQnA, setEditingQnA] = useState<ChatbotQnA | null>(null);
  const [isQnAModalOpen, setIsQnAModalOpen] = useState(false);
  const [qnaForm, setQnaForm] = useState<{ keyword: string; question: string; answer: string; enabled: boolean }>({
    keyword: '',
    question: '',
    answer: '',
    enabled: true
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testInput, setTestInput] = useState('');
  const [testResponse, setTestResponse] = useState<string | null>(null);

  if (!isMasterAuthenticated) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-8 text-center text-red-700">
        <ShieldAlert className="w-12 h-12 mx-auto mb-3 text-red-500" />
        <h3 className="text-lg font-bold">অনুমতি প্রয়োজন</h3>
        <p className="text-sm mt-1">চ্যাটবট সেটিংস শুধুমাত্র লগইনকৃত সুপার অ্যাডমিনের জন্য উন্মুক্ত।</p>
      </div>
    );
  }

  const handleSave = () => {
    updateChamberSettings({ chatbotConfig: config });
    addAuditLog('চ্যাটবট কনফিগারেশন আপডেট', 'অ্যাডমিন কর্তৃক চ্যাটবটের তথ্য, প্রম্পট ও কাস্টম প্রশ্নোত্তর আপডেট করা হয়েছে।', 'info');
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleReset = () => {
    if (window.confirm('আপনি কি চ্যাটবট সেটিংস ডিফল্ট অবস্থায় ফিরিয়ে নিতে চান?')) {
      setConfig(defaultConfig);
      updateChamberSettings({ chatbotConfig: defaultConfig });
      addAuditLog('চ্যাটবট রিসেট', 'চ্যাটবটের সকল কনফিগারেশন ডিফল্ট অবস্থায় ফিরিয়ে নেওয়া হয়েছে।', 'warning');
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  const handleAddPrompt = () => {
    if (!newPrompt.trim()) return;
    setConfig(prev => ({
      ...prev,
      quickPrompts: [...prev.quickPrompts, newPrompt.trim()]
    }));
    setNewPrompt('');
  };

  const handleRemovePrompt = (index: number) => {
    setConfig(prev => ({
      ...prev,
      quickPrompts: prev.quickPrompts.filter((_, i) => i !== index)
    }));
  };

  const handleSavePromptEdit = (index: number) => {
    if (!editingPromptText.trim()) return;
    setConfig(prev => {
      const updated = [...prev.quickPrompts];
      updated[index] = editingPromptText.trim();
      return { ...prev, quickPrompts: updated };
    });
    setEditingPromptIdx(null);
    setEditingPromptText('');
  };

  const handleOpenAddQnA = () => {
    setEditingQnA(null);
    setQnaForm({ keyword: '', question: '', answer: '', enabled: true });
    setIsQnAModalOpen(true);
  };

  const handleOpenEditQnA = (item: ChatbotQnA) => {
    setEditingQnA(item);
    setQnaForm({
      keyword: item.keyword,
      question: item.question,
      answer: item.answer,
      enabled: item.enabled !== false
    });
    setIsQnAModalOpen(true);
  };

  const handleSaveQnA = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qnaForm.keyword.trim() || !qnaForm.answer.trim()) return;

    if (editingQnA) {
      setConfig(prev => ({
        ...prev,
        customQnA: prev.customQnA.map(q => q.id === editingQnA.id ? {
          ...q,
          keyword: qnaForm.keyword.trim(),
          question: qnaForm.question.trim(),
          answer: qnaForm.answer.trim(),
          enabled: qnaForm.enabled
        } : q)
      }));
    } else {
      const newId = `qna-${Date.now()}`;
      setConfig(prev => ({
        ...prev,
        customQnA: [
          ...prev.customQnA,
          {
            id: newId,
            keyword: qnaForm.keyword.trim(),
            question: qnaForm.question.trim() || qnaForm.keyword.trim(),
            answer: qnaForm.answer.trim(),
            enabled: qnaForm.enabled
          }
        ]
      }));
    }
    setIsQnAModalOpen(false);
  };

  const handleDeleteQnA = (id: string) => {
    if (window.confirm('আপনি কি এই প্রশ্নোত্তর নিয়মটি মুছে ফেলতে চান?')) {
      setConfig(prev => ({
        ...prev,
        customQnA: prev.customQnA.filter(q => q.id !== id)
      }));
    }
  };

  const handleToggleQnA = (id: string) => {
    setConfig(prev => ({
      ...prev,
      customQnA: prev.customQnA.map(q => q.id === id ? { ...q, enabled: !q.enabled } : q)
    }));
  };

  const handleTestChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testInput.trim()) return;

    const lower = testInput.toLowerCase();
    const matched = config.customQnA.find(q => {
      if (q.enabled === false) return false;
      const terms = q.keyword.toLowerCase().split(/[|,]/).map(t => t.trim()).filter(Boolean);
      return terms.some(t => lower.includes(t));
    });

    if (matched) {
      setTestResponse(`[ম্যাচ করেছে: "${matched.question}"]\n\n${matched.answer}`);
    } else {
      setTestResponse('কোনো কাস্টম প্রশ্নোত্তর মেলেনি। সাধারণ ব্যাকএন্ড এআই অথবা চেম্বার প্রাথমিক হেল্পলাইনে পাঠানো হবে।');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white p-6 rounded-2xl shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center text-white">
            <Bot className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              চ্যাটবট কনফিগারেশন ও নিয়ন্ত্রণ প্যানেল
              <span className="text-xs bg-emerald-500/40 text-emerald-100 px-2 py-0.5 rounded-full border border-emerald-400/30">
                AI / Q&A Engine
              </span>
            </h2>
            <p className="text-xs text-emerald-100 mt-0.5">
              চ্যাটবটের নাম, বার্তা, প্রাথমিক সাজেস্টেড প্রশ্ন এবং কাস্টম উত্তরের শব্দ নির্বাচন করুন
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-medium transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            রিসেট
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-xl text-sm font-bold shadow transition transform active:scale-95"
          >
            <Save className="w-4 h-4" />
            পরিবর্তন সংরক্ষণ করুন
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl flex items-center gap-2 text-sm font-medium animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          চ্যাটবটের নতুন তথ্য সফলভাবে সংরক্ষিত ও লাইভ হয়েছে!
        </div>
      )}

      {/* Grid: Settings on left, live tester on right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Main Configuration */}
        <div className="lg:col-span-2 space-y-6">
          {/* Card 1: Basic Bot Identity */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-600" />
                ১. চ্যাটবটের পরিচয় ও মূল সেটিংস
              </h3>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.botEnabled}
                  onChange={(e) => setConfig({ ...config, botEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                <span className="ml-2 text-xs font-semibold text-slate-700">
                  {config.botEnabled ? 'চ্যাটবট সক্রিয়' : 'চ্যাটবট বন্ধ'}
                </span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  চ্যাটবটের নাম
                </label>
                <input
                  type="text"
                  value={config.botName}
                  onChange={(e) => setConfig({ ...config, botName: e.target.value })}
                  placeholder="যেমন: হোমিও এআই অ্যাসিস্ট্যান্ট"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  সাবটাইটেল / পদবী
                </label>
                <input
                  type="text"
                  value={config.botSubtitle}
                  onChange={(e) => setConfig({ ...config, botSubtitle: e.target.value })}
                  placeholder="যেমন: জরুরি পরামর্শ ও সাহায্য"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  স্বাগতম বার্তা (Welcome Message)
                </label>
                <textarea
                  rows={3}
                  value={config.welcomeMessage}
                  onChange={(e) => setConfig({ ...config, welcomeMessage: e.target.value })}
                  placeholder="ব্যবহারকারী চ্যাটবট খুললে প্রথমে এই বার্তাটি দেখবে..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  অ্যাপয়েন্টমেন্ট বাটন লেখা
                </label>
                <input
                  type="text"
                  value={config.bookingCtaText || ''}
                  onChange={(e) => setConfig({ ...config, bookingCtaText: e.target.value })}
                  placeholder="যেমন: ডাক্তার অ্যাপয়েন্টমেন্ট বুক করুন"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  সতর্কতা / ডিসক্লেইমার নোট
                </label>
                <input
                  type="text"
                  value={config.disclaimerText}
                  onChange={(e) => setConfig({ ...config, disclaimerText: e.target.value })}
                  placeholder="মেডিকেল ডিসক্লেইমার..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Card 2: Quick Prompts / Suggested Questions Chips */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-600" />
                  ২. দ্রুত সাজেস্টেড প্রশ্ন (Quick Prompts)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  রোগী চ্যাটবট খোলার পর নিচে যে ক্লিকেবল বাটনগুলো দেখতে পাবে
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {config.quickPrompts.map((prompt, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-medium text-emerald-800"
                >
                  {editingPromptIdx === idx ? (
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        value={editingPromptText}
                        onChange={(e) => setEditingPromptText(e.target.value)}
                        className="px-2 py-0.5 border border-emerald-400 rounded text-xs text-slate-800 focus:outline-none"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSavePromptEdit(idx)}
                        className="p-0.5 text-emerald-700 hover:text-emerald-900"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingPromptIdx(null)}
                        className="p-0.5 text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span>{prompt}</span>
                      <button
                        onClick={() => {
                          setEditingPromptIdx(idx);
                          setEditingPromptText(prompt);
                        }}
                        className="p-0.5 text-emerald-600 hover:text-emerald-900 rounded"
                        title="এডিট করুন"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleRemovePrompt(idx)}
                        className="p-0.5 text-red-500 hover:text-red-700 rounded"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </>
                  )}
                </div>
              ))}
            </div>

            {/* Add prompt input */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={newPrompt}
                onChange={(e) => setNewPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddPrompt())}
                placeholder="নতুন সাজেস্টেড প্রশ্ন লিখুন..."
                className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddPrompt}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition"
              >
                <Plus className="w-3.5 h-3.5" />
                যুক্ত করুন
              </button>
            </div>
          </div>

          {/* Card 3: Custom Q&A Rules (Smart Offline Answers) */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-emerald-600" />
                  ৩. কাস্টম প্রশ্নোত্তর ডাটাবেস (Custom Q&A Rules)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  নির্দিষ্ট শব্দ বা কি-ওয়ার্ড মিললে চ্যাটবট স্বয়ংক্রিয়ভাবে আপনার নির্ধারিত উত্তরটি প্রদান করবে
                </p>
              </div>

              <button
                onClick={handleOpenAddQnA}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm transition"
              >
                <Plus className="w-3.5 h-3.5" />
                নতুন প্রশ্নোত্তর
              </button>
            </div>

            <div className="space-y-3">
              {config.customQnA.map((item) => (
                <div
                  key={item.id}
                  className={`p-4 rounded-xl border transition ${
                    item.enabled !== false
                      ? 'bg-slate-50 border-slate-200 hover:border-emerald-300'
                      : 'bg-slate-100 border-slate-200 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs text-slate-800">
                          {item.question}
                        </span>
                        <span className="text-[11px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-mono">
                          ট্রিগার: {item.keyword}
                        </span>
                        {item.enabled === false && (
                          <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded">
                            নিষ্ক্রিয়
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mt-1 whitespace-pre-line line-clamp-2">
                        {item.answer}
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleToggleQnA(item.id)}
                        className={`text-[11px] px-2 py-1 rounded font-medium border ${
                          item.enabled !== false
                            ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                            : 'bg-slate-200 text-slate-600 border-slate-300'
                        }`}
                        title="সক্রিয়/নিষ্ক্রিয়"
                      >
                        {item.enabled !== false ? 'অন' : 'অফ'}
                      </button>
                      <button
                        onClick={() => handleOpenEditQnA(item)}
                        className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-slate-200 rounded"
                        title="এডিট করুন"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteQnA(item.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Live Preview & Testing Box */}
        <div className="space-y-6">
          <div className="bg-slate-900 text-white rounded-2xl shadow-lg border border-slate-800 overflow-hidden">
            <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
                <h4 className="text-xs font-bold tracking-wide uppercase text-slate-200 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  লাইভ প্রিভিউ
                </h4>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-700 text-emerald-300 font-mono">
                {config.botEnabled ? 'Active' : 'Disabled'}
              </span>
            </div>

            {/* Mock Chat Header */}
            <div className="bg-emerald-800 p-3 text-white flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-xs">
                AI
              </div>
              <div>
                <p className="text-xs font-bold">{config.botName}</p>
                <p className="text-[10px] text-emerald-200">{config.botSubtitle}</p>
              </div>
            </div>

            {/* Mock Chat Body */}
            <div className="p-4 space-y-3 bg-slate-950/70 text-xs text-slate-300 min-h-[220px] max-h-[300px] overflow-y-auto">
              {/* Bot Greeting */}
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-emerald-700 flex-shrink-0 flex items-center justify-center text-[10px] text-white">
                  🤖
                </div>
                <div className="bg-slate-800 p-2.5 rounded-xl rounded-tl-none border border-slate-700 text-slate-200 leading-relaxed max-w-[85%]">
                  {config.welcomeMessage}
                </div>
              </div>

              {/* Suggested chips preview */}
              <div className="pt-2">
                <p className="text-[10px] text-slate-400 mb-1 font-semibold">সাজেস্টেড প্রশ্নসমূহ:</p>
                <div className="flex flex-wrap gap-1">
                  {config.quickPrompts.map((p, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-slate-800 text-[10px] text-emerald-300 rounded border border-emerald-900/50"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>

              {testResponse && (
                <div className="mt-3 p-2.5 bg-emerald-950/80 border border-emerald-800/80 rounded-xl text-emerald-200 whitespace-pre-line text-xs">
                  {testResponse}
                </div>
              )}
            </div>

            {/* Test Input Form */}
            <form onSubmit={handleTestChat} className="p-3 bg-slate-900 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                placeholder="প্রশ্ন বা কি-ওয়ার্ড টেস্ট করুন..."
                className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center justify-center"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* Tips Card */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 space-y-2">
            <h5 className="font-bold flex items-center gap-1.5 text-amber-900">
              💡 কি-ওয়ার্ড ব্যবহারের টিপস
            </h5>
            <p>
              একটি প্রশ্নোত্তরের জন্য একাধিক শব্দ ট্রিগার হিসেবে রাখতে পাইপ (<code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">|</code>) অথবা কমা ব্যবহার করুন।
            </p>
            <p className="font-mono text-[11px] bg-amber-100/70 p-1.5 rounded text-amber-800">
              যেমন: <span className="font-bold">সিরিয়াল|বুকিং|সিরিয়াল|appointment</span>
            </p>
            <p className="text-[11px] text-amber-800">
              রোগী এই শব্দগুলোর যেকোনো একটি লিখলেই আপনার নির্ধারিত কাস্টম উত্তর তৎক্ষণাৎ শো করবে।
            </p>
          </div>
        </div>
      </div>

      {/* Add / Edit Q&A Modal */}
      {isQnAModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="p-4 bg-emerald-700 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <HelpCircle className="w-4 h-4" />
                {editingQnA ? 'প্রশ্নোত্তর সম্পাদনা করুন' : 'নতুন প্রশ্নোত্তর যুক্ত করুন'}
              </h3>
              <button
                onClick={() => setIsQnAModalOpen(false)}
                className="text-emerald-100 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQnA} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ট্রিগার কি-ওয়ার্ডসমূহ (Trigger Keywords) *
                </label>
                <input
                  type="text"
                  required
                  value={qnaForm.keyword}
                  onChange={(e) => setQnaForm({ ...qnaForm, keyword: e.target.value })}
                  placeholder="যেমন: ফি|টাকা|খরচ|fee|cost"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <p className="text-[11px] text-slate-500 mt-0.5">
                  একাধিক শব্দ যোগ করতে মাঝখানে | (পাইপ) চিহ্ন দিন।
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  প্রশ্নের শিরোনাম বা পরিচিতি *
                </label>
                <input
                  type="text"
                  required
                  value={qnaForm.question}
                  onChange={(e) => setQnaForm({ ...qnaForm, question: e.target.value })}
                  placeholder="যেমন: ডাক্তারের ভিজিট বা ফি কত?"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  চ্যাটবটের উত্তর (Detailed Answer) *
                </label>
                <textarea
                  required
                  rows={4}
                  value={qnaForm.answer}
                  onChange={(e) => setQnaForm({ ...qnaForm, answer: e.target.value })}
                  placeholder="রোগীর উক্ত প্রশ্নে চ্যাটবট যে উত্তরটি প্রদান করবে..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="qna-active"
                  checked={qnaForm.enabled}
                  onChange={(e) => setQnaForm({ ...qnaForm, enabled: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <label htmlFor="qna-active" className="text-xs font-medium text-slate-700 cursor-pointer">
                  এই প্রশ্নোত্তরটি সক্রিয় রাখুন
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsQnAModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-lg"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm"
                >
                  {editingQnA ? 'আপডেট করুন' : 'যোগ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
