import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { PatientReview } from '../../types.ts';
import { Star, PlusCircle, Edit3, Trash2, Check, X, MessageSquareQuote, CheckCircle } from 'lucide-react';

export const ReviewsTab: React.FC = () => {
  const { reviews, addReview, updateReview, deleteReview } = useClinic();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<PatientReview | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    location: '',
    condition: '',
    text: '',
    rating: 5,
    date: ''
  });

  const handleOpenAdd = () => {
    setEditingReview(null);
    setFormData({
      name: '',
      location: '',
      condition: '',
      text: '',
      rating: 5,
      date: new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rev: PatientReview) => {
    setEditingReview(rev);
    setFormData({
      name: rev.name,
      location: rev.location,
      condition: rev.condition,
      text: rev.text,
      rating: rev.rating || 5,
      date: rev.date
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.text.trim()) return;

    if (editingReview) {
      updateReview(editingReview.id, {
        name: formData.name.trim(),
        location: formData.location.trim() || 'ঢাকা',
        condition: formData.condition.trim() || 'ক্রনিক স্বাস্থ্য সমস্যা',
        text: formData.text.trim(),
        rating: Number(formData.rating) || 5,
        date: formData.date.trim() || new Date().toLocaleDateString('bn-BD')
      });
    } else {
      addReview({
        name: formData.name.trim(),
        location: formData.location.trim() || 'ঢাকা',
        condition: formData.condition.trim() || 'ক্রনিক স্বাস্থ্য সমস্যা',
        text: formData.text.trim(),
        rating: Number(formData.rating) || 5,
        date: formData.date.trim() || new Date().toLocaleDateString('bn-BD')
      });
    }

    setIsModalOpen(false);
    setEditingReview(null);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`আপনি কি নিশ্চিত যে "${name}"-এর রিভিউটি মুছে ফেলতে চান?`)) {
      deleteReview(id);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-200 dark:border-gray-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span>রোগীদের রিভিউ ও রেটিং ব্যবস্থাপনা (Reviews & Ratings)</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            ওয়েবসাইটে প্রদর্শিত আরোগ্যপ্রাপ্ত রোগীদের অভিজ্ঞতা, স্টার রেটিং ও ফিডব্যাক এডিট ও নিয়ন্ত্রণ করুন।
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1.5 shadow-xs"
        >
          <PlusCircle className="w-4 h-4" />
          <span>নতুন রিভিউ যোগ করুন</span>
        </button>
      </div>

      {/* Reviews Table / Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-200 dark:border-gray-800 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3 border-b border-gray-100 dark:border-gray-800/80 pb-2">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < (rev.rating || 5)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-gray-300 dark:text-gray-600'
                      }`}
                    />
                  ))}
                  <span className="text-xs font-bold text-gray-700 dark:text-gray-300 ml-1">
                    {(rev.rating || 5).toFixed(1)}
                  </span>
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => handleOpenEdit(rev)}
                    className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-md transition"
                    title="এডিট করুন"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(rev.id, rev.name)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-md transition"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded inline-block mb-2">
                রোগ/সমস্যা: {rev.condition}
              </div>

              <p className="text-xs text-gray-700 dark:text-gray-300 italic mb-4 line-clamp-4">
                "{rev.text}"
              </p>
            </div>

            <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-gray-900 dark:text-white block">
                  {rev.name}
                </span>
                <span className="text-[11px] text-gray-500">
                  {rev.location}
                </span>
              </div>
              <span className="text-[10px] text-gray-400 font-mono">
                {rev.date}
              </span>
            </div>

          </div>
        ))}
      </div>

      {reviews.length === 0 && (
        <div className="text-center py-16 bg-white dark:bg-[#1a2024] rounded-xl border border-dashed border-gray-300 dark:border-gray-800">
          <MessageSquareQuote className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300">
            কোনো রিভিউ ডাটা পাওয়া যায়নি
          </h3>
          <p className="text-xs text-gray-500 mt-1 mb-4">
            নতুন রোগীর ফিডব্যাক যুক্ত করতে ওপরের বাটনে ক্লিক করুন।
          </p>
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold"
          >
            প্রথম রিভিউ যোগ করুন
          </button>
        </div>
      )}

      {/* Edit / Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 animate-in fade-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-amber-100 dark:bg-amber-950/80 rounded-lg text-amber-600 dark:text-amber-400">
                  <Star className="w-5 h-5 fill-amber-500" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    {editingReview ? 'রিভিউ ও রেটিং সম্পাদনা' : 'নতুন রোগী রিভিউ যুক্ত করুন'}
                  </h3>
                  <p className="text-xs text-gray-500">
                    ওয়েবসাইট ও ডাটাবেসে রিয়েল-টাইমে আপডেট হবে
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
              
              {/* Star Rating Selection */}
              <div>
                <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রেটিং নির্বাচন করুন (১-৫ স্টার) *
                </label>
                <div className="flex items-center space-x-2 bg-gray-50 dark:bg-gray-900 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setFormData({ ...formData, rating: star })}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= formData.rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-gray-300 dark:text-gray-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 ml-2">
                    {formData.rating}.০ স্টার রেটিং
                  </span>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রোগীর নাম *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="যেমন: মোঃ হারুনুর রশীদ"
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* Location & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                    ঠিকানা / এলাকা
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="যেমন: উত্তরা সেক্টর ৭, ঢাকা"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                    তারিখ
                  </label>
                  <input
                    type="text"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    placeholder="যেমন: ১২ অক্টোবর, ২০২৬"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Condition */}
              <div>
                <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রোগ বা আরোগ্যপ্রাপ্ত সমস্যা
                </label>
                <input
                  type="text"
                  value={formData.condition}
                  onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                  placeholder="যেমন: ৩ বছরের ক্রনিক একজিমা ও শুষ্ক চর্মরোগ"
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* Text */}
              <div>
                <label className="block font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রোগীর অভিজ্ঞতা ও মন্তব্য *
                </label>
                <textarea
                  rows={3}
                  required
                  value={formData.text}
                  onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                  placeholder="রোগীর চিকিৎসার অভিজ্ঞতা ও ফলাফল বিস্তারিত লিখুন..."
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingReview ? 'হালনাগাদ সংরক্ষণ করুন' : 'রিভিউ যুক্ত করুন'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
