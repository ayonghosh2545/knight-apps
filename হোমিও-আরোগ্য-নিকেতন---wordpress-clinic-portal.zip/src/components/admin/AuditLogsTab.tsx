import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  History,
  Search,
  Download,
  Filter,
  ShieldCheck,
  AlertTriangle,
  Info,
  CheckCircle2,
  Trash2
} from 'lucide-react';

export const AuditLogsTab: React.FC = () => {
  const { auditLogs } = useClinic();

  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.user.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || log.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  const handleExportCSV = () => {
    const headers = ['আইডি', 'তারিখ ও সময়', 'ব্যবহারকারী', 'কার্যক্রম (Action)', 'বিস্তারিত বিবরণ', 'আইপি এড্রেস', 'সিকিউরিটি লেভেল'];
    const rows = filteredLogs.map((log) => [
      `"${log.id}"`,
      `"${log.timestamp}"`,
      `"${log.user}"`,
      `"${log.action}"`,
      `"${log.details.replace(/"/g, '""')}"`,
      `"${log.ip}"`,
      `"${log.severity}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `homeocare-audit-report-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      
      {/* Title & CSV Export */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <History className="w-5 h-5 text-[#2271b1]" />
            <span>অডিট লগ ও বিস্তারিত রিপোর্টিং সিস্টেম (Audit Trail)</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            চেম্বারের প্রতিটি কার্যক্রম, প্রেসক্রিপশন তৈরি, লগইন ও ডাটাবেজ পরিবর্তনের নির্ভুল রেকর্ড।
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
        >
          <Download className="w-4 h-4" />
          <span>অডিট রিপোর্ট ডাউনলোড (CSV Export)</span>
        </button>
      </div>

      {/* Filter Strip */}
      <div className="bg-white dark:bg-[#1a2024] p-4 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap gap-3 items-center flex-1 min-w-[280px]">
          
          <div className="relative flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="কার্যক্রম, বিবরণ বা ব্যবহারকারী দিয়ে খুঁজুন..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
            />
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2" />
          </div>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
          >
            <option value="all">সকল লেভেল</option>
            <option value="success">সফলতা (Success)</option>
            <option value="info">তথ্যমূলক (Info)</option>
            <option value="security">নিরাপত্তা (Security)</option>
            <option value="warning">সতর্কতা (Warning)</option>
          </select>
        </div>

        <span className="text-xs text-gray-500 font-mono">
          মোট রেকর্ড: {filteredLogs.length} টি
        </span>
      </div>

      {/* Logs Table */}
      <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#151a1e] text-gray-600 dark:text-gray-400 font-bold border-b border-gray-300 dark:border-gray-800">
                <th className="p-3">সময় ও তারিখ</th>
                <th className="p-3">লেভেল</th>
                <th className="p-3">কার্যক্রম (Action)</th>
                <th className="p-3">বিস্তারিত বিবরণ</th>
                <th className="p-3">ব্যবহারকারী</th>
                <th className="p-3 font-mono">আইপি এড্রেস</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="p-3 font-mono text-gray-500 whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.severity === 'success'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : log.severity === 'security'
                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                          : log.severity === 'warning'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                      }`}
                    >
                      {log.severity.toUpperCase()}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-gray-900 dark:text-white whitespace-nowrap">
                    {log.action}
                  </td>
                  <td className="p-3 text-gray-600 dark:text-gray-400">
                    {log.details}
                  </td>
                  <td className="p-3 text-gray-700 dark:text-gray-300 whitespace-nowrap">
                    {log.user}
                  </td>
                  <td className="p-3 font-mono text-gray-400 whitespace-nowrap">
                    {log.ip}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
