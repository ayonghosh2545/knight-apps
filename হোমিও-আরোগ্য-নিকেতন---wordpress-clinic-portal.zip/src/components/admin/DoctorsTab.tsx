import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { Doctor } from '../../types.ts';
import {
  UserCheck,
  Stethoscope,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  Clock,
  Phone,
  Mail,
  GraduationCap,
  Award,
  DollarSign,
  Camera,
  Check,
  X,
  Search,
  Sparkles,
  Info,
  ShieldCheck,
  Tag
} from 'lucide-react';

const AVATAR_PRESETS = [
  { label: 'পুরুষ চিকিৎসক ১ (সিনিয়র)', url: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80' },
  { label: 'মহিলা চিকিৎসক ১', url: 'https://images.unsplash.com/photo-1594824813627-2c90c749a177?w=400&auto=format&fit=crop&q=80' },
  { label: 'পুরুষ চিকিৎসক ২ (ক্লাসিকাল)', url: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80' },
  { label: 'মহিলা চিকিৎসক ২', url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80' },
  { label: 'পুরুষ চিকিৎসক ৩ (তরুণ)', url: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80' }
];

const ALL_WEEKDAYS = ['শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার'];

const COMMON_SPECIALTIES = [
  'জটিল ক্রনিক ব্যাধি',
  'হাঁপানি ও এলার্জি',
  'বাত ও মেরুদণ্ডের ব্যথা',
  'পিত্ত ও কিডনি পাথর',
  'একজিমা ও সোরিয়াসিস',
  'গ্যাস্ট্রিক ও আইবিএস',
  'মা ও শিশু রোগ',
  'মহিলাদের হরমোনজনিত সমস্যা',
  'মাইগ্রেন ও নার্ভাস সমস্যা',
  'চুল পড়া ও স্কাল্প সমস্যা'
];

export const DoctorsTab: React.FC = () => {
  const { doctors, updateDoctor, addDoctor, deleteDoctor } = useClinic();

  const [searchQuery, setSearchQuery] = useState('');
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Form states for Add / Edit
  const [formData, setFormData] = useState<Omit<Doctor, 'id'>>({
    name: '',
    qualification: '',
    designation: '',
    specialties: [],
    experienceYears: 10,
    consultationFee: 500,
    followupFee: 300,
    visitingDays: ['শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার'],
    visitingHours: 'বিকাল ৫:০০ - রাত ৯:০০',
    phone: '',
    email: '',
    avatar: AVATAR_PRESETS[0].url,
    bio: ''
  });

  const [newSpecialtyInput, setNewSpecialtyInput] = useState('');

  const filteredDoctors = doctors.filter((doc) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      doc.name.toLowerCase().includes(q) ||
      doc.designation.toLowerCase().includes(q) ||
      doc.qualification.toLowerCase().includes(q) ||
      doc.specialties.some((s) => s.toLowerCase().includes(q))
    );
  });

  const handleStartEdit = (doc: Doctor) => {
    setEditingDoctor(doc);
    setIsAddingNew(false);
    setFormData({
      name: doc.name,
      qualification: doc.qualification,
      designation: doc.designation,
      specialties: [...doc.specialties],
      experienceYears: doc.experienceYears,
      consultationFee: doc.consultationFee,
      followupFee: doc.followupFee,
      visitingDays: [...doc.visitingDays],
      visitingHours: doc.visitingHours,
      phone: doc.phone,
      email: doc.email,
      avatar: doc.avatar,
      bio: doc.bio
    });
  };

  const handleStartAdd = () => {
    setEditingDoctor(null);
    setIsAddingNew(true);
    setFormData({
      name: '',
      qualification: 'BHMS / DHMS, PGT',
      designation: 'কনসালট্যান্ট - ক্লাসিকাল হোমিওপ্যাথি',
      specialties: ['ক্রনিক রোগ', 'চর্ম ও এলার্জি'],
      experienceYears: 5,
      consultationFee: 500,
      followupFee: 300,
      visitingDays: ['শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার'],
      visitingHours: 'বিকাল ৪:০০ - রাত ৮:০০',
      phone: '০১৭০০-০০০০০০',
      email: 'doctor@homeocare.com',
      avatar: AVATAR_PRESETS[0].url,
      bio: 'দীর্ঘদিনের অভিজ্ঞতা সম্পন্ন ক্লাসিকাল হোমিওপ্যাথ।'
    });
  };

  const handleCloseModal = () => {
    setEditingDoctor(null);
    setIsAddingNew(false);
  };

  const handleToggleWeekday = (day: string) => {
    setFormData((prev) => {
      const exists = prev.visitingDays.includes(day);
      const newDays = exists ? prev.visitingDays.filter((d) => d !== day) : [...prev.visitingDays, day];
      return { ...prev, visitingDays: newDays };
    });
  };

  const handleAddSpecialty = (spec: string) => {
    const trimmed = spec.trim();
    if (!trimmed || formData.specialties.includes(trimmed)) return;
    setFormData((prev) => ({ ...prev, specialties: [...prev.specialties, trimmed] }));
    setNewSpecialtyInput('');
  };

  const handleRemoveSpecialty = (spec: string) => {
    setFormData((prev) => ({
      ...prev,
      specialties: prev.specialties.filter((s) => s !== spec)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      setFeedback({ type: 'error', message: 'ডাক্তারের নাম দেওয়া আবশ্যক।' });
      return;
    }
    if (!formData.qualification.trim()) {
      setFeedback({ type: 'error', message: 'শিক্ষাগত যোগ্যতা ও ডিগ্রি প্রদান করুন।' });
      return;
    }

    if (editingDoctor) {
      updateDoctor(editingDoctor.id, formData);
      setFeedback({
        type: 'success',
        message: `ডা. ${formData.name} এর প্রোফাইল সফলভাবে আপডেট করা হয়েছে।`
      });
    } else {
      addDoctor(formData);
      setFeedback({
        type: 'success',
        message: `নতুন চিকিৎসক ডা. ${formData.name} সফলভাবে প্যানেলে যোগ করা হয়েছে।`
      });
    }

    handleCloseModal();
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleDelete = (id: string, name: string) => {
    if (doctors.length <= 1) {
      setFeedback({ type: 'error', message: 'চেম্বারে কমপক্ষে একজন ডাক্তার প্রোফাইল থাকা আবশ্যক।' });
      setTimeout(() => setFeedback(null), 3000);
      return;
    }

    if (confirm(`আপনি কি নিশ্চিত যে ডা. ${name} এর প্রোফাইল অপসারণ করতে চান?`)) {
      deleteDoctor(id);
      setFeedback({ type: 'success', message: `ডা. ${name} প্রোফাইল সফলভাবে অপসারিত হয়েছে।` });
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* WordPress Page Header */}
      <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
              <Stethoscope className="w-6 h-6 text-emerald-600" />
              <span>ডাক্তার প্রোফাইল ও চেম্বার প্যানেল ব্যবস্থাপনা</span>
            </h1>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              মোট: {doctors.length} জন
            </span>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            এখানে চিকিৎসকদের প্রোফাইল, ডিগ্রি, ভিজিটিং সময়সূচী, ফি এবং বিশেষত্বসমূহ এডিট ও সংযোজন করুন। এই তথ্যগুলো সরাসরি ওয়েবসাইটের ফ্রন্টএন্ড এবং প্রেসক্রিপশনে প্রতিফলিত হবে।
          </p>
        </div>

        <button
          onClick={handleStartAdd}
          className="px-4 py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs rounded-lg shadow-sm transition flex items-center space-x-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন চিকিৎসক যোগ করুন</span>
        </button>
      </div>

      {/* Feedback Alert */}
      {feedback && (
        <div
          className={`p-4 rounded-xl border text-xs font-bold flex items-center space-x-2 transition-all ${
            feedback.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
          }`}
        >
          {feedback.type === 'success' ? (
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <Info className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Search and Filter Bar */}
      <div className="bg-white dark:bg-[#1a2024] p-3 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder="ডাক্তারের নাম, পদবী, ডিগ্রি বা বিশেষত্ব দিয়ে খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2" />
        </div>

        <div className="text-xs text-gray-500 font-medium hidden sm:block">
          তালিকাভুক্ত চিকিৎসক: <strong className="text-gray-800 dark:text-gray-200">{filteredDoctors.length}</strong> জন
        </div>
      </div>

      {/* Doctors Grid / Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredDoctors.map((doc, idx) => (
          <div
            key={doc.id}
            className="bg-white dark:bg-[#1a2024] rounded-2xl border border-gray-300 dark:border-gray-800 shadow-xs hover:shadow-md transition overflow-hidden flex flex-col"
          >
            {/* Top Bar of Card */}
            <div className="p-5 pb-3 border-b border-gray-100 dark:border-gray-800 flex items-start justify-between gap-3">
              <div className="flex items-start space-x-3.5">
                <div className="relative shrink-0">
                  <img
                    src={doc.avatar}
                    alt={doc.name}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500/40 shadow-sm"
                  />
                  {idx === 0 && (
                    <span className="absolute -bottom-1 -right-1 bg-amber-500 text-white p-0.5 rounded-full text-[9px]" title="প্রধান চিকিৎসক">
                      <Award className="w-3 h-3" />
                    </span>
                  )}
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="font-bold text-base text-gray-900 dark:text-white">
                      {doc.name}
                    </h3>
                    {idx === 0 && (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded-md">
                        চিফ
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                    {doc.designation}
                  </div>
                  <div className="text-[11px] text-gray-500 mt-1 flex items-center space-x-1">
                    <Award className="w-3.5 h-3.5 text-amber-500" />
                    <span>{doc.experienceYears}+ বছর অভিজ্ঞতা</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => handleStartEdit(doc)}
                  className="px-3 py-1.5 bg-[#2271b1] hover:bg-[#135e96] text-white rounded-lg font-bold text-xs flex items-center space-x-1 transition shadow-2xs"
                  title="এই ডাক্তারের প্রোফাইল সম্পাদনা করুন"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>এডিট করুন</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(doc.id, doc.name)}
                  disabled={doctors.length <= 1}
                  className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition disabled:opacity-30"
                  title="প্রোফাইল মুছে ফেলুন"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Doctor Info Details */}
            <div className="p-5 space-y-3.5 flex-1 text-xs">
              
              {/* Qualifications */}
              <div className="bg-gray-50 dark:bg-[#131b1e] p-2.5 rounded-xl border border-gray-200 dark:border-gray-800 flex items-start space-x-2">
                <GraduationCap className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-gray-700 dark:text-gray-300 text-[11px]">শিক্ষাগত ডিগ্রি ও প্রশিক্ষণ:</div>
                  <div className="text-gray-900 dark:text-white font-medium">{doc.qualification}</div>
                </div>
              </div>

              {/* Schedule and Fees Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div className="bg-blue-50/50 dark:bg-blue-950/20 p-2.5 rounded-xl border border-blue-100 dark:border-blue-900/40">
                  <div className="flex items-center space-x-1 text-blue-900 dark:text-blue-300 font-bold mb-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>সাক্ষাতের সময়:</span>
                  </div>
                  <div className="text-gray-800 dark:text-gray-200 font-medium">{doc.visitingHours}</div>
                  <div className="text-gray-500 mt-1 line-clamp-1">দিন: {doc.visitingDays.join(', ')}</div>
                </div>

                <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-2.5 rounded-xl border border-emerald-100 dark:border-emerald-900/40">
                  <div className="flex items-center space-x-1 text-emerald-900 dark:text-emerald-300 font-bold mb-1">
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>পরামর্শ ও ফলোআপ ফি:</span>
                  </div>
                  <div className="text-emerald-700 dark:text-emerald-400 font-bold font-mono text-sm">
                    ৳{doc.consultationFee} <span className="text-[11px] text-gray-500 font-normal font-sans">(ফলোআপ: ৳{doc.followupFee})</span>
                  </div>
                  <div className="text-gray-500 mt-1">ফোন: {doc.phone}</div>
                </div>
              </div>

              {/* Specialties */}
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                  বিশেষজ্ঞ ক্ষেত্রসমূহ (Specialties):
                </span>
                <div className="flex flex-wrap gap-1">
                  {doc.specialties.map((s, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-md text-[10px] font-medium"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Short Bio */}
              {doc.bio && (
                <div className="text-gray-600 dark:text-gray-400 text-[11px] leading-relaxed line-clamp-2 border-t border-gray-100 dark:border-gray-800 pt-2">
                  {doc.bio}
                </div>
              )}
            </div>

            {/* Bottom Card Footer */}
            <div className="px-5 py-2.5 bg-gray-50 dark:bg-[#151a1e] border-t border-gray-200 dark:border-gray-800 flex items-center justify-between text-[11px] text-gray-500">
              <span className="truncate">ইমেইল: {doc.email}</span>
              <button
                type="button"
                onClick={() => handleStartEdit(doc)}
                className="text-[#2271b1] hover:underline font-bold"
              >
                প্রোফাইল সম্পাদন &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Modal */}
      {(editingDoctor || isAddingNew) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl border border-gray-300 dark:border-gray-800 shadow-2xl max-w-2xl w-full my-auto overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-emerald-800 text-white flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Stethoscope className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base">
                  {editingDoctor ? `ডা. ${editingDoctor.name} এর প্রোফাইল সম্পাদনা` : 'নতুন চিকিৎসক প্রোফাইল যুক্ত করুন'}
                </h3>
              </div>
              <button
                type="button"
                onClick={handleCloseModal}
                className="p-1 hover:bg-emerald-700 rounded-lg text-emerald-200 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
              
              {/* Row 1: Name & Designation */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    চিকিৎসকের পূর্ণ নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="যেমন: ড. সুমন কুমার"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    পদবী ও বিশেষত্ব শিরোনাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.designation}
                    onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                    placeholder="যেমন: চিফ কনসালট্যান্ট ও ক্লাসিকাল হোমিওপ্যাথি গবেষক"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 2: Qualifications & Experience */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    শিক্ষাগত ডিগ্রি ও প্রশিক্ষণসমূহ *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    placeholder="যেমন: BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট), PGT"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    চিকিৎসা অভিজ্ঞতা (বছর)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={formData.experienceYears}
                    onChange={(e) => setFormData({ ...formData, experienceYears: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 3: Visiting Hours & Fees */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    সাক্ষাতের সময়সূচী (Visiting Hours) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.visitingHours}
                    onChange={(e) => setFormData({ ...formData, visitingHours: e.target.value })}
                    placeholder="যেমন: বিকাল ৫:০০ - রাত ৯:৩০"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    নতুন পরামর্শ ফি (৳) *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={formData.consultationFee}
                    onChange={(e) => setFormData({ ...formData, consultationFee: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    ফলোআপ ফি (৳) *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={formData.followupFee}
                    onChange={(e) => setFormData({ ...formData, followupFee: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono"
                  />
                </div>
              </div>

              {/* Visiting Days Checkboxes */}
              <div>
                <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1.5">
                  সাক্ষাতের দিনসমূহ (সপ্তাহের বার নির্বাচন করুন):
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_WEEKDAYS.map((day) => {
                    const isChecked = formData.visitingDays.includes(day);
                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => handleToggleWeekday(day)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold transition border ${
                          isChecked
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-700'
                        }`}
                      >
                        {isChecked ? '✓ ' : ''}{day}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Contact: Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="যেমন: ০১৭১২-৩৪৫৬৭৮"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                    ইমেইল ঠিকানা
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="doctor@example.com"
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Specialties: Chips & Add */}
              <div>
                <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                  বিশেষজ্ঞ ক্ষেত্রসমূহ (Specialties Tags):
                </label>
                
                {/* Active Tags */}
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {formData.specialties.map((spec) => (
                    <span
                      key={spec}
                      className="inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-semibold"
                    >
                      <span>{spec}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveSpecialty(spec)}
                        className="hover:text-rose-600 ml-1"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                {/* Tag Input */}
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newSpecialtyInput}
                    onChange={(e) => setNewSpecialtyInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSpecialty(newSpecialtyInput);
                      }
                    }}
                    placeholder="নতুন ক্ষেত্র লিখুন (যেমন: জটিল পাইলস, পেডিয়াট্রিক) এবং এন্টার দিন..."
                    className="flex-1 px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddSpecialty(newSpecialtyInput)}
                    className="px-3 py-1.5 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-lg font-bold text-xs"
                  >
                    যুক্ত করুন
                  </button>
                </div>

                {/* Preset Suggestions */}
                <div className="mt-2 flex flex-wrap gap-1 items-center text-[10px] text-gray-400">
                  <span>পরামর্শ:</span>
                  {COMMON_SPECIALTIES.slice(0, 6).map((cs) => (
                    <button
                      key={cs}
                      type="button"
                      onClick={() => handleAddSpecialty(cs)}
                      className="hover:text-emerald-600 hover:underline"
                    >
                      +{cs}
                    </button>
                  ))}
                </div>
              </div>

              {/* Avatar Selection & Custom URL */}
              <div className="space-y-2">
                <label className="block font-bold text-gray-800 dark:text-gray-200">
                  চিকিৎসকের প্রোফাইল ছবি (Avatar)
                </label>
                
                <div className="flex items-center space-x-4">
                  <img
                    src={formData.avatar}
                    alt="Preview"
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md shrink-0"
                  />
                  <div className="flex-1">
                    <input
                      type="text"
                      value={formData.avatar}
                      onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                      placeholder="ছবির সরাসরি লিংক (URL) লিখুন..."
                      className="w-full px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-xs font-mono"
                    />
                  </div>
                </div>

                {/* Preset Avatars */}
                <div className="flex items-center space-x-2 pt-1">
                  <span className="text-[10px] text-gray-400">প্রিসেট ছবি:</span>
                  <div className="flex space-x-2">
                    {AVATAR_PRESETS.map((p, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setFormData({ ...formData, avatar: p.url })}
                        className={`w-8 h-8 rounded-lg overflow-hidden border-2 transition ${
                          formData.avatar === p.url ? 'border-emerald-500 scale-110 shadow-xs' : 'border-transparent opacity-70 hover:opacity-100'
                        }`}
                        title={p.label}
                      >
                        <img src={p.url} alt={p.label} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bio */}
              <div>
                <label className="block font-bold text-gray-800 dark:text-gray-200 mb-1">
                  সংক্ষিপ্ত পরিচিতি ও বায়োগ্রাফি (Bio)
                </label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  placeholder="চিকিৎসকের চিকিৎসা দর্শন, অতীত সাফল্য বা বিশেষ কোনো বার্তা..."
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white leading-relaxed"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-gray-200 dark:border-gray-800 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 text-gray-700 dark:text-gray-300 rounded-lg font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow transition flex items-center space-x-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingDoctor ? 'প্রোফাইল সংরক্ষণ করুন' : 'নতুন ডাক্তার যোগ করুন'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
