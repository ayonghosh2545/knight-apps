import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  Settings,
  Save,
  CheckCircle,
  Building,
  Phone,
  Clock,
  Shield,
  Bell,
  Sparkles,
  UserCog,
  UtensilsCrossed,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Lock,
  KeyRound
} from 'lucide-react';

export const ChamberSettingsTab: React.FC = () => {
  const { settings, updateChamberSettings, setAdminSubTab, adminProfile } = useClinic();

  const [formData, setFormData] = useState({
    ...settings,
    footerBio:
      settings.footerBio ||
      'ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।',
    copyrightText:
      settings.copyrightText ||
      `${settings.chamberName} — সর্বস্বত্ব সংরক্ষিত।`,
    defaultDietInstructions:
      settings.defaultDietInstructions ||
      'ওষুধ সেবনের ৩০ মিনিট পূর্বে ও পরে মুখ সম্পূর্ণ পরিষ্কার রাখবেন। কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করবেন। কাঁচা পিঁয়াজ, রসুন ও তীব্র কফি সম্পূর্ণ বর্জনীয়।',
    defaultRestrictions:
      settings.defaultRestrictions && settings.defaultRestrictions.length > 0
        ? settings.defaultRestrictions
        : [
            'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
            'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন',
            'ধূমপান, জর্দা ও তামাক জাতীয় দ্রব্য নিষিদ্ধ',
            'তেঁতুল, আচার ও অতিরিক্ত টক খাবার বর্জনীয়',
            'অতিরিক্ত তেল-মসলাযুক্ত ও বাসি খাবার বর্জনীয়',
            'ফ্রিজের অতিরিক্ত ঠান্ডা পানি বা আইসক্রিম নিষিদ্ধ'
          ]
  });
  const [isSaved, setIsSaved] = useState(false);
  const [newRestrictionInput, setNewRestrictionInput] = useState('');
  const [editingRestrictionIdx, setEditingRestrictionIdx] = useState<number | null>(null);
  const [editingRestrictionText, setEditingRestrictionText] = useState('');

  const handleChange = (field: keyof typeof settings, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setIsSaved(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateChamberSettings(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Settings Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-gray-200 dark:border-gray-800 pb-3">
        <button
          type="button"
          className="px-4 py-2 bg-[#2271b1] text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-2"
        >
          <Settings className="w-4 h-4" />
          <span>১. চেম্বার তথ্য ও সিস্টেম কনফিগারেশন</span>
        </button>
        <button
          type="button"
          onClick={() => setAdminSubTab('admin-settings')}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-xs font-bold transition flex items-center space-x-2"
        >
          <UserCog className="w-4 h-4 text-amber-500" />
          <span>২. অ্যাডমিন অ্যাকাউন্ট সেটিংস (প্রোফাইল এডিট) &rarr;</span>
        </button>
      </div>

      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <Settings className="w-5 h-5 text-[#2271b1]" />
            <span>চেম্বার কনফিগারেশন ও সিস্টেম সেটিংস</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            চেম্বারের নাম, ঠিকানা, ভিজিটিং আওয়ার্স, কনসালটেশন ফি এবং নিরাপত্তা নিয়ন্ত্রণ।
          </p>
        </div>

        {isSaved && (
          <div className="px-3.5 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold flex items-center space-x-1.5 animate-in fade-in">
            <CheckCircle className="w-4 h-4" />
            <span>সকল পরিবর্তন সফলভাবে সংরক্ষিত হয়েছে!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        
        {/* 1. Chamber Basic Details */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center space-x-2">
            <Building className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ১. চিকিৎসালয় ও চেম্বারের সাধারণ পরিচিতি
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">চেম্বারের সম্পূর্ণ নাম *</label>
              <input
                type="text"
                required
                value={formData.chamberName}
                onChange={(e) => handleChange('chamberName', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">স্লোগান / ট্যাগলাইন</label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => handleChange('tagline', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block font-bold mb-1">পূর্ণ ঠিকানা *</label>
              <input
                type="text"
                required
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">শহর</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => handleChange('city', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold mb-1">চেম্বার ফোন নম্বর *</label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">জরুরি হটলাইন (২৪/৭) *</label>
              <input
                type="text"
                required
                value={formData.emergencyPhone}
                onChange={(e) => handleChange('emergencyPhone', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">ইমেইল ঠিকানা</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>
        </div>

        {/* 2. Visiting Hours & Fees */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center space-x-2">
            <Clock className="w-4 h-4 text-teal-600" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ২. সময়সূচী ও কনসালটেশন ফি
            </h3>
          </div>

          <div>
            <label className="block font-bold mb-1">চেম্বার ভিজিটিং আওয়ার্স বর্ণনা *</label>
            <input
              type="text"
              required
              value={formData.visitingHours}
              onChange={(e) => handleChange('visitingHours', e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">নতুন রোগীর রেগুলার ফি (টাকা) *</label>
              <input
                type="number"
                required
                value={formData.regularFee}
                onChange={(e) => handleChange('regularFee', Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
            <div>
              <label className="block font-bold mb-1">পুরাতন রোগীর ফলোআপ ফি (টাকা) *</label>
              <input
                type="number"
                required
                value={formData.followupFee}
                onChange={(e) => handleChange('followupFee', Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>
        </div>

        {/* 3. Live Notice Board */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-amber-500" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ৩. ওয়েবসাইটের জরুরি নোটিশ বোর্ড (Notice Bar)
              </h3>
            </div>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.noticeActive}
                onChange={(e) => handleChange('noticeActive', e.target.checked)}
                className="rounded text-amber-600 focus:ring-amber-500"
              />
              <span className="font-bold">নোটিশ প্রদর্শন সক্রিয় রাখুন</span>
            </label>
          </div>

          <div>
            <label className="block font-bold mb-1">নোটিশের বিষয়বস্তু</label>
            <textarea
              rows={2}
              value={formData.noticeText}
              onChange={(e) => handleChange('noticeText', e.target.value)}
              placeholder="যেমন: আগামী শুক্রবার চেম্বার বন্ধ থাকবে কিন্তু অনলাইন সেবা চালু থাকবে..."
              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
            />
          </div>
        </div>

        {/* 4. Default Homeopathic Diet & Restrictions Config */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center justify-between">
            <div className="flex items-center space-x-2 text-emerald-600">
              <UtensilsCrossed className="w-4 h-4" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ৪. হোমিওপ্যাথিক পথ্য ও বর্জনীয় নির্দেশিকা (Dietary & Restrictions Config)
              </h3>
            </div>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2 py-0.5 rounded font-bold">
              সম্পাদনা ও তথ্য ইনপুট
            </span>
          </div>

          <p className="text-gray-500 text-[11px]">
            চেম্বারের সকল প্রেসক্রিপশন ও অনলাইন পোর্টালের জন্য আদর্শ হোমিওপ্যাথিক পথ্য ও বর্জনীয় নির্দেশিকাসমূহ এখান থেকে ইনপুট ও এডিট করতে পারবেন।
          </p>

          {/* Blank Input Box to add new restriction */}
          <div className="bg-emerald-50/70 dark:bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-800 space-y-2">
            <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200">
              নতুন পথ্য বা বর্জনীয় নির্দেশিকা যোগ করার ব্লাঙ্ক বক্স (Add New Guideline):
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={newRestrictionInput}
                onChange={(e) => setNewRestrictionInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    if (newRestrictionInput.trim()) {
                      const cur = formData.defaultRestrictions || [];
                      handleChange('defaultRestrictions', [...cur, newRestrictionInput.trim()]);
                      setNewRestrictionInput('');
                    }
                  }
                }}
                placeholder="যেমন: কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণ নিষেধ / তেঁতুল ও অতিরিক্ত টক খাবার বর্জনীয়..."
                className="flex-1 px-3 py-2 rounded-lg border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-[#131b1e] text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={() => {
                  if (newRestrictionInput.trim()) {
                    const cur = formData.defaultRestrictions || [];
                    handleChange('defaultRestrictions', [...cur, newRestrictionInput.trim()]);
                    setNewRestrictionInput('');
                  }
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 shrink-0 shadow-xs transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>তথ্য ইনপুট করুন</span>
              </button>
            </div>
          </div>

          {/* List of default restrictions with inline edit & delete */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-gray-800 dark:text-gray-200 block">
              ডিফল্ট নির্দেশিকা তালিকা ({(formData.defaultRestrictions || []).length} টি সক্রিয়):
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
              {(formData.defaultRestrictions || []).map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] text-xs"
                >
                  {editingRestrictionIdx === idx ? (
                    <div className="flex items-center space-x-1.5 w-full">
                      <input
                        type="text"
                        value={editingRestrictionText}
                        onChange={(e) => setEditingRestrictionText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            if (editingRestrictionText.trim()) {
                              const updated = [...(formData.defaultRestrictions || [])];
                              updated[idx] = editingRestrictionText.trim();
                              handleChange('defaultRestrictions', updated);
                              setEditingRestrictionIdx(null);
                            }
                          }
                        }}
                        className="flex-1 px-2 py-1 rounded border border-[#2271b1] bg-white dark:bg-[#131b1e] text-xs"
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (editingRestrictionText.trim()) {
                            const updated = [...(formData.defaultRestrictions || [])];
                            updated[idx] = editingRestrictionText.trim();
                            handleChange('defaultRestrictions', updated);
                            setEditingRestrictionIdx(null);
                          }
                        }}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[10px]"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingRestrictionIdx(null)}
                        className="p-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="truncate flex-1 mr-2 text-gray-800 dark:text-gray-200">
                        {idx + 1}. {item}
                      </span>
                      <div className="flex items-center space-x-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingRestrictionIdx(idx);
                            setEditingRestrictionText(item);
                          }}
                          className="p-1 text-[#2271b1] hover:bg-blue-100 dark:hover:bg-blue-950/50 rounded transition"
                          title="এডিট করুন"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const updated = (formData.defaultRestrictions || []).filter((_, i) => i !== idx);
                            handleChange('defaultRestrictions', updated);
                          }}
                          className="p-1 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/50 rounded transition"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Multi-line Blank Box for Freeform Diet/Medicine Notes */}
          <div className="pt-2">
            <label className="block font-bold mb-1">
              উন্মুক্ত বিস্তারিত পথ্য ও সেবনবিধি ব্লাঙ্ক বক্স (Default Free-text Diet Notes)
            </label>
            <textarea
              rows={3}
              value={formData.defaultDietInstructions || ''}
              onChange={(e) => handleChange('defaultDietInstructions', e.target.value)}
              placeholder="এখানে চিকিৎসকের সাধারণ পথ্য ও ওষুধ সেবনের নিয়মাবলী বিস্তারিতভাবে লিখুন..."
              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-xs leading-relaxed"
            />
          </div>
        </div>

        {/* 5. Security & System Features */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center space-x-2">
            <Shield className="w-4 h-4 text-purple-600" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ৫. নিরাপত্তা ও সিস্টেম অপশন
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] flex items-center justify-between">
              <div>
                <span className="font-bold block text-gray-900 dark:text-white">
                  টু-ফ্যাক্টর অথেন্টিকেশন (2FA)
                </span>
                <span className="text-[11px] text-gray-500">
                  লগইনে ৬-সংখ্যার ওটিপি কোড যাচাই সক্রিয় করুন
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.twoFactorEnabled}
                onChange={(e) => handleChange('twoFactorEnabled', e.target.checked)}
                className="w-4 h-4 rounded text-[#2271b1]"
              />
            </div>

            <div className="p-3.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] flex items-center justify-between">
              <div>
                <span className="font-bold block text-gray-900 dark:text-white">
                  ডাটাবেজ এনক্রিপশন (Encryption)
                </span>
                <span className="text-[11px] text-gray-500">
                  সংবেদনশীল মেডিকেল হিস্ট্রি ক্রিপ্টোগ্রাফিক সুরক্ষা
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.encryptionEnabled}
                onChange={(e) => handleChange('encryptionEnabled', e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600"
              />
            </div>

            <div className="p-3.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] flex items-center justify-between">
              <div>
                <span className="font-bold block text-gray-900 dark:text-white">
                  অফলাইন মোড ও অটো সিঙ্ক
                </span>
                <span className="text-[11px] text-gray-500">
                  ইন্টারনেট না থাকলেও চেম্বার কার্যক্রম চলমান রাখা
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.offlineSyncEnabled}
                onChange={(e) => handleChange('offlineSyncEnabled', e.target.checked)}
                className="w-4 h-4 rounded text-sky-600"
              />
            </div>

            <div className="p-3.5 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] flex items-center justify-between">
              <div>
                <span className="font-bold block text-gray-900 dark:text-white">
                  স্বয়ংক্রিয় ক্লাউড স্ন্যাপশট
                </span>
                <span className="text-[11px] text-gray-500">
                  দৈনিক ডাটাবেস পরিবর্তনসমূহ ক্লাউড ভল্টে সংরক্ষণ
                </span>
              </div>
              <input
                type="checkbox"
                checked={formData.autoBackupDaily}
                onChange={(e) => handleChange('autoBackupDaily', e.target.checked)}
                className="w-4 h-4 rounded text-teal-600"
              />
            </div>
          </div>

          {/* Master Security Code & Prescription Privacy Configuration */}
          <div className="mt-4 p-4 rounded-xl border border-amber-300 dark:border-amber-800 bg-amber-50/70 dark:bg-amber-950/20 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-2 text-amber-900 dark:text-amber-200">
                <Lock className="w-4 h-4 text-amber-600" />
                <h4 className="font-bold text-xs sm:text-sm">
                  প্রেসক্রিপশন মেডিসিন মাস্টার সিকিউরিটি কোড (Prescription Privacy)
                </h4>
              </div>
              <span className="text-[10px] bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 px-2 py-0.5 rounded-full font-bold">
                লগআউট লক অটো-সক্রিয়
              </span>
            </div>

            <p className="text-[11px] text-amber-900/80 dark:text-amber-300/80 leading-relaxed">
              লগআউট থাকা অবস্থায় প্রেসক্রিপশনের ওষুধসমূহ রোগীদের থেকে সুরক্ষিত ও গোপন থাকে। রোগী বা বহিরাগতরা নিচে উল্লেখিত মাস্টার সিকিউরিটি কোড লিখলে তবেই প্রেসক্রিপশনের ওষুধ ও সেবনবিধি দেখতে পারবেন।
            </p>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white dark:bg-[#1a2024] p-3 rounded-lg border border-amber-200 dark:border-amber-800">
              <div>
                <span className="text-[10px] text-gray-500 block">বর্তমান সক্রিয় মাস্টার কোড:</span>
                <span className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400 tracking-wider">
                  {adminProfile?.masterSecurityCode || 'AYON540'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setAdminSubTab('admin-settings')}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1.5 shadow-xs"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>মাস্টার কোড পরিবর্তন করুন &rarr;</span>
              </button>
            </div>
          </div>
        </div>

        {/* 6. Footer & Copyright Settings */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center space-x-2">
            <Building className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ৬. ফুটার পরিচিতি, কলাম শিরোনাম ও অপশন কনফিগারেশন
            </h3>
          </div>

          <div>
            <label className="block font-bold mb-1">ফুটার চেম্বার পরিচিতি / বিবরণ (Bio)</label>
            <textarea
              rows={2}
              value={formData.footerBio || ''}
              onChange={(e) => handleChange('footerBio', e.target.value)}
              placeholder="যেমন: ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।"
              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold mb-1">কলাম ২ শিরোনাম (যোগাযোগ)</label>
              <input
                type="text"
                value={formData.footerContactHeading || ''}
                onChange={(e) => handleChange('footerContactHeading', e.target.value)}
                placeholder="যোগাযোগ ও চেম্বার ঠিকানা"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">কলাম ৩ শিরোনাম (কুইক লিংক)</label>
              <input
                type="text"
                value={formData.footerQuickLinksHeading || ''}
                onChange={(e) => handleChange('footerQuickLinksHeading', e.target.value)}
                placeholder="রোগী সেবা ও পোর্টাল"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">কলাম ৪ শিরোনাম (মোবাইল অ্যাপ)</label>
              <input
                type="text"
                value={formData.footerAppHeading || ''}
                onChange={(e) => handleChange('footerAppHeading', e.target.value)}
                placeholder="মোবাইল অ্যাপ ও ডাউনলোড"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">মোবাইল অ্যাপ সেকশনের বিবরণ</label>
              <textarea
                rows={2}
                value={formData.footerAppDesc || ''}
                onChange={(e) => handleChange('footerAppDesc', e.target.value)}
                placeholder="এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন..."
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">অ্যাপ ডাউনলোড বাটন টেক্সট</label>
              <input
                type="text"
                value={formData.footerAppBtnText || ''}
                onChange={(e) => handleChange('footerAppBtnText', e.target.value)}
                placeholder="ডাউনলোড APK (v1.0.4)"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold mb-1">কপিরাইট নোটিশ টেক্সট</label>
              <input
                type="text"
                value={formData.copyrightText || ''}
                onChange={(e) => handleChange('copyrightText', e.target.value)}
                placeholder="যেমন: হোমিও আরোগ্য নিকেতন ও রিসার্চ সেন্টার — সর্বস্বত্ব সংরক্ষিত।"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">বটম বার প্ল্যাটফর্ম ট্যাগ</label>
              <input
                type="text"
                value={formData.footerBottomBadge || ''}
                onChange={(e) => handleChange('footerBottomBadge', e.target.value)}
                placeholder="WordPress 6.7 & HomeoPress Theme"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">বটম বার সাব-ট্যাগলাইন</label>
              <input
                type="text"
                value={formData.footerBottomTagline || ''}
                onChange={(e) => handleChange('footerBottomTagline', e.target.value)}
                placeholder="অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
            </div>
          </div>
        </div>

        {/* Save Changes Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-lg shadow-md transition flex items-center space-x-2 text-sm"
          >
            <Save className="w-4 h-4" />
            <span>সকল সেটিংস সেভ করুন (Save Changes)</span>
          </button>
        </div>

      </form>
    </div>
  );
};
