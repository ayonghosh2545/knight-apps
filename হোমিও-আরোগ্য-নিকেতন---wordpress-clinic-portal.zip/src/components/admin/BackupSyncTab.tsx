import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  Download,
  Upload,
  Cloud,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  FileCode,
  Shield,
  Database,
  History
} from 'lucide-react';

export const BackupSyncTab: React.FC = () => {
  const {
    exportJsonBackup,
    importJsonBackup,
    triggerCloudBackup,
    restoreCloudSnapshot,
    cloudSnapshots,
    isOnline,
    isSyncing,
    lastSyncedAt,
    syncQueue,
    triggerManualSync
  } = useClinic();

  const [encryptExport, setEncryptExport] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isCloudBackingUp, setIsCloudBackingUp] = useState(false);

  const handleDownloadJson = () => {
    try {
      const content = exportJsonBackup(encryptExport);
      const blob = new Blob([content], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const filename = `homeocare-backup-${new Date().toISOString().split('T')[0]}${encryptExport ? '-encrypted' : ''}.json`;
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setFeedback({ type: 'success', message: `${filename} সফলভাবে আপনার ডিভাইসে ডাউনলোড হয়েছে!` });
    } catch (err: any) {
      setFeedback({ type: 'error', message: 'ডাউনলোড ত্রুটি: ' + err?.message });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const result = importJsonBackup(content);
        if (result.success) {
          setFeedback({ type: 'success', message: result.message });
        } else {
          setFeedback({ type: 'error', message: result.message });
        }
      }
    };
    reader.onerror = () => {
      setFeedback({ type: 'error', message: 'ফাইল রিড করতে ব্যর্থ হয়েছে।' });
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleCloudBackupNow = async () => {
    setIsCloudBackingUp(true);
    setFeedback(null);
    try {
      const res = await triggerCloudBackup();
      if (res.success) {
        setFeedback({ type: 'success', message: res.message });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', message: 'ক্লাউড ব্যাকআপ ত্রুটি: ' + err?.message });
    } finally {
      setIsCloudBackingUp(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <Database className="w-5 h-5 text-[#2271b1]" />
            <span>ডাটা ব্যাকআপ, রিস্টোর ও ক্লাউড সিঙ্ক্রোনাইজেশন</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            .json ফাইল এক্সপোর্ট/ইমপোর্ট, অফলাইন সিঙ্ক এবং সুরক্ষিত ক্লাউড স্টোরেজ অপশন।
          </p>
        </div>

        <button
          onClick={triggerManualSync}
          disabled={isSyncing}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg transition flex items-center space-x-1.5 shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>{isSyncing ? 'সিঙ্ক হচ্ছে...' : 'এখনই সিঙ্ক করুন'}</span>
        </button>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl text-xs flex items-start space-x-2.5 animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800'
              : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border border-rose-300 dark:border-rose-800'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Sync Status Banner */}
      <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isOnline ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/80' : 'bg-amber-100 text-amber-600 dark:bg-amber-950/80'
          }`}>
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-sm text-gray-900 dark:text-white">
              {isOnline ? 'ক্লাউড নেটওয়ার্ক সংযুক্ত (Online)' : 'অফলাইন মোড সক্রিয় (Offline)'}
            </div>
            <div className="text-xs text-gray-500">
              সর্বশেষ সফল সিঙ্ক: <span className="font-mono font-semibold text-emerald-600">{lastSyncedAt}</span>
              {syncQueue.length > 0 && ` | অপেক্ষমাণ কিউ: ${syncQueue.length} টি`}
            </div>
          </div>
        </div>

        <div className="text-xs text-gray-600 dark:text-gray-400">
          অফলাইনে পরিবর্তন করলে ইন্টারনেট ফিরে আসলে স্বয়ংক্রিয়ভাবে ক্লাউডে আপলোড হবে।
        </div>
      </div>

      {/* Two Column Grid: JSON Export / Import */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Export JSON Card */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2 mb-2 text-[#2271b1]">
              <Download className="w-5 h-5" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ডাটাবেস ব্যাকআপ ডাউনলোড (.json Download)
              </h3>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              চেম্বারের সকল রোগীর তথ্য, অ্যাপয়েন্টমেন্ট শিডিউল, এবং ডিজিটাল প্রেসক্রিপশন একটি পোর্টেবল .json ফাইল আকারে ব্যাকআপ সংরক্ষণ করুন।
            </p>

            <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-800">
              <label className="flex items-center space-x-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={encryptExport}
                  onChange={(e) => setEncryptExport(e.target.checked)}
                  className="rounded text-[#2271b1] focus:ring-[#2271b1]"
                />
                <span>এনক্রিপ্টেড ফরম্যাটে এক্সপোর্ট করুন (প্রস্তাবিত - বাড়তি সুরক্ষা)</span>
              </label>
            </div>
          </div>

          <button
            onClick={handleDownloadJson}
            className="w-full py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>.JSON ফাইল ডাউনলোড করুন</span>
          </button>
        </div>

        {/* Import JSON Card */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2 mb-2 text-emerald-600">
              <Upload className="w-5 h-5" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ফাইল আপলোড করে রিস্টোর (.json Upload & Restore)
              </h3>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              পূর্বে ডাউনলোডকৃত যেকোনো .json ফাইল আপলোড করে এক ক্লিকে সম্পূর্ণ ক্লিনিক ডাটাবেস রিস্টোর করুন। (এনক্রিপ্টেড বা সাধারণ উভয় ফাইলই সাপোর্টেড)।
            </p>
          </div>

          <div>
            <label className="w-full py-2.5 border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 rounded-xl flex items-center justify-center space-x-2 cursor-pointer bg-gray-50 dark:bg-[#131b1e] hover:bg-emerald-50/40 text-xs font-bold text-gray-700 dark:text-gray-300 transition">
              <Upload className="w-4 h-4 text-emerald-600" />
              <span>.JSON ফাইল নির্বাচন করুন ও রিস্টোর করুন</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

      </div>

      {/* Cloud Storage Vault Section */}
      <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-200 dark:border-gray-800 pb-3">
          <div className="flex items-center space-x-2 text-teal-600">
            <Cloud className="w-5 h-5" />
            <div>
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ক্লাউড স্টোরেজ অপশন ও স্ন্যাপশট হিস্ট্রি (Cloud Vault)
              </h3>
              <p className="text-xs text-gray-500">
                স্বয়ংক্রিয় দূরবর্তী ক্লাউড ভল্টে ডাটা ব্যাকআপ সংরক্ষণ ও রিস্টোর সুবিধা।
              </p>
            </div>
          </div>

          <button
            onClick={handleCloudBackupNow}
            disabled={isCloudBackingUp}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
          >
            <Cloud className="w-4 h-4" />
            <span>{isCloudBackingUp ? 'ক্লাউডে আপলোড হচ্ছে...' : 'এখনই ক্লাউড ব্যাকআপ নিন'}</span>
          </button>
        </div>

        {/* Snapshots Table */}
        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#151a1e] text-gray-500 font-bold border-b border-gray-300 dark:border-gray-800">
                <th className="p-2.5">স্ন্যাপশট আইডি</th>
                <th className="p-2.5">সংরক্ষণের সময়</th>
                <th className="p-2.5">ফাইল সাইজ</th>
                <th className="p-2.5">মোট রেকর্ড</th>
                <th className="p-2.5">চেকসাম</th>
                <th className="p-2.5 text-right">পদক্ষেপ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
              {cloudSnapshots.map((snap) => (
                <tr key={snap.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/40">
                  <td className="p-2.5 font-mono font-bold text-teal-600">{snap.id}</td>
                  <td className="p-2.5 text-gray-700 dark:text-gray-300">{snap.timestamp}</td>
                  <td className="p-2.5 font-mono text-gray-500">{(snap.sizeBytes / 1024).toFixed(1)} KB</td>
                  <td className="p-2.5 font-bold text-emerald-600">{snap.recordsCount} টি</td>
                  <td className="p-2.5 font-mono text-purple-600">{snap.checksum}</td>
                  <td className="p-2.5 text-right">
                    <button
                      onClick={() => {
                        restoreCloudSnapshot(snap.id);
                        setFeedback({ type: 'success', message: `স্ন্যাপশট ${snap.id} থেকে ডাটাবেস সফলভাবে রিস্টোর হয়েছে।` });
                      }}
                      className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 rounded text-[11px] font-bold text-gray-800 dark:text-gray-200"
                    >
                      রিস্টোর
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
