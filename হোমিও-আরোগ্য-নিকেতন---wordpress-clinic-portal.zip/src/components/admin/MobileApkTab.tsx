import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  QrCode,
  CheckCircle,
  RefreshCw,
  ShieldCheck,
  PackageCheck,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export const MobileApkTab: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useState(true);
  const [updateStatus, setUpdateStatus] = useState<string>('আপনি সর্বশেষ সংস্করণ v1.0.4 ব্যবহার করছেন।');
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      alert('আপনার মোবাইল ব্রাউজারের মেনু (তিনটি ডট) থেকে "Add to Home screen" বা "ইনস্টল করুন" বাটনে ট্যাপ করুন।');
    }
  };

  const handleDownloadApk = () => {
    window.location.href = '/api/download-apk';
  };

  const handleCheckUpdate = () => {
    setIsCheckingUpdate(true);
    setTimeout(() => {
      setIsCheckingUpdate(false);
      setUpdateStatus('সিস্টেম আপ-টু-ডেট! কোনো নতুন প্যাচ বা আপডেট অমীমাংসিত নেই।');
    }, 800);
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
          <Smartphone className="w-5 h-5 text-purple-600" />
          <span>মোবাইল অ্যাপ ও সরাসরি APK ডাউনলোড কেন্দ্র</span>
        </h2>
        <p className="text-xs text-gray-500 mt-0.5">
          এক ক্লিকে মোবাইল ফোনে ইনস্টলেশন এবং বিল্ড ফোল্ডারে সংরক্ষিত APK ফাইল ডাউনলোড।
        </p>
      </div>

      {/* Main Grid: PWA Install & Direct APK Download */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Card 1: 1-Click Mobile PWA Install */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 text-emerald-600 mb-2">
              <Smartphone className="w-5 h-5" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                এক ক্লিকে মোবাইলে ইনস্টল (1-Click PWA App)
              </h3>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              হোমিও আরোগ্য নিকেতন অ্যাপটি সরাসরি আপনার স্মার্টফোনের হোম স্ক্রিনে অ্যান্ড্রয়েড অ্যাপের মতো ইনস্টল করুন। এটি পূর্ণ স্ক্রিনে চলে এবং অফলাইনেও সম্পূর্ণ কার্যকর থাকে।
            </p>

            <div className="mt-4 p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-300 space-y-1">
              <div className="flex items-center space-x-1.5 font-bold">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>অফলাইন সাপোর্ট ও ক্যাশ মেমোরি সংযুক্ত</span>
              </div>
              <div className="text-[11px] text-emerald-700 dark:text-emerald-400">
                হোমস্ক্রিন আইকন ও নেটিভ স্প্ল্যাশ স্ক্রিন সক্রিয়।
              </div>
            </div>
          </div>

          <button
            onClick={handleInstallPWA}
            className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-2"
          >
            <Smartphone className="w-4 h-4" />
            <span>{isInstalled ? 'অ্যাপটি ইতিমধ্যে ইনস্টল্ড' : 'মোবাইলে অ্যাপ ইনস্টল করুন'}</span>
          </button>
        </div>

        {/* Card 2: Generated APK File in Build Directory */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center space-x-2.5 text-purple-600 mb-2">
              <PackageCheck className="w-5 h-5" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                বিল্ড ফোল্ডারের সরাসরি APK ফাইল
              </h3>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              আপনার অনুরোধ অনুযায়ী সরাসরি প্রজেক্টের ফাইল এক্সপ্লোরার এবং <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded font-mono text-[11px]">/build/</code> ফোল্ডারে <code className="text-purple-600 font-mono font-bold">HomeoCare-Chamber.apk</code> ফাইল তৈরি ও সংরক্ষণ করা হয়েছে।
            </p>

            {/* APK Metadata details */}
            <div className="mt-3 p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800 text-[11px] space-y-1 font-mono text-purple-950 dark:text-purple-300">
              <div>ফাইল নাম: HomeoCare-Chamber.apk</div>
              <div>অবস্থান: /build/ এবং /public/build/</div>
              <div>প্যাকেজ: com.homeocare.clinic (v1.0.4)</div>
              <div>মাস্টার সিকিউরিটি: লকড ও সমন্বিত</div>
            </div>
          </div>

          <button
            onClick={handleDownloadApk}
            className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>সরাসরি APK ফাইল ডাউনলোড করুন</span>
          </button>
        </div>

      </div>

      {/* QR Code & Mobile Sync Section */}
      <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          <div className="md:col-span-8 space-y-3">
            <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-2">
              <QrCode className="w-4 h-4 text-emerald-600" />
              <span>মোবাইল ক্যামেরা দিয়ে স্ক্যান করে ইনস্টলেশন</span>
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              আপনার অ্যান্ড্রয়েড ফোনের ক্যামেরা অন করে পাশের QR কোডটি স্ক্যান করলে সরাসরি চেম্বার পোর্টাল চালু হবে এবং হোম স্ক্রিনে ইন্সটল করার অপশন আসবে।
            </p>

            <div className="pt-2 flex items-center space-x-4 text-xs">
              <label className="flex items-center space-x-2 cursor-pointer text-gray-700 dark:text-gray-300">
                <input
                  type="checkbox"
                  checked={autoUpdateEnabled}
                  onChange={(e) => setAutoUpdateEnabled(e.target.checked)}
                  className="rounded text-emerald-600"
                />
                <span>অটো আপডেট অপশন চালু রাখুন (Auto Update)</span>
              </label>

              <button
                onClick={handleCheckUpdate}
                disabled={isCheckingUpdate}
                className="px-3 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 rounded font-bold text-[11px] flex items-center space-x-1"
              >
                <RefreshCw className={`w-3 h-3 ${isCheckingUpdate ? 'animate-spin' : ''}`} />
                <span>আপডেট চেক করুন</span>
              </button>
            </div>

            <div className="text-[11px] text-gray-500 font-mono">
              স্ট্যাটাস: {updateStatus}
            </div>
          </div>

          {/* SVG QR Code Simulation */}
          <div className="md:col-span-4 flex justify-center">
            <div className="p-3 bg-white rounded-xl border-2 border-gray-300 shadow-md flex flex-col items-center">
              <svg
                className="w-32 h-32"
                viewBox="0 0 100 100"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="100" height="100" fill="white" />
                {/* Corner markers */}
                <rect x="10" y="10" width="24" height="24" fill="#1d2327" rx="3" />
                <rect x="14" y="14" width="16" height="16" fill="white" rx="1" />
                <rect x="18" y="18" width="8" height="8" fill="#1d2327" rx="1" />

                <rect x="66" y="10" width="24" height="24" fill="#1d2327" rx="3" />
                <rect x="70" y="14" width="16" height="16" fill="white" rx="1" />
                <rect x="74" y="18" width="8" height="8" fill="#1d2327" rx="1" />

                <rect x="10" y="66" width="24" height="24" fill="#1d2327" rx="3" />
                <rect x="14" y="70" width="16" height="16" fill="white" rx="1" />
                <rect x="18" y="74" width="8" height="8" fill="#1d2327" rx="1" />

                {/* Pattern dots */}
                <rect x="42" y="12" width="6" height="6" fill="#1d2327" />
                <rect x="52" y="12" width="6" height="6" fill="#1d2327" />
                <rect x="42" y="24" width="6" height="6" fill="#1d2327" />
                <rect x="52" y="24" width="6" height="6" fill="#1d2327" />
                <rect x="38" y="38" width="8" height="8" fill="#2271b1" rx="1" />
                <rect x="54" y="38" width="8" height="8" fill="#2271b1" rx="1" />
                <rect x="46" y="46" width="8" height="8" fill="#2271b1" rx="1" />
                <rect x="14" y="44" width="6" height="6" fill="#1d2327" />
                <rect x="24" y="44" width="6" height="6" fill="#1d2327" />
                <rect x="70" y="44" width="6" height="6" fill="#1d2327" />
                <rect x="80" y="44" width="6" height="6" fill="#1d2327" />
                <rect x="42" y="66" width="6" height="6" fill="#1d2327" />
                <rect x="52" y="66" width="6" height="6" fill="#1d2327" />
                <rect x="66" y="66" width="6" height="6" fill="#1d2327" />
                <rect x="76" y="66" width="6" height="6" fill="#1d2327" />
                <rect x="66" y="76" width="6" height="6" fill="#1d2327" />
                <rect x="76" y="76" width="6" height="6" fill="#1d2327" />
                <rect x="42" y="76" width="6" height="6" fill="#1d2327" />
                <rect x="52" y="76" width="6" height="6" fill="#1d2327" />
              </svg>
              <span className="text-[10px] font-bold text-gray-700 mt-1 font-mono">
                Scan to Install
              </span>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
