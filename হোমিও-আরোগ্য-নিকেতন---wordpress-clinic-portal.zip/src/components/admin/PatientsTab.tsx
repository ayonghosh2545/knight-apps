import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { Patient } from '../../types.ts';
import {
  Users,
  Search,
  Plus,
  Phone,
  Calendar,
  FileText,
  MapPin,
  HeartPulse,
  Edit,
  Trash2,
  CheckCircle,
  Eye,
  X,
  AlertTriangle,
  Mail,
  Shield,
  Activity,
  UserCheck
} from 'lucide-react';

export const PatientsTab: React.FC = () => {
  const {
    patients,
    addPatient,
    updatePatient,
    deletePatient,
    setActiveLookupCodeOrPhone,
    setIsPrescriptionLookupOpen
  } = useClinic();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterGender, setFilterGender] = useState<string>('all');
  const [filterBloodGroup, setFilterBloodGroup] = useState<string>('all');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [viewingPatient, setViewingPatient] = useState<Patient | null>(null);
  const [deletingPatientId, setDeletingPatientId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Add Patient Form State
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newAge, setNewAge] = useState<number | ''>('');
  const [newGender, setNewGender] = useState<'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য'>('পুরুষ');
  const [newBloodGroup, setNewBloodGroup] = useState('O+');
  const [newAddress, setNewAddress] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newEmergencyContact, setNewEmergencyContact] = useState('');
  const [newConstitutionalType, setNewConstitutionalType] = useState('');
  const [newChronicCondition, setNewChronicCondition] = useState('');
  const [newAllergies, setNewAllergies] = useState('');
  const [newNotes, setNewNotes] = useState('');

  // Edit Patient Form State (Everything can be edited)
  const [editForm, setEditForm] = useState<{
    id: string;
    name: string;
    phone: string;
    age: number;
    gender: 'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য';
    bloodGroup: string;
    address: string;
    email: string;
    emergencyContact: string;
    firstVisitDate: string;
    lastVisitDate: string;
    totalVisits: number;
    totalPrescriptions: number;
    chronicConditions: string;
    constitutionalType: string;
    allergies: string;
    notes: string;
  }>({
    id: '',
    name: '',
    phone: '',
    age: 30,
    gender: 'পুরুষ',
    bloodGroup: 'O+',
    address: '',
    email: '',
    emergencyContact: '',
    firstVisitDate: '',
    lastVisitDate: '',
    totalVisits: 1,
    totalPrescriptions: 0,
    chronicConditions: '',
    constitutionalType: '',
    allergies: '',
    notes: ''
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Filter patients
  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.phone.includes(searchTerm) ||
      p.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.chronicConditions && p.chronicConditions.some((c) => c.toLowerCase().includes(searchTerm.toLowerCase()))) ||
      (p.constitutionalType && p.constitutionalType.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesGender = filterGender === 'all' || p.gender === filterGender;
    const matchesBlood = filterBloodGroup === 'all' || p.bloodGroup === filterBloodGroup;

    return matchesSearch && matchesGender && matchesBlood;
  });

  // Handle open edit modal
  const handleStartEdit = (patient: Patient) => {
    setEditForm({
      id: patient.id,
      name: patient.name,
      phone: patient.phone,
      age: patient.age,
      gender: patient.gender,
      bloodGroup: patient.bloodGroup || 'O+',
      address: patient.address,
      email: patient.email || '',
      emergencyContact: patient.emergencyContact || '',
      firstVisitDate: patient.firstVisitDate || new Date().toISOString().split('T')[0],
      lastVisitDate: patient.lastVisitDate || new Date().toISOString().split('T')[0],
      totalVisits: patient.totalVisits || 1,
      totalPrescriptions: patient.totalPrescriptions || 0,
      chronicConditions: (patient.chronicConditions || []).join(', '),
      constitutionalType: patient.constitutionalType || '',
      allergies: (patient.allergies || []).join(', '),
      notes: patient.notes || ''
    });
    setEditingPatient(patient);
  };

  // Handle Save Edit
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.id || !editForm.name.trim() || !editForm.phone.trim()) return;

    const parsedConditions = editForm.chronicConditions
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);

    const parsedAllergies = editForm.allergies
      .split(',')
      .map((a) => a.trim())
      .filter(Boolean);

    const updatedData: Partial<Patient> = {
      name: editForm.name.trim(),
      phone: editForm.phone.trim(),
      age: Number(editForm.age) || 0,
      gender: editForm.gender,
      bloodGroup: editForm.bloodGroup,
      address: editForm.address.trim(),
      email: editForm.email.trim() || undefined,
      emergencyContact: editForm.emergencyContact.trim() || undefined,
      firstVisitDate: editForm.firstVisitDate,
      lastVisitDate: editForm.lastVisitDate,
      totalVisits: Math.max(0, Number(editForm.totalVisits) || 0),
      totalPrescriptions: Math.max(0, Number(editForm.totalPrescriptions) || 0),
      chronicConditions: parsedConditions,
      constitutionalType: editForm.constitutionalType.trim() || undefined,
      allergies: parsedAllergies,
      notes: editForm.notes.trim() || undefined
    };

    updatePatient(editForm.id, updatedData);
    setEditingPatient(null);
    showToast(`রোগী "${editForm.name}" এর সকল তথ্য সফলভাবে আপডেট হয়েছে!`);
  };

  // Handle Add New Patient
  const handleCreatePatient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    const parsedConditions = newChronicCondition
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);

    const parsedAllergies = newAllergies
      .split(',')
      .map((a) => a.trim())
      .filter(Boolean);

    addPatient({
      name: newName.trim(),
      phone: newPhone.trim(),
      age: Number(newAge) || 30,
      gender: newGender,
      bloodGroup: newBloodGroup,
      address: newAddress.trim() || 'উত্তরা, ঢাকা',
      email: newEmail.trim() || undefined,
      emergencyContact: newEmergencyContact.trim() || undefined,
      constitutionalType: newConstitutionalType.trim() || undefined,
      chronicConditions: parsedConditions,
      allergies: parsedAllergies,
      notes: newNotes.trim() || undefined
    });

    setShowAddModal(false);
    showToast(`নতুন রোগী "${newName}" সফলভাবে ডাটাবেজে অন্তর্ভুক্ত হয়েছে!`);
    // Reset
    setNewName('');
    setNewPhone('');
    setNewAge('');
    setNewAddress('');
    setNewEmail('');
    setNewEmergencyContact('');
    setNewConstitutionalType('');
    setNewChronicCondition('');
    setNewAllergies('');
    setNewNotes('');
  };

  // Handle Delete Patient
  const handleConfirmDelete = (id: string) => {
    const target = patients.find((p) => p.id === id);
    deletePatient(id);
    setDeletingPatientId(null);
    showToast(`রোগী "${target?.name || id}" এর তথ্য সফলভাবে মুছে ফেলা হয়েছে।`);
  };

  // Handle Lookup Prescription
  const handleViewPatientRx = (phoneNum: string) => {
    setActiveLookupCodeOrPhone(phoneNum);
    setIsPrescriptionLookupOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#135e96] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center space-x-2 border border-blue-400/30 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-300 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-[#1a2024] p-5 rounded-2xl border border-gray-300 dark:border-gray-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-[#2271b1] flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center space-x-2">
                <span>রোগী ডাটাবেস ব্যবস্থাপনা (Full Patient Database Editor)</span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-full">
                  সম্পূর্ণ এডিট সুবিধাযুক্ত
                </span>
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                রোগীর ব্যক্তিগত তথ্য, মায়াজম, রক্ত গ্রুপ, ভিজিট সংখ্যা ও মেডিকেল হিস্ট্রি ইচ্ছামত পরিবর্তন ও পরিমার্জন করুন।
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <button
            onClick={() => setShowAddModal(true)}
            className="w-full sm:w-auto px-4 py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন রোগী যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-[#1a2024] p-3.5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="text-xs text-gray-500 flex items-center justify-between">
            <span>মোট নিবন্ধিত রোগী</span>
            <Users className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-xl font-bold font-mono text-gray-900 dark:text-white mt-1">
            {patients.length} জন
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-3.5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="text-xs text-gray-500 flex items-center justify-between">
            <span>ক্রনিক / স্থায়ী রোগী</span>
            <HeartPulse className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-1">
            {patients.filter((p) => p.chronicConditions && p.chronicConditions.length > 0).length} জন
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-3.5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="text-xs text-gray-500 flex items-center justify-between">
            <span>মোট পরামর্শ ভিজিট</span>
            <Calendar className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
            {patients.reduce((sum, p) => sum + (p.totalVisits || 1), 0)} বার
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-3.5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="text-xs text-gray-500 flex items-center justify-between">
            <span>প্রেসক্রিপশন ইস্যু</span>
            <FileText className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-xl font-bold font-mono text-purple-600 dark:text-purple-400 mt-1">
            {patients.reduce((sum, p) => sum + (p.totalPrescriptions || 0), 0)} টি
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-[#1a2024] p-4 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col md:flex-row justify-between items-stretch md:items-center gap-3">
        <div className="relative flex-1 max-w-lg">
          <input
            type="text"
            placeholder="নাম, মোবাইল নম্বর, রোগ বা মায়াজম অনুসন্ধান..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-xs rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Gender Filter */}
          <select
            value={filterGender}
            onChange={(e) => setFilterGender(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-700 dark:text-gray-300"
          >
            <option value="all">সকল লিঙ্গ</option>
            <option value="পুরুষ">পুরুষ</option>
            <option value="মহিলা">মহিলা</option>
            <option value="শিশু">শিশু</option>
            <option value="অন্যান্য">অন্যান্য</option>
          </select>

          {/* Blood Group Filter */}
          <select
            value={filterBloodGroup}
            onChange={(e) => setFilterBloodGroup(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-700 dark:text-gray-300 font-mono"
          >
            <option value="all">সকল ব্লাড গ্রুপ</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>

          <span className="text-xs text-gray-500 font-mono pl-2">
            ফলাফল: {filteredPatients.length} জন
          </span>
        </div>
      </div>

      {/* Patient Database Table */}
      <div className="bg-white dark:bg-[#1a2024] rounded-2xl border border-gray-300 dark:border-gray-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#151a1e] text-gray-600 dark:text-gray-400 font-bold border-b border-gray-300 dark:border-gray-800">
                <th className="p-3.5">রোগীর নাম ও পরিচয়</th>
                <th className="p-3.5">বয়স / লিঙ্গ</th>
                <th className="p-3.5">ব্লাড গ্রুপ</th>
                <th className="p-3.5">যোগাযোগ</th>
                <th className="p-3.5">ঠিকানা</th>
                <th className="p-3.5">হোমিও মায়াজম / রোগ</th>
                <th className="p-3.5 text-center">ভিজিট / Rx</th>
                <th className="p-3.5 text-right">কার্যক্রম (Action)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
              {filteredPatients.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-gray-500">
                    কোনো রোগী পাওয়া যায়নি। অনুসন্ধানের শব্দ পরিবর্তন করুন অথবা নতুন রোগী যুক্ত করুন।
                  </td>
                </tr>
              ) : (
                filteredPatients.map((pat) => (
                  <tr key={pat.id} className="hover:bg-blue-50/40 dark:hover:bg-gray-800/40 transition">
                    <td className="p-3.5">
                      <div className="font-bold text-gray-900 dark:text-white flex items-center space-x-1.5">
                        <span>{pat.name}</span>
                        {pat.constitutionalType && (
                          <span className="px-1.5 py-0.5 bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 rounded text-[10px] font-medium" title="হোমিওপ্যাথিক প্রকৃতি">
                            {pat.constitutionalType.slice(0, 16)}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400 font-mono mt-0.5">
                        ID: {pat.id} • প্রথম: {pat.firstVisitDate}
                      </div>
                    </td>

                    <td className="p-3.5 text-gray-700 dark:text-gray-300">
                      <div>{pat.age} বছর</div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
                        {pat.gender}
                      </span>
                    </td>

                    <td className="p-3.5 font-mono font-bold text-emerald-600">
                      <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800">
                        {pat.bloodGroup || 'N/A'}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <div className="font-mono text-gray-800 dark:text-gray-200 flex items-center space-x-1">
                        <Phone className="w-3 h-3 text-gray-400" />
                        <span>{pat.phone}</span>
                      </div>
                      {pat.email && (
                        <div className="text-[11px] text-gray-400 truncate max-w-[120px]">{pat.email}</div>
                      )}
                    </td>

                    <td className="p-3.5 text-gray-600 dark:text-gray-400 max-w-xs truncate">
                      {pat.address}
                    </td>

                    <td className="p-3.5 max-w-xs">
                      <div className="text-gray-800 dark:text-gray-200 font-medium truncate">
                        {(pat.chronicConditions && pat.chronicConditions.length > 0)
                          ? pat.chronicConditions.join(', ')
                          : 'সাধারণ চেকআপ'}
                      </div>
                      {pat.notes && (
                        <div className="text-[11px] text-gray-400 truncate mt-0.5" title={pat.notes}>
                          নোট: {pat.notes}
                        </div>
                      )}
                    </td>

                    <td className="p-3.5 text-center">
                      <span className="font-mono font-bold text-purple-700 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/50 px-2 py-0.5 rounded">
                        {pat.totalVisits || 1} বার
                      </span>
                      <div className="text-[10px] text-gray-400 mt-1">
                        {pat.totalPrescriptions || 0}টি প্রেসক্রিপশন
                      </div>
                    </td>

                    <td className="p-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end space-x-1.5">
                        {/* Quick View */}
                        <button
                          onClick={() => setViewingPatient(pat)}
                          title="সম্পূর্ণ প্রোফাইল দেখুন"
                          className="p-1.5 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Prescriptions lookup */}
                        <button
                          onClick={() => handleViewPatientRx(pat.phone)}
                          title="প্রেসক্রিপশন দেখুন"
                          className="px-2 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900 border border-emerald-300 dark:border-emerald-800 rounded-lg text-[11px] font-bold inline-flex items-center space-x-1 transition"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Rx</span>
                        </button>

                        {/* EDIT EVERYTHING BUTTON */}
                        <button
                          onClick={() => handleStartEdit(pat)}
                          title="রোগীর ডাটাবেজ তথ্য এডিট করুন"
                          className="px-2.5 py-1 bg-[#2271b1] hover:bg-[#135e96] text-white rounded-lg text-[11px] font-bold inline-flex items-center space-x-1 shadow-xs transition"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>এডিট</span>
                        </button>

                        {/* Delete Patient */}
                        <button
                          onClick={() => setDeletingPatientId(pat.id)}
                          title="রোগী ডাটাবেজ থেকে মুছে ফেলুন"
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FULL PATIENT EDIT MODAL (সবকিছু এডিট করার পূর্ণাঙ্গ ফর্ম)                    */}
      {/* ========================================================================= */}
      {editingPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700 my-8">
            <div className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-[#2271b1] flex items-center justify-center font-bold">
                  <Edit className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-gray-900 dark:text-white">
                    রোগীর ডাটাবেজ তথ্য সম্পাদনা (Edit Patient Records)
                  </h3>
                  <p className="text-[11px] text-gray-500">
                    রোগী আইডি: <span className="font-mono font-bold">{editForm.id}</span> • যেকোনো তথ্য পরিবর্তন করে সেভ করুন।
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingPatient(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-4 text-xs">
              {/* Row 1: Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    রোগীর পূর্ণ নাম <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    মোবাইল নম্বর <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 2: Age, Gender, Blood Group */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    বয়স (বছর)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={125}
                    value={editForm.age}
                    onChange={(e) => setEditForm({ ...editForm, age: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    লিঙ্গ
                  </label>
                  <select
                    value={editForm.gender}
                    onChange={(e) => setEditForm({ ...editForm, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="শিশু">শিশু</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    রক্তের গ্রুপ
                  </label>
                  <select
                    value={editForm.bloodGroup}
                    onChange={(e) => setEditForm({ ...editForm, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono font-bold text-emerald-600"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Address & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    বর্তমান পূর্ণ ঠিকানা
                  </label>
                  <input
                    type="text"
                    value={editForm.address}
                    onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    ইমেইল ঠিকানা (ঐচ্ছিক)
                  </label>
                  <input
                    type="email"
                    placeholder="patient@example.com"
                    value={editForm.email}
                    onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 4: Emergency contact & Homeopathic Constitutional Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    জরুরি অভিভাবক / যোগাযোগ নম্বর
                  </label>
                  <input
                    type="text"
                    placeholder="অভিভাবকের নাম ও মোবাইল নম্বর"
                    value={editForm.emergencyContact}
                    onChange={(e) => setEditForm({ ...editForm, emergencyContact: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    হোমিওপ্যাথিক ধাতুগত প্রকৃতি / মায়াজম
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: সোরা (Psora), সাইকোসিস, সালফার কনস্টিটিউশন"
                    value={editForm.constitutionalType}
                    onChange={(e) => setEditForm({ ...editForm, constitutionalType: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 5: Chronic Conditions & Allergies */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    প্রধান রোগ ও লক্ষণ (কমা দিয়ে একাধিক লিখুন)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: ক্রনিক গ্যাস্ট্রাইটিস, অ্যালার্জি, একজিমা"
                    value={editForm.chronicConditions}
                    onChange={(e) => setEditForm({ ...editForm, chronicConditions: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    ওষুধ ও খাদ্যে অ্যালার্জি / সংবেদনশীলতা
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: গরুর দুধ, ধুলোবালি, চিংড়ি মাছ"
                    value={editForm.allergies}
                    onChange={(e) => setEditForm({ ...editForm, allergies: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Row 6: First Visit, Last Visit, Total Visits, Total Prescriptions */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-gray-50 dark:bg-[#131b1e] p-3 rounded-xl border border-gray-200 dark:border-gray-800">
                <div>
                  <label className="block font-bold mb-1 text-gray-600 dark:text-gray-400">
                    প্রথম ভিজিট
                  </label>
                  <input
                    type="date"
                    value={editForm.firstVisitDate}
                    onChange={(e) => setEditForm({ ...editForm, firstVisitDate: e.target.value })}
                    className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-600 dark:text-gray-400">
                    সর্বশেষ ভিজিট
                  </label>
                  <input
                    type="date"
                    value={editForm.lastVisitDate}
                    onChange={(e) => setEditForm({ ...editForm, lastVisitDate: e.target.value })}
                    className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-600 dark:text-gray-400">
                    মোট ভিজিট সংখ্যা
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editForm.totalVisits}
                    onChange={(e) => setEditForm({ ...editForm, totalVisits: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-gray-600 dark:text-gray-400">
                    প্রেসক্রিপশন সংখ্যা
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editForm.totalPrescriptions}
                    onChange={(e) => setEditForm({ ...editForm, totalPrescriptions: Number(e.target.value) })}
                    className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] font-mono text-[11px]"
                  />
                </div>
              </div>

              {/* Row 7: Confidential Doctor Notes */}
              <div>
                <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                  চিকিৎসকের ব্যক্তিগত পর্যবেক্ষণ ও গোপনীয় নোট
                </label>
                <textarea
                  rows={2}
                  placeholder="রোগীর মানসিক অবস্থা, পারিবারিক ইতিহাস বা চিকিৎসা সংক্রান্ত বিশেষ পর্যবেক্ষণ..."
                  value={editForm.notes}
                  onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                />
              </div>

              {/* Form Buttons */}
              <div className="pt-3 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setEditingPatient(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl font-bold transition"
                >
                  বাতিল করুন
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-xl shadow-xs transition flex items-center space-x-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>তথ্য আপডেট ও সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PATIENT DETAIL VIEW MODAL (রোগীর পূর্ণাঙ্গ প্রোফাইল ভিউ)                  */}
      {/* ========================================================================= */}
      {viewingPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700 animate-scale-up">
            <div className="flex justify-between items-start pb-3 border-b border-gray-200 dark:border-gray-800">
              <div>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white flex items-center space-x-2">
                  <span>{viewingPatient.name}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                    {viewingPatient.bloodGroup || 'ব্লাড গ্রুপ N/A'}
                  </span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  আইডি: {viewingPatient.id} • {viewingPatient.gender}, {viewingPatient.age} বছর
                </p>
              </div>
              <button
                onClick={() => setViewingPatient(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-gray-50 dark:bg-[#131b1e] p-3 rounded-xl border border-gray-200 dark:border-gray-800">
                <div>
                  <span className="text-gray-400 block">মোবাইল নম্বর</span>
                  <span className="font-mono font-bold text-gray-900 dark:text-white">{viewingPatient.phone}</span>
                </div>
                <div>
                  <span className="text-gray-400 block">ঠিকানা</span>
                  <span className="text-gray-900 dark:text-white">{viewingPatient.address}</span>
                </div>
                {viewingPatient.email && (
                  <div>
                    <span className="text-gray-400 block">ইমেইল</span>
                    <span className="text-gray-900 dark:text-white font-mono">{viewingPatient.email}</span>
                  </div>
                )}
                {viewingPatient.emergencyContact && (
                  <div>
                    <span className="text-gray-400 block">জরুরি যোগাযোগ</span>
                    <span className="text-gray-900 dark:text-white">{viewingPatient.emergencyContact}</span>
                  </div>
                )}
              </div>

              {viewingPatient.constitutionalType && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900">
                  <span className="text-amber-800 dark:text-amber-300 font-bold block">হোমিওপ্যাথিক প্রকৃতি / মায়াজম:</span>
                  <span className="text-gray-800 dark:text-gray-200">{viewingPatient.constitutionalType}</span>
                </div>
              )}

              <div>
                <span className="text-gray-500 font-bold block mb-1">প্রধান স্বাস্থ্য সমস্যা / রোগ:</span>
                <div className="flex flex-wrap gap-1">
                  {(viewingPatient.chronicConditions || []).length > 0 ? (
                    viewingPatient.chronicConditions.map((cond, idx) => (
                      <span key={idx} className="px-2 py-1 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900 rounded-lg text-[11px]">
                        {cond}
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-400">কোনো ক্রনিক সমস্যা উল্লেখ নেই</span>
                  )}
                </div>
              </div>

              {viewingPatient.allergies && viewingPatient.allergies.length > 0 && (
                <div>
                  <span className="text-gray-500 font-bold block mb-1">অ্যালার্জি ও সংবেদনশীলতা:</span>
                  <div className="flex flex-wrap gap-1">
                    {viewingPatient.allergies.map((alg, idx) => (
                      <span key={idx} className="px-2 py-0.5 bg-orange-50 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 rounded text-[11px]">
                        {alg}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {viewingPatient.notes && (
                <div className="p-3 bg-blue-50/50 dark:bg-blue-950/30 rounded-xl border border-blue-100 dark:border-blue-900/50">
                  <span className="text-[#2271b1] font-bold block mb-0.5">চিকিৎসকের গোপনীয় নোট:</span>
                  <p className="text-gray-700 dark:text-gray-300 italic">{viewingPatient.notes}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 text-center pt-2">
                <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <span className="text-[10px] text-gray-400 block">মোট ভিজিট</span>
                  <span className="text-base font-bold font-mono text-purple-600">{viewingPatient.totalVisits || 1} বার</span>
                </div>
                <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <span className="text-[10px] text-gray-400 block">মোট প্রেসক্রিপশন</span>
                  <span className="text-base font-bold font-mono text-emerald-600">{viewingPatient.totalPrescriptions || 0} টি</span>
                </div>
              </div>
            </div>

            <div className="mt-5 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800 pt-3">
              <button
                onClick={() => {
                  const pat = viewingPatient;
                  setViewingPatient(null);
                  handleStartEdit(pat);
                }}
                className="px-4 py-2 bg-[#2271b1] hover:bg-[#135e96] text-white rounded-xl font-bold flex items-center space-x-1"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>এডিট করুন</span>
              </button>
              <button
                onClick={() => setViewingPatient(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl font-bold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DELETE CONFIRMATION MODAL                                                 */}
      {/* ========================================================================= */}
      {deletingPatientId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-300 dark:border-gray-700 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-base text-gray-900 dark:text-white">
              রোগী ডাটাবেজ থেকে মুছে ফেলতে চান?
            </h4>
            <p className="text-xs text-gray-500 mt-1">
              এই রোগীর সকল হিস্ট্রি ডাটাবেজ থেকে স্থায়ীভাবে অপসারিত হবে।
            </p>
            <div className="mt-4 flex justify-center space-x-2">
              <button
                onClick={() => setDeletingPatientId(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold"
              >
                বাতিল
              </button>
              <button
                onClick={() => handleConfirmDelete(deletingPatientId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold"
              >
                হ্যাঁ, মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ADD PATIENT MODAL                                                         */}
      {/* ========================================================================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700 my-8">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
              <h3 className="font-bold text-base text-gray-900 dark:text-white flex items-center space-x-2">
                <Plus className="w-4 h-4 text-[#2271b1]" />
                <span>নতুন রোগী নিবন্ধন ফর্ম</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePatient} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1">রোগীর পূর্ণ নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মোঃ কামরুল ইসলাম"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold mb-1">বয়স</label>
                  <input
                    type="number"
                    value={newAge}
                    onChange={(e) => setNewAge(e.target.value ? Number(e.target.value) : '')}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">লিঙ্গ</label>
                  <select
                    value={newGender}
                    onChange={(e) => setNewGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="শিশু">শিশু</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">ব্লাড গ্রুপ</label>
                  <select
                    value={newBloodGroup}
                    onChange={(e) => setNewBloodGroup(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৭১১-XXXXXX"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">ঠিকানা</label>
                  <input
                    type="text"
                    placeholder="উত্তরা, ঢাকা"
                    value={newAddress}
                    onChange={(e) => setNewAddress(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">দীর্ঘমেয়াদী রোগ / স্বাস্থ্য লক্ষণ (কমা দিয়ে লিখুন)</label>
                <input
                  type="text"
                  placeholder="যেমন: হাঁপানি, একজিমা, ক্রনিক এসিডিটি"
                  value={newChronicCondition}
                  onChange={(e) => setNewChronicCondition(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">হোমিওপ্যাথিক প্রকৃতি / মায়াজম (ঐচ্ছিক)</label>
                <input
                  type="text"
                  placeholder="যেমন: সোরা, সাইকোসিস, লাইকোপোডিয়াম কনস্টিটিউশন"
                  value={newConstitutionalType}
                  onChange={(e) => setNewConstitutionalType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 rounded-xl font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition"
                >
                  নিবন্ধন সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
