import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { DashboardConfig, Appointment } from '../../types.ts';
import {
  Users,
  Calendar,
  FileText,
  Clock,
  Activity,
  CheckCircle2,
  AlertCircle,
  Volume2,
  ArrowRight,
  ShieldCheck,
  Plus,
  Save,
  RefreshCw,
  SlidersHorizontal,
  Edit3,
  Edit2,
  X,
  Check,
  RotateCcw,
  User,
  PhoneCall,
  Stethoscope
} from 'lucide-react';

export const DashboardTab: React.FC = () => {
  const {
    appointments,
    prescriptions,
    patients,
    auditLogs,
    settings,
    doctors,
    isOnline,
    updateAppointmentStatus,
    updateAppointment,
    deleteAppointment,
    setIsBookingModalOpen,
    setAdminSubTab,
    logAction,
    updateChamberSettings,
    addAuditLog,
    isMasterAuthenticated
  } = useClinic();

  const defaultDashConfig: DashboardConfig = {
    welcomeTitle: 'হোমিও আরোগ্য নিকেতন ড্যাশবোর্ডে স্বাগতম!',
    welcomeSubtitle: 'ওয়ার্ডপ্রেস CMS এর মাধ্যমে ক্লিনিকের সকল অ্যাপয়েন্টমেন্ট, ডিজিটাল প্রেসক্রিপশন ও রোগীর ইতিহাস লাইভ পর্যবেক্ষণ করুন।',
    quickBtnText: 'নতুন প্রেসক্রিপশন লিখুন',
    appointmentBtnText: 'অ্যাপয়েন্টমেন্ট ও সিরিয়াল',
    appointmentBtnAction: 'appointments',
    appointmentBtnVisible: true,
    stat1Title: 'আজকের অ্যাপয়েন্টমেন্ট',
    stat1Sub: 'মোট শিডিউলভুক্ত সিরিয়াল',
    stat2Title: 'মোট নিবন্ধিত রোগী',
    stat2Sub: 'স্থানীয় ডাটাবেসে সংরক্ষিত',
    stat3Title: 'ডিজিটাল প্রেসক্রিপশন',
    stat3Sub: 'মেটেরিয়া মেডিকা যুক্ত',
    stat4Title: 'অপেক্ষমাণ রোগী (Queue)',
    stat4Sub: 'বর্তমান ওয়েটিং রুমে উপস্থিত',
    queueBoxTitle: 'রিয়েল-টাইম রোগী ওয়েটিং রুম ও সিরিয়াল কলিং (Live Queue)',
    dashboardNotice: 'সতর্কতা: সকল রোগীর গোপনীয় তথ্য সংরক্ষিত। চেম্বারের অভ্যন্তরীণ ডাটাবেস পরিবর্তনের পূর্বে ব্যাকআপ নিশ্চিত করুন।'
  };

  const dashConfig = settings.dashboardConfig || defaultDashConfig;
  const [isEditDashboardOpen, setIsEditDashboardOpen] = useState(false);
  const [dashboardForm, setDashboardForm] = useState<DashboardConfig>(dashConfig);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);

  // Appointment Edit Modal State on Dashboard
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [isEditAptModalOpen, setIsEditAptModalOpen] = useState(false);
  const [aptForm, setAptForm] = useState({
    patientName: '',
    patientAge: 0,
    patientGender: 'পুরুষ' as Appointment['patientGender'],
    phone: '',
    doctorId: '',
    doctorName: '',
    date: '',
    timeSlot: '',
    symptoms: '',
    status: 'pending' as Appointment['status'],
    priority: 'normal' as Appointment['priority'],
    consultationType: 'chamber' as Appointment['consultationType']
  });

  const handleOpenEditAppointment = (apt: Appointment) => {
    setEditingAppointment(apt);
    setAptForm({
      patientName: apt.patientName,
      patientAge: apt.patientAge,
      patientGender: apt.patientGender,
      phone: apt.phone,
      doctorId: apt.doctorId,
      doctorName: apt.doctorName,
      date: apt.date,
      timeSlot: apt.timeSlot,
      symptoms: apt.symptoms,
      status: apt.status,
      priority: apt.priority,
      consultationType: apt.consultationType
    });
    setIsEditAptModalOpen(true);
  };

  const handleSaveAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAppointment) return;
    const doc = doctors.find(d => d.id === aptForm.doctorId);
    const updatedDoctorName = doc ? doc.name : aptForm.doctorName;
    updateAppointment(editingAppointment.id, {
      ...aptForm,
      doctorName: updatedDoctorName
    });
    logAction('অ্যাপয়েন্টমেন্ট এডিট (Dashboard)', `ড্যাশবোর্ড থেকে #${editingAppointment.tokenNumber} (${aptForm.patientName}) এর তথ্য সফলভাবে আপডেট করা হয়েছে।`, 'info');
    setIsEditAptModalOpen(false);
    setEditingAppointment(null);
  };

  const handleOpenEdit = () => {
    setDashboardForm(settings.dashboardConfig || defaultDashConfig);
    setIsEditDashboardOpen(true);
  };

  const handleSaveDashboardConfig = (e: React.FormEvent) => {
    e.preventDefault();
    updateChamberSettings({ dashboardConfig: dashboardForm });
    addAuditLog('ড্যাশবোর্ড অপশন আপডেট', 'অ্যাডমিন কর্তৃক ড্যাশবোর্ডের ব্যানার, বাটন, কার্ড ও কিউ টাইটেল সফলভাবে আপডেট করা হয়েছে।', 'info');
    setIsEditDashboardOpen(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 3000);
  };

  const handleResetDashboardConfig = () => {
    if (window.confirm('আপনি কি ড্যাশবোর্ড অপশনগুলো ডিফল্ট অবস্থায় ফিরিয়ে নিতে চান?')) {
      setDashboardForm(defaultDashConfig);
      updateChamberSettings({ dashboardConfig: defaultDashConfig });
      addAuditLog('ড্যাশবোর্ড অপশন রিসেট', 'ড্যাশবোর্ডের সকল অপশন ডিফল্ট অবস্থায় ফিরিয়ে নেওয়া হয়েছে।', 'warning');
      setIsEditDashboardOpen(false);
      setSaveSuccessNotice(true);
      setTimeout(() => setSaveSuccessNotice(false), 3000);
    }
  };

  const [quickNoteTitle, setQuickNoteTitle] = useState('');
  const [quickNoteContent, setQuickNoteContent] = useState('');
  const [savedNotes, setSavedNotes] = useState<Array<{ id: string; title: string; content: string; date: string }>>([
    {
      id: 'note-1',
      title: 'নতুন ব্যাচ ওষুধ স্টকের আগমন',
      content: 'জার্মানির ডক্টর রিকওয়েগ (Dr. Reckeweg) ও শোয়াবে (Schwabe) মাদার টিংচার ও পোটেন্সির নতুন স্টক চেম্বার ফার্মেসিতে যুক্ত হয়েছে।',
      date: 'আজ'
    }
  ]);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter((a) => a.date === todayStr);
  const activeInConsultation = appointments.find((a) => a.status === 'in-consultation');
  const nextInQueue = appointments.find((a) => a.status === 'confirmed' || a.status === 'pending');

  const handleCallNextPatient = () => {
    if (activeInConsultation) {
      updateAppointmentStatus(activeInConsultation.id, 'completed');
    }
    if (nextInQueue) {
      updateAppointmentStatus(nextInQueue.id, 'in-consultation');
      // Visual chime / notification
      logAction('রোগী আহ্বান (Queue Call)', `টোকেন #${nextInQueue.tokenNumber} (${nextInQueue.patientName}) কে ডাক্তারের রুমে ডাকা হয়েছে।`, 'info');
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.45);
      } catch {}
    }
  };

  const handleSaveQuickNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickNoteTitle.trim() && !quickNoteContent.trim()) return;
    setSavedNotes([
      {
        id: 'note-' + Date.now(),
        title: quickNoteTitle.trim() || 'জরুরি মেমো',
        content: quickNoteContent.trim(),
        date: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
      },
      ...savedNotes
    ]);
    setQuickNoteTitle('');
    setQuickNoteContent('');
  };

  return (
    <div className="space-y-6">
      
      {/* WordPress Welcome Banner */}
      <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            {dashConfig.welcomeTitle}
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 mt-1">
            {dashConfig.welcomeSubtitle}
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0 flex-wrap gap-y-2">
          {/* Dashboard Options Edit Button */}
          <button
            onClick={handleOpenEdit}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
            title="ড্যাশবোর্ডের সকল লেখা ও অ্যাপয়েন্টমেন্ট বাটন এডিট করুন"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>ড্যাশবোর্ড অপশন এডিট</span>
          </button>

          {/* Appointment Button (Customizable & Editable) */}
          {dashConfig.appointmentBtnVisible !== false && (
            <div className="flex items-center shadow-xs rounded-lg overflow-hidden">
              <button
                onClick={() => {
                  if (dashConfig.appointmentBtnAction === 'booking_modal') {
                    setIsBookingModalOpen(true);
                  } else {
                    setAdminSubTab('appointments');
                  }
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition flex items-center space-x-1.5"
                title="অ্যাপয়েন্টমেন্ট বাটন"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{dashConfig.appointmentBtnText || 'অ্যাপয়েন্টমেন্ট ও সিরিয়াল'}</span>
              </button>
              <button
                onClick={handleOpenEdit}
                className="px-2 py-2 bg-emerald-700 hover:bg-emerald-800 text-emerald-100 hover:text-white border-l border-emerald-500/50 transition"
                title="অ্যাপয়েন্টমেন্ট বাটন এডিট করুন"
              >
                <Edit2 className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Prescription Quick Button */}
          <button
            onClick={() => setAdminSubTab('prescriptions')}
            className="px-4 py-2 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{dashConfig.quickBtnText}</span>
          </button>
        </div>
      </div>

      {saveSuccessNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          ড্যাশবোর্ডের সকল অপশন সফলভাবে হালনাগাদ করা হয়েছে!
        </div>
      )}

      {/* Optional Dashboard Notice */}
      {dashConfig.dashboardNotice && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 p-3.5 rounded-xl text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{dashConfig.dashboardNotice}</span>
        </div>
      )}

      {/* WordPress "At a Glance" Stats Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
              {dashConfig.stat1Title}
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950/80 flex items-center justify-center text-sky-600">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2 font-mono">
            {todayAppointments.length}
          </div>
          <div className="text-[11px] text-gray-500 mt-1">
            {dashConfig.stat1Sub}
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
              {dashConfig.stat2Title}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 flex items-center justify-center text-emerald-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2 font-mono">
            {patients.length + 1250}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1 font-medium">
            {dashConfig.stat2Sub}
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
              {dashConfig.stat3Title}
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950/80 flex items-center justify-center text-purple-600">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2 font-mono">
            {prescriptions.length + 840}
          </div>
          <div className="text-[11px] text-purple-600 mt-1 font-medium">
            {dashConfig.stat3Sub}
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
              {dashConfig.stat4Title}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950/80 flex items-center justify-center text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400 mt-2 font-mono">
            {appointments.filter((a) => a.status === 'confirmed' || a.status === 'pending').length}
          </div>
          <div className="text-[11px] text-gray-500 mt-1">
            {dashConfig.stat4Sub}
          </div>
        </div>

      </div>

      {/* Main Two Columns: Live Queue & Site Health / Quick Draft */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (8 cols): Live Patient Queue & Waiting Room Manager */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Live Queue Box */}
          <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs overflow-hidden">
            <div className="bg-gray-100 dark:bg-[#151a1e] px-5 py-3.5 border-b border-gray-300 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Volume2 className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                  {dashConfig.queueBoxTitle}
                </h3>
              </div>
              <button
                onClick={handleCallNextPatient}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>পরবর্তী রোগী আহ্বান করুন</span>
              </button>
            </div>

            <div className="p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
                
                {/* Currently In Doctor Room */}
                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                      ডাক্তারের রুমে অবস্থানরত (Now Consulting)
                    </span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                  </div>
                  {activeInConsultation ? (
                    <div>
                      <div className="text-xl font-black text-emerald-950 dark:text-emerald-100 font-mono">
                        #TK-{activeInConsultation.tokenNumber}
                      </div>
                      <div className="font-bold text-sm text-gray-900 dark:text-white mt-1">
                        {activeInConsultation.patientName} ({activeInConsultation.patientAge} বছর)
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 line-clamp-1">
                        সমস্যা: {activeInConsultation.symptoms}
                      </div>
                      <div className="mt-3 flex gap-2 flex-wrap">
                        <button
                          onClick={() => handleOpenEditAppointment(activeInConsultation)}
                          className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold text-[11px] rounded-md transition flex items-center gap-1 shadow-xs"
                          title="অ্যাপয়েন্টমেন্ট তথ্য এডিট করুন"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>এডিট</span>
                        </button>
                        <button
                          onClick={() => {
                            setAdminSubTab('prescriptions');
                          }}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-md transition"
                        >
                          প্রেসক্রিপশন লিখুন
                        </button>
                        <button
                          onClick={() => updateAppointmentStatus(activeInConsultation.id, 'completed')}
                          className="px-3 py-1 bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-[11px] rounded-md transition"
                        >
                          সম্পন্ন চিহ্নিত করুন
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-gray-500 py-3">
                      বর্তমানে কোনো রোগী ডাক্তারের রুমে নেই।
                    </div>
                  )}
                </div>

                {/* Next In Line */}
                <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider">
                      পরবর্তী অপেক্ষমাণ সিরিয়াল (Next In Queue)
                    </span>
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                  </div>
                  {nextInQueue ? (
                    <div>
                      <div className="text-xl font-black text-amber-950 dark:text-amber-100 font-mono">
                        #TK-{nextInQueue.tokenNumber}
                      </div>
                      <div className="font-bold text-sm text-gray-900 dark:text-white mt-1">
                        {nextInQueue.patientName} ({nextInQueue.timeSlot})
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 line-clamp-1">
                        {nextInQueue.phone} — {nextInQueue.doctorName}
                      </div>
                      <div className="mt-3 flex gap-2">
                        <button
                          onClick={() => handleOpenEditAppointment(nextInQueue)}
                          className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold text-[11px] rounded-md transition flex items-center gap-1 shadow-xs"
                          title="অ্যাপয়েন্টমেন্ট তথ্য এডিট করুন"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>এডিট</span>
                        </button>
                        <button
                          onClick={() => updateAppointmentStatus(nextInQueue.id, 'in-consultation')}
                          className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] rounded-md transition"
                        >
                          রুমে প্রবেশ করান
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-gray-500 py-3">
                      আর কোনো রোগী অপেক্ষমাণ নেই।
                    </div>
                  )}
                </div>

              </div>

              {/* Today's Full Schedule Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-500 font-bold">
                      <th className="py-2">টোকেন</th>
                      <th className="py-2">রোগীর নাম</th>
                      <th className="py-2">মোবাইল</th>
                      <th className="py-2">সময়</th>
                      <th className="py-2">চিকিৎসক</th>
                      <th className="py-2">স্ট্যাটাস</th>
                      <th className="py-2 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                    {todayAppointments.map((apt) => (
                      <tr key={apt.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/40">
                        <td className="py-2.5 font-mono font-bold text-emerald-600">
                          #TK-{apt.tokenNumber}
                        </td>
                        <td className="py-2.5 font-semibold text-gray-900 dark:text-white">
                          {apt.patientName} ({apt.patientAge}ব, {apt.patientGender})
                        </td>
                        <td className="py-2.5 font-mono text-gray-500">{apt.phone}</td>
                        <td className="py-2.5 text-gray-600 dark:text-gray-400">{apt.timeSlot}</td>
                        <td className="py-2.5 text-gray-700 dark:text-gray-300">{apt.doctorName}</td>
                        <td className="py-2.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              apt.status === 'in-consultation'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : apt.status === 'completed'
                                ? 'bg-gray-200 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
                                : apt.status === 'confirmed'
                                ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            }`}
                          >
                            {apt.status === 'in-consultation'
                              ? 'পরামর্শ চলছে'
                              : apt.status === 'completed'
                              ? 'সম্পন্ন'
                              : apt.status === 'confirmed'
                              ? 'নিশ্চিত'
                              : 'পেন্ডিং'}
                          </span>
                        </td>
                        <td className="py-2.5 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => handleOpenEditAppointment(apt)}
                            className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 dark:bg-amber-950/80 dark:text-amber-300 rounded text-[11px] font-bold inline-flex items-center gap-1 transition"
                            title="অ্যাপয়েন্টমেন্ট এডিট করুন"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>এডিট</span>
                          </button>
                          <button
                            onClick={() => updateAppointmentStatus(apt.id, 'completed')}
                            className="px-2 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 rounded text-[10px]"
                            title="সম্পন্ন করুন"
                          >
                            ✓
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Recent Activity Audit Feed */}
          <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 p-5 shadow-xs">
            <h3 className="font-bold text-sm text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
              <Activity className="w-4 h-4 text-[#2271b1]" />
              <span>সাম্প্রতিক চেম্বার কার্যক্রম ও সিস্টেম ইভেন্ট (Live Stream)</span>
            </h3>

            <div className="space-y-2.5 text-xs">
              {auditLogs.slice(0, 5).map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 rounded-lg bg-gray-50 dark:bg-[#151a1e] border border-gray-200 dark:border-gray-800 flex items-start justify-between"
                >
                  <div>
                    <div className="font-bold text-gray-800 dark:text-gray-200">
                      {log.action}
                    </div>
                    <div className="text-gray-600 dark:text-gray-400 text-[11px] mt-0.5">
                      {log.details}
                    </div>
                  </div>
                  <div className="text-[10px] text-gray-400 shrink-0 font-mono ml-2">
                    {log.timestamp}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column (4 cols): Site Health & Quick Draft Note */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* WordPress Site Health Widget */}
          <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3 border-b border-gray-200 dark:border-gray-800 pb-2">
              <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>সাইট হেলথ (Site Health)</span>
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                চমৎকার (Good)
              </span>
            </div>

            <ul className="space-y-2.5 text-xs text-gray-600 dark:text-gray-400">
              <li className="flex items-center justify-between">
                <span>ডাটাবেজ এনক্রিপশন:</span>
                <span className="font-bold text-emerald-600">সক্রিয় (AES-Salt)</span>
              </li>
              <li className="flex items-center justify-between">
                <span>মাস্টার সিকিউরিটি:</span>
                <span className="font-bold text-emerald-600">লকড ও সুরক্ষিত</span>
              </li>
              <li className="flex items-center justify-between">
                <span>অফলাইন লোকাল স্টোরেজ:</span>
                <span className="font-bold text-emerald-600">১০০% কার্যকর</span>
              </li>
              <li className="flex items-center justify-between">
                <span>ক্লাউড সিঙ্ক্রোনাইজেশন:</span>
                <span className="font-bold text-sky-600">{isOnline ? 'কানেক্টেড' : 'অফলাইন মোড'}</span>
              </li>
              <li className="flex items-center justify-between">
                <span>অটো ব্যাকআপ:</span>
                <span className="font-bold text-gray-800 dark:text-gray-200">দৈনিক সক্রিয়</span>
              </li>
            </ul>
          </div>

          {/* WordPress Quick Draft Widget */}
          <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 p-5 shadow-xs">
            <h3 className="font-bold text-sm text-gray-900 dark:text-white mb-2">
              কুইক ড্রাফট ও মেমো (Quick Draft)
            </h3>
            <p className="text-xs text-gray-500 mb-3">
              চেম্বারের জরুরি নোট বা ড্রাফট দ্রুত সংরক্ষণ করুন।
            </p>

            <form onSubmit={handleSaveQuickNote} className="space-y-2.5 text-xs">
              <input
                type="text"
                placeholder="শিরোনাম (Title)"
                value={quickNoteTitle}
                onChange={(e) => setQuickNoteTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#151a1e] text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
              />
              <textarea
                rows={3}
                placeholder="কী মনে রাখতে চান? (রোগীর ওষুধ সংক্রান্ত নোট ইত্যাদি)..."
                value={quickNoteContent}
                onChange={(e) => setQuickNoteContent(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#151a1e] text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
              />
              <button
                type="submit"
                className="w-full py-2 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-lg transition flex items-center justify-center space-x-1"
              >
                <Save className="w-3.5 h-3.5" />
                <span>ড্রাফট সেভ করুন</span>
              </button>
            </form>

            {/* List of saved notes */}
            {savedNotes.length > 0 && (
              <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-800 space-y-2">
                <span className="text-[11px] font-bold text-gray-500 uppercase">
                  সংরক্ষিত ড্রাফট:
                </span>
                {savedNotes.map((note) => (
                  <div
                    key={note.id}
                    className="p-2.5 rounded-lg bg-gray-50 dark:bg-[#151a1e] border border-gray-200 dark:border-gray-800 text-xs"
                  >
                    <div className="font-bold text-gray-900 dark:text-white">
                      {note.title}
                    </div>
                    <div className="text-gray-600 dark:text-gray-400 text-[11px] mt-0.5">
                      {note.content}
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 font-mono">{note.date}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Dashboard Customization Modal */}
      {isEditDashboardOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-amber-100 dark:bg-amber-950/80 rounded-lg text-amber-700 dark:text-amber-400">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    ড্যাশবোর্ড অপশন ও ইন্টারফেস সম্পাদনা
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    ড্যাশবোর্ডের স্বাগতম ব্যানার, স্ট্যাটাস কার্ড, বাটন এবং নোটিশ পরিবর্তন করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditDashboardOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDashboardConfig} className="mt-5 space-y-5">
              
              {/* Section 1: Welcome Banner & Quick CTA */}
              <div className="space-y-3 bg-gray-50 dark:bg-gray-900/60 p-4 rounded-xl border border-gray-200 dark:border-gray-800">
                <h4 className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5 uppercase tracking-wider">
                  ১. স্বাগতম ব্যানার ও দ্রুত অ্যাকশন
                </h4>
                
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    ব্যানার শিরোনাম (Welcome Title) *
                  </label>
                  <input
                    type="text"
                    required
                    value={dashboardForm.welcomeTitle}
                    onChange={(e) => setDashboardForm({ ...dashboardForm, welcomeTitle: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    ব্যানার সাবটাইটেল (Welcome Subtitle)
                  </label>
                  <textarea
                    rows={2}
                    value={dashboardForm.welcomeSubtitle}
                    onChange={(e) => setDashboardForm({ ...dashboardForm, welcomeSubtitle: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      দ্রুত অ্যাকশন বাটন টেক্সট
                    </label>
                    <input
                      type="text"
                      value={dashboardForm.quickBtnText}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, quickBtnText: e.target.value })}
                      placeholder="নতুন প্রেসক্রিপশন লিখুন"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      লাইভ কিউ বক্সের শিরোনাম
                    </label>
                    <input
                      type="text"
                      value={dashboardForm.queueBoxTitle}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, queueBoxTitle: e.target.value })}
                      placeholder="রিয়েল-টাইম রোগী ওয়েটিং রুম..."
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    ড্যাশবোর্ড জরুরি নোটিশ ব্যানার (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={dashboardForm.dashboardNotice || ''}
                    onChange={(e) => setDashboardForm({ ...dashboardForm, dashboardNotice: e.target.value })}
                    placeholder="সতর্কতা বা জরুরি বার্তা যা ব্যানারের নিচে শো করবে..."
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                {/* Appointment Button Settings */}
                <div className="p-3.5 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-emerald-600" />
                      অ্যাপয়েন্টমেন্ট বাটন কনফিগারেশন
                    </h5>
                    <label className="flex items-center gap-1.5 cursor-pointer text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                      <input
                        type="checkbox"
                        checked={dashboardForm.appointmentBtnVisible !== false}
                        onChange={(e) => setDashboardForm({ ...dashboardForm, appointmentBtnVisible: e.target.checked })}
                        className="rounded border-emerald-400 text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      <span>বাটনটি ড্যাশবোর্ডে সক্রিয় রাখুন</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-gray-700 dark:text-gray-300 mb-1">
                        অ্যাপয়েন্টমেন্ট বাটন টেক্সট / লেবেল
                      </label>
                      <input
                        type="text"
                        value={dashboardForm.appointmentBtnText || ''}
                        onChange={(e) => setDashboardForm({ ...dashboardForm, appointmentBtnText: e.target.value })}
                        placeholder="যেমন: অ্যাপয়েন্টমেন্ট ও সিরিয়াল / নতুন সিরিয়াল নিন"
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-gray-700 dark:text-gray-300 mb-1">
                        বাটনে ক্লিক অ্যাকশন
                      </label>
                      <select
                        value={dashboardForm.appointmentBtnAction || 'appointments'}
                        onChange={(e) => setDashboardForm({ ...dashboardForm, appointmentBtnAction: e.target.value as any })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      >
                        <option value="appointments">অ্যাপয়েন্টমেন্ট পরিচালনা ট্যাবে যান</option>
                        <option value="booking_modal">সরাসরি নতুন বুকিং ফর্ম মডাল ওপেন করুন</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: Four "At a Glance" Stats Cards */}
              <div className="space-y-3 bg-gray-50 dark:bg-gray-900/60 p-4 rounded-xl border border-gray-200 dark:border-gray-800">
                <h4 className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5 uppercase tracking-wider">
                  ২. চারটি স্ট্যাটাস কার্ড (At a Glance)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Card 1 */}
                  <div className="p-3 bg-white dark:bg-gray-800/80 rounded-lg border border-gray-200 dark:border-gray-700 space-y-2">
                    <span className="text-[10px] font-bold text-sky-600 uppercase">কার্ড ১ (অ্যাপয়েন্টমেন্ট)</span>
                    <input
                      type="text"
                      placeholder="কার্ড শিরোনাম"
                      value={dashboardForm.stat1Title}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat1Title: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="সাবটাইটেল"
                      value={dashboardForm.stat1Sub}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat1Sub: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                  </div>

                  {/* Card 2 */}
                  <div className="p-3 bg-white dark:bg-gray-800/80 rounded-lg border border-gray-200 dark:border-gray-700 space-y-2">
                    <span className="text-[10px] font-bold text-emerald-600 uppercase">কার্ড ২ (নিবন্ধিত রোগী)</span>
                    <input
                      type="text"
                      placeholder="কার্ড শিরোনাম"
                      value={dashboardForm.stat2Title}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat2Title: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="সাবটাইটেল"
                      value={dashboardForm.stat2Sub}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat2Sub: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                  </div>

                  {/* Card 3 */}
                  <div className="p-3 bg-white dark:bg-gray-800/80 rounded-lg border border-gray-200 dark:border-gray-700 space-y-2">
                    <span className="text-[10px] font-bold text-purple-600 uppercase">কার্ড ৩ (প্রেসক্রিপশন)</span>
                    <input
                      type="text"
                      placeholder="কার্ড শিরোনাম"
                      value={dashboardForm.stat3Title}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat3Title: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="সাবটাইটেল"
                      value={dashboardForm.stat3Sub}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat3Sub: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                  </div>

                  {/* Card 4 */}
                  <div className="p-3 bg-white dark:bg-gray-800/80 rounded-lg border border-gray-200 dark:border-gray-700 space-y-2">
                    <span className="text-[10px] font-bold text-amber-600 uppercase">কার্ড ৪ (কিউ / অপেক্ষমাণ)</span>
                    <input
                      type="text"
                      placeholder="কার্ড শিরোনাম"
                      value={dashboardForm.stat4Title}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat4Title: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="সাবটাইটেল"
                      value={dashboardForm.stat4Sub}
                      onChange={(e) => setDashboardForm({ ...dashboardForm, stat4Sub: e.target.value })}
                      className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={handleResetDashboardConfig}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  ডিফল্ট রিসেট
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditDashboardOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-500 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>ড্যাশবোর্ড অপশন সংরক্ষণ করুন</span>
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Appointment Edit Modal from Dashboard */}
      {isEditAptModalOpen && editingAppointment && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 rounded-lg text-emerald-700 dark:text-emerald-400">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    অ্যাপয়েন্টমেন্ট সম্পাদনা
                    <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-mono font-bold">
                      #TK-{editingAppointment.tokenNumber}
                    </span>
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    রোগীর তথ্য, সিরিয়াল সময়সূচী, চিকিৎসক ও স্ট্যাটাস পরিবর্তন করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsEditAptModalOpen(false);
                  setEditingAppointment(null);
                }}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAppointment} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    রোগীর নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={aptForm.patientName}
                    onChange={(e) => setAptForm({ ...aptForm, patientName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    মোবাইল নম্বর *
                  </label>
                  <input
                    type="text"
                    required
                    value={aptForm.phone}
                    onChange={(e) => setAptForm({ ...aptForm, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      বয়স
                    </label>
                    <input
                      type="number"
                      value={aptForm.patientAge}
                      onChange={(e) => setAptForm({ ...aptForm, patientAge: Number(e.target.value) })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      লিঙ্গ
                    </label>
                    <select
                      value={aptForm.patientGender}
                      onChange={(e) => setAptForm({ ...aptForm, patientGender: e.target.value as any })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                      <option value="পুরুষ">পুরুষ</option>
                      <option value="মহিলা">মহিলা</option>
                      <option value="শিশু">শিশু</option>
                      <option value="অন্যান্য">অন্যান্য</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    চিকিৎসক নির্বাচন *
                  </label>
                  <select
                    value={aptForm.doctorId}
                    onChange={(e) => {
                      const selDoc = doctors.find(d => d.id === e.target.value);
                      setAptForm({
                        ...aptForm,
                        doctorId: e.target.value,
                        doctorName: selDoc ? selDoc.name : aptForm.doctorName
                      });
                    }}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    {doctors.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.designation})</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      তারিখ
                    </label>
                    <input
                      type="date"
                      value={aptForm.date}
                      onChange={(e) => setAptForm({ ...aptForm, date: e.target.value })}
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                      সময়সূচী
                    </label>
                    <input
                      type="text"
                      value={aptForm.timeSlot}
                      onChange={(e) => setAptForm({ ...aptForm, timeSlot: e.target.value })}
                      placeholder="যেমন: বিকাল ৫:৩০"
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    রোগের লক্ষণ বা প্রধান সমস্যা
                  </label>
                  <textarea
                    rows={2}
                    value={aptForm.symptoms}
                    onChange={(e) => setAptForm({ ...aptForm, symptoms: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    সিরিয়াল স্ট্যাটাস
                  </label>
                  <select
                    value={aptForm.status}
                    onChange={(e) => setAptForm({ ...aptForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="pending">পেন্ডিং (অপেক্ষমাণ)</option>
                    <option value="confirmed">নিশ্চিত (Confirmed)</option>
                    <option value="in-consultation">পরামর্শ চলছে (In Doctor Room)</option>
                    <option value="completed">সম্পন্ন (Completed)</option>
                    <option value="cancelled">বাতিল (Cancelled)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    পরামর্শের ধরন
                  </label>
                  <select
                    value={aptForm.consultationType}
                    onChange={(e) => setAptForm({ ...aptForm, consultationType: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="chamber">চেম্বার সরাসরি ভিজিট</option>
                    <option value="online">অনলাইন টেলি-পরামর্শ</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditAptModalOpen(false);
                    setEditingAppointment(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>পরিবর্তন সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
