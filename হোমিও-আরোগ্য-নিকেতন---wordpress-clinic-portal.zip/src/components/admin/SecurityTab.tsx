import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { generate2FACode } from '../../utils/crypto.ts';
import {
  Shield,
  KeyRound,
  Lock,
  CheckCircle,
  AlertTriangle,
  Smartphone,
  Eye,
  EyeOff,
  RefreshCw,
  Terminal
} from 'lucide-react';

export const SecurityTab: React.FC = () => {
  const { settings, updateChamberSettings, logAction, adminProfile } = useClinic();

  const [testOtp, setTestOtp] = useState<string>('');
  const [showCurrentMaster, setShowCurrentMaster] = useState(false);
  const [sessionProtection, setSessionProtection] = useState(true);

  const handleGenerateSample2FA = () => {
    const code = generate2FACode();
    setTestOtp(code);
    logAction('2FA ওটিপি জেনারেশন', 'পরীক্ষামূলক টু-ফ্যাক্টর অথেনটিকেশন ওটিপি টোকেন জেনারেট করা হয়েছে।', 'security');
  };

  const handleToggle2FA = (enabled: boolean) => {
    updateChamberSettings({ twoFactorEnabled: enabled });
    logAction('2FA স্ট্যাটাস পরিবর্তন', `টু-ফ্যাক্টর অথেনটিকেশন ${enabled ? 'সক্রিয়' : 'নিষ্ক্রিয়'} করা হয়েছে।`, 'security');
  };

  const handleToggleEncryption = (enabled: boolean) => {
    updateChamberSettings({ encryptionEnabled: enabled });
    logAction('ডাটাবেজ এনক্রিপশন পরিবর্তন', `লোকাল স্টোরেজ এনক্রিপশন ${enabled ? 'সক্রিয়' : 'নিষ্ক্রিয়'} করা হয়েছে।`, 'security');
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
          <Shield className="w-5 h-5 text-emerald-600" />
          <span>মাস্টার সিকিউরিটি ও টু-ফ্যাক্টর অথেন্টিকেশন (2FA)</span>
        </h2>
        <p className="text-xs text-gray-500 mt-0.5">
          চেম্বারের সকল সংবেদনশীল তথ্য ও এডমিন অ্যাক্সেসের সর্বোচ্চ নিরাপত্তা নিয়ন্ত্রণ।
        </p>
      </div>

      {/* Security Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Master Code Status */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 uppercase">মাস্টার সিকিউরিটি</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              সুরক্ষিত
            </span>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-[#131b1e] rounded-lg border border-gray-200 dark:border-gray-800 flex items-center justify-between">
            <span className="text-xs text-gray-600 dark:text-gray-400">মাস্টার কোড:</span>
            <div className="flex items-center space-x-2 font-mono font-bold text-emerald-600">
              <span>{showCurrentMaster ? (adminProfile?.masterSecurityCode || 'AYON540') : '••••••••'}</span>
              <button
                onClick={() => setShowCurrentMaster(!showCurrentMaster)}
                className="text-gray-400 hover:text-gray-600"
              >
                {showCurrentMaster ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <p className="text-[11px] text-gray-500 leading-relaxed">
            মাস্টার সিকিউরিটি কোড ছাড়া কোনো ব্যবহারকারী ওয়ার্ডপ্রেস এডমিন প্যানেলে লগইন করতে পারে না।
          </p>
        </div>

        {/* 2FA Status */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 uppercase">টু-ফ্যাক্টর অথেনটিকেশন</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              settings.twoFactorEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-700'
            }`}>
              {settings.twoFactorEnabled ? 'সক্রিয়' : 'ঐচ্ছিক (অফ)'}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">
              2FA সক্রিয় করুন
            </span>
            <input
              type="checkbox"
              checked={settings.twoFactorEnabled}
              onChange={(e) => handleToggle2FA(e.target.checked)}
              className="w-4 h-4 rounded text-[#2271b1]"
            />
          </div>

          <p className="text-[11px] text-gray-500 leading-relaxed">
            সক্রিয় থাকলে লগইনে মাস্টার কোডের পাশাপাশি ৬-সংখ্যার ডায়নামিক ওটিপি বা ব্যাকআপ কোড আবশ্যক হবে।
          </p>
        </div>

        {/* Encryption Status */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 uppercase">ডাটাবেজ এনক্রিপশন</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
              সক্রিয়
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">
              লোকাল স্টোরেজ এনক্রিপশন
            </span>
            <input
              type="checkbox"
              checked={settings.encryptionEnabled}
              onChange={(e) => handleToggleEncryption(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-600"
            />
          </div>

          <p className="text-[11px] text-gray-500 leading-relaxed">
            রোগীর সমস্ত ব্যক্তিগত তথ্য ও প্রেসক্রিপশন ক্রিপ্টোগ্রাফিক সল্ট দিয়ে এনক্রিপ্ট হয়ে ব্রাউজারে থাকে।
          </p>
        </div>

      </div>

      {/* 2FA Testing & Backup Simulator */}
      <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 text-[#2271b1] border-b border-gray-200 dark:border-gray-800 pb-3">
          <KeyRound className="w-5 h-5" />
          <h3 className="font-bold text-sm text-gray-900 dark:text-white">
            টু-ফ্যাক্টর অথেনটিকেশন (2FA) ওটিপি ভেরিফায়ার
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs items-center">
          <div className="space-y-2">
            <p className="text-gray-600 dark:text-gray-400">
              স্ট্যান্ডার্ড টাইম-বেসড (TOTP) ৩০-সেকেন্ড উইন্ডো কোড অথবা চেম্বার মাস্টার ব্যাকআপ কোড <b>540540</b> দিয়ে যেকোনো সময় লগইন করা যাবে।
            </p>
            <button
              onClick={handleGenerateSample2FA}
              className="px-4 py-2 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-lg transition flex items-center space-x-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>লাইভ ওটিপি কোড জেনারেট করুন</span>
            </button>
          </div>

          {testOtp && (
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-center space-y-1">
              <span className="text-[11px] text-emerald-800 dark:text-emerald-300 font-semibold block">
                চলতি ভ্যালিড ওটিপি কোড (৩০ সেকেন্ড বৈধ):
              </span>
              <div className="text-3xl font-black text-emerald-700 dark:text-emerald-300 font-mono tracking-widest">
                {testOtp}
              </div>
              <span className="text-[10px] text-gray-500 block">
                স্ট্যাটিক জরুরি ব্যাকআপ ওটিপি: <b>540540</b>
              </span>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};
