import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { Appointment, MedicineItem, Prescription } from '../../types.ts';
import {
  Calendar,
  Search,
  Filter,
  Plus,
  CheckCircle,
  Clock,
  XCircle,
  Volume2,
  FileText,
  User,
  Phone,
  Edit2,
  Pill,
  Printer,
  Trash2,
  X,
  AlertTriangle,
  Save,
  CheckCircle2,
  Eye,
  MapPin,
  Check,
  Stethoscope
} from 'lucide-react';

const QUICK_POTENCY_PILLS = ['Q', '6X', '12X', '30C', '200C', '1M', '10M', '0/1', '0/2', '0/3', 'CM'];

const COMMON_REMEDIES = [
  'Arnica Montana',
  'Nux Vomica',
  'Bryonia Alba',
  'Belladonna',
  'Rhus Toxicodendron',
  'Arsenicum Album',
  'Lycopodium Clavatum',
  'Pulsatilla Nigricans',
  'Sulphur',
  'Calcarea Carbonica',
  'Thuja Occidentalis',
  'Silicea',
  'Hepar Sulphuris Calcareum',
  'Gelsemium Sempervirens',
  'Aconitum Napellus',
  'Carbo Vegetabilis',
  'Chamomilla',
  'Phosphorus',
  'Colocynthis',
  'China Officinalis'
];

export const AppointmentsTab: React.FC = () => {
  const {
    appointments,
    doctors,
    prescriptions,
    settings,
    updateAppointmentStatus,
    updateAppointment,
    deleteAppointment,
    bookAppointment,
    addPrescription,
    updatePrescription,
    setSelectedPrescriptionForView,
    setIsPrescriptionLookupOpen,
    setAdminSubTab
  } = useClinic();

  const [searchFilter, setSearchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [doctorFilter, setDoctorFilter] = useState<string>('all');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [medicineEditAppointment, setMedicineEditAppointment] = useState<Appointment | null>(null);
  const [printingAppointment, setPrintingAppointment] = useState<Appointment | null>(null);
  const [deletingAppointment, setDeletingAppointment] = useState<Appointment | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Walk-in Appointment State
  const [walkinName, setWalkinName] = useState('');
  const [walkinAge, setWalkinAge] = useState<number | ''>('');
  const [walkinGender, setWalkinGender] = useState<'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য'>('পুরুষ');
  const [walkinPhone, setWalkinPhone] = useState('');
  const [walkinDoctor, setWalkinDoctor] = useState(doctors[0]?.id || '');
  const [walkinSymptoms, setWalkinSymptoms] = useState('');
  const [walkinAddress, setWalkinAddress] = useState('');

  // Edit Appointment Form State
  const [editForm, setEditForm] = useState<{
    id: string;
    patientName: string;
    patientAge: number | '';
    patientGender: 'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য';
    phone: string;
    address: string;
    email: string;
    date: string;
    timeSlot: string;
    doctorId: string;
    doctorName: string;
    symptoms: string;
    chronicHistory: string;
    previousTreatments: string;
    status: Appointment['status'];
    priority: 'normal' | 'emergency';
    consultationType: 'chamber' | 'online';
  }>({
    id: '',
    patientName: '',
    patientAge: 30,
    patientGender: 'পুরুষ',
    phone: '',
    address: '',
    email: '',
    date: '',
    timeSlot: '',
    doctorId: '',
    doctorName: '',
    symptoms: '',
    chronicHistory: '',
    previousTreatments: '',
    status: 'pending',
    priority: 'normal',
    consultationType: 'chamber'
  });

  // Medicine Edit Form State (for this appointment)
  const [appointmentMedicines, setAppointmentMedicines] = useState<MedicineItem[]>([]);
  const [linkedPrescriptionId, setLinkedPrescriptionId] = useState<string | null>(null);
  const [diagnosisInput, setDiagnosisInput] = useState('');
  const [registerPageNoInput, setRegisterPageNoInput] = useState(''); // খাতার পেজ নম্বর
  const [dietGuidelineInput, setDietGuidelineInput] = useState('কাঁচা পিঁয়াজ, রসুন ও তীব্র কফি পরিহার্য। কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করবেন।');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const filteredAppointments = appointments.filter((apt) => {
    const matchesSearch =
      apt.patientName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (apt.address && apt.address.toLowerCase().includes(searchFilter.toLowerCase())) ||
      apt.phone.includes(searchFilter) ||
      `#tk-${apt.tokenNumber}`.toLowerCase().includes(searchFilter.toLowerCase()) ||
      apt.tokenNumber.toString().includes(searchFilter);
    const matchesStatus = statusFilter === 'all' || apt.status === statusFilter;
    const matchesDoctor = doctorFilter === 'all' || apt.doctorId === doctorFilter;
    return matchesSearch && matchesStatus && matchesDoctor;
  });

  // Open Edit Appointment Modal
  const handleStartEdit = (apt: Appointment) => {
    setEditForm({
      id: apt.id,
      patientName: apt.patientName,
      patientAge: apt.patientAge,
      patientGender: apt.patientGender,
      phone: apt.phone,
      address: apt.address || '',
      email: apt.email || '',
      date: apt.date,
      timeSlot: apt.timeSlot,
      doctorId: apt.doctorId,
      doctorName: apt.doctorName,
      symptoms: apt.symptoms,
      chronicHistory: apt.chronicHistory || '',
      previousTreatments: apt.previousTreatments || '',
      status: apt.status,
      priority: apt.priority,
      consultationType: apt.consultationType
    });
    setEditingAppointment(apt);
  };

  // Save Edit Appointment
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.id || !editForm.patientName.trim() || !editForm.phone.trim()) return;

    const selectedDoc = doctors.find((d) => d.id === editForm.doctorId) || doctors[0];

    updateAppointment(editForm.id, {
      patientName: editForm.patientName.trim(),
      patientAge: Number(editForm.patientAge) || 30,
      patientGender: editForm.patientGender,
      phone: editForm.phone.trim(),
      address: editForm.address.trim() || undefined,
      email: editForm.email.trim() || undefined,
      date: editForm.date,
      timeSlot: editForm.timeSlot,
      doctorId: selectedDoc.id,
      doctorName: selectedDoc.name,
      symptoms: editForm.symptoms.trim(),
      chronicHistory: editForm.chronicHistory.trim() || undefined,
      previousTreatments: editForm.previousTreatments.trim() || undefined,
      status: editForm.status,
      priority: editForm.priority,
      consultationType: editForm.consultationType
    });

    setEditingAppointment(null);
    showToast(`রোগী "${editForm.patientName}" এর অ্যাপয়েন্টমেন্ট সফলভাবে আপডেট হয়েছে!`);
  };

  // Open Medicine Edit Modal for Appointment
  const handleStartMedicineEdit = (apt: Appointment) => {
    setMedicineEditAppointment(apt);

    // Look for existing linked prescription
    const existingRx =
      prescriptions.find((p) => p.appointmentId === apt.id || p.id === apt.prescriptionId) ||
      prescriptions.find((p) => p.patientPhone === apt.phone);

    if (existingRx) {
      setLinkedPrescriptionId(existingRx.id);
      setDiagnosisInput(existingRx.diagnosis || apt.symptoms || 'হোমিওপ্যাথিক চিকিৎসা');
      setDietGuidelineInput(existingRx.notes || 'কাঁচা পিঁয়াজ, রসুন ও তীব্র কফি পরিহার্য।');
      setRegisterPageNoInput(existingRx.registerPageNo || '');
      setAppointmentMedicines(
        existingRx.medicines && existingRx.medicines.length > 0
          ? JSON.parse(JSON.stringify(existingRx.medicines))
          : [
              {
                id: 'med-' + Date.now(),
                name: 'Nux Vomica',
                potency: '200CH',
                dosage: '২ ফোঁটা',
                frequency: 'প্রতি রাতে ঘুমানোর পূর্বে',
                duration: '১৫ দিন',
                timing: 'খাবারের ৩০ মিনিট পর ১ চামচ পানিতে'
              }
            ]
      );
    } else {
      setLinkedPrescriptionId(null);
      setDiagnosisInput(apt.symptoms || 'লক্ষণভিত্তিক পরীক্ষা ও পরামর্শ');
      setDietGuidelineInput('ওষুধ সেবনের ৩০ মিনিট পূর্বে ও পরে মুখ পরিষ্কার রাখবেন। সুপাচ্য খাদ্য গ্রহণ করবেন।');
      setRegisterPageNoInput('');
      setAppointmentMedicines([
        {
          id: 'med-' + Date.now(),
          name: '',
          potency: '30CH',
          dosage: '২ ফোঁটা',
          frequency: 'দিনে ৩ বার',
          duration: '১৫ দিন',
          timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে'
        }
      ]);
    }
  };

  // Medicine items handlers
  const handleAddMedicineRow = () => {
    setAppointmentMedicines((prev) => [
      ...prev,
      {
        id: 'med-' + Date.now(),
        name: '',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'দিনে ৩ বার',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে'
      }
    ]);
  };

  const handleRemoveMedicineRow = (id: string) => {
    if (appointmentMedicines.length <= 1) return;
    setAppointmentMedicines((prev) => prev.filter((m) => m.id !== id));
  };

  const handleMedicineChange = (id: string, field: keyof MedicineItem, value: string) => {
    setAppointmentMedicines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  // Save Medicines for Appointment
  const handleSaveAppointmentMedicines = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicineEditAppointment) return;

    const apt = medicineEditAppointment;
    const doc = doctors.find((d) => d.id === apt.doctorId) || doctors[0];
    const today = new Date().toISOString().split('T')[0];

    if (linkedPrescriptionId) {
      // Update existing prescription
      updatePrescription(linkedPrescriptionId, {
        diagnosis: diagnosisInput.trim() || 'হোমিওপ্যাথিক চিকিৎসা',
        registerPageNo: registerPageNoInput.trim() || undefined,
        medicines: appointmentMedicines,
        notes: dietGuidelineInput.trim()
      });
      showToast(`টোকেন #${apt.tokenNumber} এর প্রেসক্রিপশনের ওষুধ সফলভাবে হালনাগাদ হয়েছে!`);
    } else {
      // Create new prescription and link it to this appointment
      const rxCode = `RX-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
      const newRx = addPrescription({
        prescriptionCode: rxCode,
        registerPageNo: registerPageNoInput.trim() || undefined,
        appointmentId: apt.id,
        patientId: 'pat-' + Date.now(),
        patientName: apt.patientName,
        patientAddress: apt.address || 'চেম্বার ভিজিটর',
        patientAge: apt.patientAge,
        patientGender: apt.patientGender,
        patientPhone: apt.phone,
        date: apt.date || today,
        doctorId: doc.id,
        doctorName: doc.name,
        doctorQualification: doc.qualification,
        diagnosis: diagnosisInput.trim() || apt.symptoms || 'হোমিওপ্যাথিক চিকিৎসা',
        symptoms: apt.symptoms ? [apt.symptoms] : [],
        medicines: appointmentMedicines,
        dietRestrictions: ['কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য', 'তীব্র কফি বর্জনীয়'],
        lifestyleAdvice: ['পর্যাপ্ত কুসুম গরম পানি পান করুন'],
        followUpDate: '১৫ দিন পর',
        notes: dietGuidelineInput.trim()
      });

      // Update appointment with prescriptionId and mark as completed or in-consultation
      updateAppointment(apt.id, {
        prescriptionId: newRx.id,
        status: 'completed'
      });

      showToast(`টোকেন #${apt.tokenNumber} এর জন্য নতুন প্রেসক্রিপশন (${rxCode}) তৈরি ও ওষুধ যুক্ত হয়েছে!`);
    }

    setMedicineEditAppointment(null);
  };

  // Print Appointment Slip / Token
  const handlePrintAppointment = (apt: Appointment) => {
    setPrintingAppointment(apt);
    setTimeout(() => {
      window.print();
    }, 350);
  };

  // Delete Appointment Confirmation
  const handleConfirmDelete = () => {
    if (!deletingAppointment) return;
    const token = deletingAppointment.tokenNumber;
    deleteAppointment(deletingAppointment.id);
    setDeletingAppointment(null);
    showToast(`টোকেন #${token} এর অ্যাপয়েন্টমেন্ট সফলভাবে মুছে ফেলা হয়েছে।`);
  };

  // Handle Add Walk-in
  const handleAddWalkin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkinName.trim() || !walkinPhone.trim()) return;

    const doc = doctors.find((d) => d.id === walkinDoctor) || doctors[0];
    const today = new Date().toISOString().split('T')[0];

    const newApt = bookAppointment({
      patientName: walkinName.trim(),
      patientAge: Number(walkinAge) || 30,
      patientGender: walkinGender,
      phone: walkinPhone.trim(),
      address: walkinAddress.trim() || 'চেম্বার ওয়াক-ইন রোগী',
      date: today,
      timeSlot: 'তাৎক্ষণিক চেম্বার স্লট',
      doctorId: doc.id,
      doctorName: doc.name,
      symptoms: walkinSymptoms.trim() || 'সাধারণ স্বাস্থ্য পরীক্ষা',
      priority: 'normal',
      consultationType: 'chamber'
    });

    setShowAddModal(false);
    setWalkinName('');
    setWalkinPhone('');
    setWalkinSymptoms('');
    setWalkinAddress('');
    showToast(`নতুন সিরিয়াল #${newApt.tokenNumber} সফলভাবে বুক হয়েছে!`);
  };

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#135e96] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center space-x-2 border border-blue-400/30 animate-fade-in no-print">
          <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Datalists for medicines */}
      <datalist id="apt-remedies-datalist">
        {COMMON_REMEDIES.map((rem) => (
          <option key={rem} value={rem} />
        ))}
      </datalist>

      {/* Title & Action Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-[#2271b1]" />
            <span>অ্যাপয়েন্টমেন্ট ও সিরিয়াল ব্যবস্থাপনা</span>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 rounded-full">
              এডিট • ওষুধ এডিট • প্রিন্ট • ডিলেট
            </span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            চেম্বারের সকল অনলাইন এবং সরাসরি রোগীর সিরিয়াল নিয়ন্ত্রণ, প্রেসক্রাইব ও প্রিন্ট করুন।
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs rounded-lg shadow-xs transition flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন ওয়াক-ইন রোগী যোগ করুন</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white dark:bg-[#1a2024] p-4 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-wrap gap-3 items-center justify-between no-print">
        <div className="flex flex-wrap gap-3 items-center flex-1 min-w-[280px]">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[180px]">
            <input
              type="text"
              placeholder="রোগীর নাম, ঠিকানা, মোবাইল নম্বর বা টোকেন দিয়ে খুঁজুন..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
            />
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2" />
          </div>

          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none"
          >
            <option value="all">সকল স্ট্যাটাস</option>
            <option value="pending">পেন্ডিং (Pending)</option>
            <option value="confirmed">নিশ্চিত (Confirmed)</option>
            <option value="in-consultation">পরামর্শ চলছে (In Consultation)</option>
            <option value="completed">সম্পন্ন (Completed)</option>
            <option value="cancelled">বাতিল (Cancelled)</option>
          </select>

          {/* Doctor Dropdown */}
          <select
            value={doctorFilter}
            onChange={(e) => setDoctorFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none"
          >
            <option value="all">সকল চিকিৎসক</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>

        <div className="text-xs text-gray-500 font-mono">
          মোট: {filteredAppointments.length} টি
        </div>
      </div>

      {/* Appointments Data Table */}
      <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs overflow-hidden no-print">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#151a1e] text-gray-600 dark:text-gray-400 font-bold border-b border-gray-300 dark:border-gray-800">
                <th className="p-3">টোকেন</th>
                <th className="p-3">রোগীর নাম ও পরিচয়</th>
                <th className="p-3">মোবাইল নম্বর</th>
                <th className="p-3">তারিখ ও সময়</th>
                <th className="p-3">চিকিৎসক</th>
                <th className="p-3">উপসর্গ (লক্ষণ)</th>
                <th className="p-3">বর্তমান অবস্থা</th>
                <th className="p-3 text-right">পদক্ষেপ (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-gray-500">
                    কোনো অ্যাপয়েন্টমেন্ট পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((apt) => (
                  <tr key={apt.id} className="hover:bg-blue-50/40 dark:hover:bg-gray-800/50 transition">
                    <td className="p-3 font-mono font-bold text-emerald-600 text-sm">
                      #TK-{apt.tokenNumber}
                    </td>

                    <td className="p-3">
                      <div className="font-bold text-gray-900 dark:text-white">
                        {apt.patientName}
                      </div>
                      <div className="text-[11px] text-gray-500">
                        {apt.patientAge} বছর, {apt.patientGender}
                        {apt.address && ` • ${apt.address}`}
                      </div>
                    </td>

                    <td className="p-3 font-mono text-gray-600 dark:text-gray-400">
                      {apt.phone}
                    </td>

                    <td className="p-3">
                      <div className="font-semibold text-gray-900 dark:text-white font-mono">
                        {apt.date}
                      </div>
                      <div className="text-[11px] text-emerald-700 dark:text-emerald-400">
                        {apt.timeSlot}
                      </div>
                    </td>

                    <td className="p-3 text-gray-700 dark:text-gray-300">
                      {apt.doctorName}
                    </td>

                    <td className="p-3 max-w-xs truncate text-gray-600 dark:text-gray-400">
                      {apt.symptoms}
                    </td>

                    <td className="p-3">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          apt.status === 'in-consultation'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : apt.status === 'completed'
                            ? 'bg-gray-200 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
                            : apt.status === 'confirmed'
                            ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {apt.status === 'in-consultation'
                          ? 'পরামর্শ চলছে'
                          : apt.status === 'completed'
                          ? 'সম্পন্ন'
                          : apt.status === 'confirmed'
                          ? 'নিশ্চিত'
                          : apt.status === 'cancelled'
                          ? 'বাতিল'
                          : 'পেন্ডিং'}
                      </span>
                    </td>

                    <td className="p-3 text-right space-x-1 whitespace-nowrap">
                      {/* ১. এডিট বাটন (Edit Appointment) */}
                      <button
                        onClick={() => handleStartEdit(apt)}
                        className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="অ্যাপয়েন্টমেন্ট তথ্য এডিট করুন"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>এডিট</span>
                      </button>

                      {/* ২. ওষুধ এডিট বাটন (Medicine Edit for Appointment) */}
                      <button
                        onClick={() => handleStartMedicineEdit(apt)}
                        className="px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="এই রোগীর ওষুধ ও প্রেসক্রিপশন এডিট বা নতুন ওষুধ নির্ধারণ করুন"
                      >
                        <Pill className="w-3 h-3" />
                        <span>ওষুধ এডিট</span>
                      </button>

                      {/* ৩. প্রিন্ট বাটন (Print Appointment Slip / Token) */}
                      <button
                        onClick={() => handlePrintAppointment(apt)}
                        className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="টোকেন ও অ্যাপয়েন্টমেন্ট স্লিপ প্রিন্ট করুন"
                      >
                        <Printer className="w-3 h-3" />
                        <span>প্রিন্ট</span>
                      </button>

                      {/* ৪. ডিলেট বাটন (Delete Appointment) */}
                      <button
                        onClick={() => setDeletingAppointment(apt)}
                        className="px-1.5 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-800 rounded font-bold text-[11px] inline-flex items-center space-x-0.5 transition"
                        title="অ্যাপয়েন্টমেন্ট মুছে ফেলুন"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>ডিলেট</span>
                      </button>

                      {/* Call or Complete Quick Status buttons */}
                      {apt.status !== 'in-consultation' && apt.status !== 'completed' && (
                        <button
                          onClick={() => updateAppointmentStatus(apt.id, 'in-consultation')}
                          className="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-bold"
                          title="রুমে ডাকুন"
                        >
                          কল
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. EDIT APPOINTMENT MODAL (অ্যাপয়েন্টমেন্ট এডিট মোডাল)                     */}
      {/* ========================================================================= */}
      {editingAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto no-print">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700 my-8 animate-scale-up">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-gray-900 dark:text-white">
                    অ্যাপয়েন্টমেন্ট তথ্য সম্পাদনা (Edit Appointment)
                  </h3>
                  <p className="text-[11px] text-gray-500">
                    টোকেন: <span className="font-mono font-bold text-emerald-600">#TK-{editingAppointment.tokenNumber}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingAppointment(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1">রোগীর পূর্ণ নাম *</label>
                <input
                  type="text"
                  required
                  value={editForm.patientName}
                  onChange={(e) => setEditForm({ ...editForm, patientName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold mb-1">বয়স (বছর)</label>
                  <input
                    type="number"
                    value={editForm.patientAge}
                    onChange={(e) => setEditForm({ ...editForm, patientAge: e.target.value ? Number(e.target.value) : '' })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">লিঙ্গ</label>
                  <select
                    value={editForm.patientGender}
                    onChange={(e) => setEditForm({ ...editForm, patientGender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="শিশু">শিশু</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">ঠিকানা</label>
                  <input
                    type="text"
                    value={editForm.address}
                    onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">চিকিৎসক নির্বাচন</label>
                  <select
                    value={editForm.doctorId}
                    onChange={(e) => {
                      const doc = doctors.find((d) => d.id === e.target.value);
                      setEditForm({ ...editForm, doctorId: e.target.value, doctorName: doc ? doc.name : '' });
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.specialties?.[0] || 'হোমিও বিশেষজ্ঞ'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">সাক্ষাতের তারিখ</label>
                  <input
                    type="date"
                    value={editForm.date}
                    onChange={(e) => setEditForm({ ...editForm, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">সময় স্লট (Time Slot)</label>
                  <input
                    type="text"
                    value={editForm.timeSlot}
                    onChange={(e) => setEditForm({ ...editForm, timeSlot: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">বর্তমান অবস্থা (Status)</label>
                  <select
                    value={editForm.status}
                    onChange={(e) => setEditForm({ ...editForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="pending">পেন্ডিং (Pending)</option>
                    <option value="confirmed">নিশ্চিত (Confirmed)</option>
                    <option value="in-consultation">পরামর্শ চলছে (In Consultation)</option>
                    <option value="completed">সম্পন্ন (Completed)</option>
                    <option value="cancelled">বাতিল (Cancelled)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">পরামর্শের ধরন</label>
                  <select
                    value={editForm.consultationType}
                    onChange={(e) => setEditForm({ ...editForm, consultationType: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="chamber">চেম্বার সাক্ষাৎ (Chamber)</option>
                    <option value="online">অনলাইন টেলিমেডিসিন (Online)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">রোগের লক্ষণ / উপসর্গ</label>
                <textarea
                  rows={2}
                  value={editForm.symptoms}
                  onChange={(e) => setEditForm({ ...editForm, symptoms: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setEditingAppointment(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-lg font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg shadow-xs transition flex items-center space-x-1"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>তথ্য আপডেট করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. MEDICINE EDIT MODAL (অ্যাপয়েন্টমেন্টের ওষুধ এডিট মোডাল)                  */}
      {/* ========================================================================= */}
      {medicineEditAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto no-print">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700 my-8 animate-scale-up">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold">
                  <Pill className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-gray-900 dark:text-white">
                    রোগীর ওষুধ ও পোটেন্সি নির্ধারণ / এডিট (Prescribe Medicines)
                  </h3>
                  <p className="text-[11px] text-gray-500">
                    টোকেন: <span className="font-mono font-bold text-emerald-600">#TK-{medicineEditAppointment.tokenNumber}</span> • রোগী: <span className="font-bold">{medicineEditAppointment.patientName}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setMedicineEditAppointment(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAppointmentMedicines} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-purple-50/40 dark:bg-purple-950/20 p-3 rounded-xl border border-purple-200 dark:border-purple-900/60">
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    রোগ নির্ণয় (Diagnosis) *
                  </label>
                  <input
                    type="text"
                    required
                    value={diagnosisInput}
                    onChange={(e) => setDiagnosisInput(e.target.value)}
                    placeholder="যেমন: Chronic Gastritis / Allergic Rhinitis"
                    className="w-full px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] font-medium"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-emerald-800 dark:text-emerald-300">
                      খাতার পেজ নম্বর
                    </label>
                    <span className="text-[10px] text-gray-400 font-medium">রেজিস্টার খাতা</span>
                  </div>
                  <input
                    type="text"
                    value={registerPageNoInput}
                    onChange={(e) => setRegisterPageNoInput(e.target.value)}
                    placeholder="যেমন: খাতা-১, পৃষ্ঠা ১২"
                    className="w-full px-3 py-1.5 rounded-lg border border-purple-300 dark:border-purple-700 bg-white dark:bg-[#1a2024] font-bold text-purple-950 dark:text-purple-200"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-gray-700 dark:text-gray-300">
                    বিশেষ পথ্য ও সেবন নির্দেশিকা
                  </label>
                  <input
                    type="text"
                    value={dietGuidelineInput}
                    onChange={(e) => setDietGuidelineInput(e.target.value)}
                    placeholder="কাঁচা পিঁয়াজ, রসুন পরিহার্য..."
                    className="w-full px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024]"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="font-bold text-gray-800 dark:text-gray-200">
                  নির্ধারিত ওষুধের তালিকা ({appointmentMedicines.length} টি)
                </span>
                <button
                  type="button"
                  onClick={handleAddMedicineRow}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg text-xs flex items-center space-x-1 shadow-xs transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন ওষুধ যোগ করুন</span>
                </button>
              </div>

              {/* Medicines List */}
              <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                {appointmentMedicines.map((med, index) => (
                  <div
                    key={med.id}
                    className="p-3.5 rounded-xl border border-purple-200 dark:border-purple-900/60 bg-purple-50/20 dark:bg-purple-950/10 space-y-2 shadow-2xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-start">
                      <div className="sm:col-span-4">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          ওষুধের নাম #{index + 1} *
                        </label>
                        <input
                          type="text"
                          required
                          list="apt-remedies-datalist"
                          value={med.name}
                          onChange={(e) => handleMedicineChange(med.id, 'name', e.target.value)}
                          placeholder="যেমন: Arnica / Nux Vomica"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs font-medium"
                        />
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          পোটেন্সি *
                        </label>
                        <input
                          type="text"
                          required
                          value={med.potency}
                          onChange={(e) => handleMedicineChange(med.id, 'potency', e.target.value)}
                          placeholder="30C, 200, 1M, Q"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-purple-300 dark:border-purple-800 bg-white dark:bg-[#1a2024] font-mono font-bold text-purple-900 dark:text-purple-200 text-xs"
                        />
                        <div className="flex flex-wrap items-center gap-1 mt-1">
                          {QUICK_POTENCY_PILLS.slice(0, 6).map((pill) => (
                            <button
                              key={pill}
                              type="button"
                              onClick={() => handleMedicineChange(med.id, 'potency', pill)}
                              className={`px-1 py-0.2 text-[9px] font-mono rounded border ${
                                med.potency === pill
                                  ? 'bg-purple-600 text-white border-purple-600 font-bold'
                                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                              }`}
                            >
                              {pill}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          মাত্রা
                        </label>
                        <input
                          type="text"
                          value={med.dosage}
                          onChange={(e) => handleMedicineChange(med.id, 'dosage', e.target.value)}
                          placeholder="২ ফোঁটা / ৪টি বড়ি"
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          সময় ও নিয়ম
                        </label>
                        <input
                          type="text"
                          value={med.timing}
                          onChange={(e) => handleMedicineChange(med.id, 'timing', e.target.value)}
                          placeholder="খাবারের ৩০ মিনিট পূর্বে"
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs"
                        />
                      </div>

                      <div className="sm:col-span-1 text-right pt-5">
                        <button
                          type="button"
                          onClick={() => handleRemoveMedicineRow(med.id)}
                          disabled={appointmentMedicines.length <= 1}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg disabled:opacity-30 transition"
                          title="এই ওষুধটি মুছুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setMedicineEditAppointment(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs transition flex items-center space-x-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>ওষুধ সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. DELETE APPOINTMENT CONFIRMATION MODAL                                  */}
      {/* ========================================================================= */}
      {deletingAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs no-print">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-300 dark:border-gray-700 text-center animate-scale-up">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-base text-gray-900 dark:text-white">
              অ্যাপয়েন্টমেন্টটি মুছে ফেলতে চান?
            </h4>
            <div className="text-xs text-gray-500 mt-2 bg-gray-50 dark:bg-gray-800 p-2.5 rounded-xl border border-gray-200 dark:border-gray-700">
              <div>টোকেন নম্বর: <span className="font-mono font-bold text-emerald-600">#TK-{deletingAppointment.tokenNumber}</span></div>
              <div>রোগীর নাম: <span className="font-bold text-gray-800 dark:text-gray-200">{deletingAppointment.patientName}</span></div>
              <div>তারিখ: <span className="font-mono">{deletingAppointment.date}</span></div>
            </div>
            <p className="text-[11px] text-rose-500 mt-2 font-medium">
              সতর্কতা: সিরিয়াল মুছে ফেললে ডাটাবেজ থেকে স্থায়ীভাবে অপসারিত হবে।
            </p>
            <div className="mt-4 flex justify-center space-x-2">
              <button
                onClick={() => setDeletingAppointment(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold"
              >
                বাতিল
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হ্যাঁ, মুছে ফেলুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. PRINT APPOINTMENT TOKEN SLIP MODAL & PRINT CONTAINER                   */}
      {/* ========================================================================= */}
      {printingAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto no-print">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-300 text-gray-900 animate-scale-up">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 mb-4">
              <h3 className="font-bold text-base flex items-center space-x-2">
                <Printer className="w-4 h-4 text-blue-600" />
                <span>অ্যাপয়েন্টমেন্ট সিরিয়াল ও টোকেন স্লিপ প্রিভিউ</span>
              </h3>
              <button
                onClick={() => setPrintingAppointment(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Token Card */}
            <div className="p-6 bg-gray-50 rounded-2xl border-2 border-dashed border-emerald-600 text-center space-y-4">
              <div className="border-b border-gray-200 pb-3">
                <h4 className="font-extrabold text-xl text-emerald-900">{settings.chamberName}</h4>
                <p className="text-xs text-gray-600">{settings.tagline}</p>
                <p className="text-[11px] text-gray-500">{settings.address} | হটলাইন: {settings.phone}</p>
              </div>

              <div>
                <span className="text-xs uppercase tracking-widest text-gray-500 font-bold block mb-1">
                  রোগীর ক্রমিক সিরিয়াল টোকেন
                </span>
                <div className="text-4xl font-black font-mono text-emerald-700 bg-emerald-100/70 inline-block px-6 py-2 rounded-2xl border border-emerald-300 shadow-inner">
                  #TK-{printingAppointment.tokenNumber}
                </div>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-gray-200 text-xs space-y-1.5 text-left">
                <div className="flex justify-between">
                  <span className="text-gray-500">রোগীর নাম:</span>
                  <span className="font-bold">{printingAppointment.patientName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">বয়স ও লিঙ্গ:</span>
                  <span>{printingAppointment.patientAge} বছর, {printingAppointment.patientGender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">মোবাইল নম্বর:</span>
                  <span className="font-mono font-bold">{printingAppointment.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">তারিখ ও সময়:</span>
                  <span className="font-bold text-emerald-800">{printingAppointment.date} ({printingAppointment.timeSlot})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">নির্ধারিত চিকিৎসক:</span>
                  <span className="font-bold">{printingAppointment.doctorName}</span>
                </div>
              </div>

              <p className="text-[10px] text-gray-500 italic">
                * অনুগ্রহ করে নির্ধারিত সময়ের ১০ মিনিট পূর্বে চেম্বারে উপস্থিত থাকুন।
              </p>
            </div>

            <div className="mt-5 flex justify-end space-x-2">
              <button
                onClick={() => setPrintingAppointment(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-xs font-bold"
              >
                বন্ধ করুন
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md"
              >
                <Printer className="w-4 h-4" />
                <span>স্লিপ প্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden Print Container for Clean Paper Printout */}
      {printingAppointment && (
        <div id="printable-prescription" className="p-8 font-sans max-w-xl mx-auto bg-white text-black">
          <div className="text-center border-b-2 border-emerald-800 pb-4 mb-4">
            <h2 className="text-2xl font-black text-emerald-900">{settings.chamberName}</h2>
            <p className="text-xs text-gray-600">{settings.tagline}</p>
            <p className="text-xs text-gray-500">{settings.address} | হটলাইন: {settings.phone}</p>
          </div>

          <div className="text-center my-6">
            <div className="text-xs uppercase tracking-widest text-gray-600 font-bold mb-1">
              রোগীর অ্যাপয়েন্টমেন্ট সিরিয়াল স্লিপ
            </div>
            <div className="text-5xl font-black font-mono text-emerald-800 border-2 border-emerald-800 inline-block px-8 py-3 rounded-2xl">
              #TK-{printingAppointment.tokenNumber}
            </div>
          </div>

          <div className="border border-gray-300 rounded-xl p-4 text-sm space-y-2 mb-6">
            <div className="flex justify-between border-b pb-1">
              <span className="text-gray-600">রোগীর নাম:</span>
              <span className="font-bold text-base">{printingAppointment.patientName}</span>
            </div>
            <div className="flex justify-between border-b pb-1">
              <span className="text-gray-600">বয়স ও লিঙ্গ:</span>
              <span>{printingAppointment.patientAge} বছর, {printingAppointment.patientGender}</span>
            </div>
            <div className="flex justify-between border-b pb-1">
              <span className="text-gray-600">মোবাইল নম্বর:</span>
              <span className="font-mono font-bold">{printingAppointment.phone}</span>
            </div>
            <div className="flex justify-between border-b pb-1">
              <span className="text-gray-600">তারিখ ও সময়:</span>
              <span className="font-bold text-emerald-900">{printingAppointment.date} ({printingAppointment.timeSlot})</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">চিকিৎসক:</span>
              <span className="font-bold">{printingAppointment.doctorName}</span>
            </div>
          </div>

          <div className="border-t border-gray-300 pt-3 text-xs text-gray-500 text-center">
            সাক্ষাতের পূর্বে অনুগ্রহ করে অপেক্ষা করুন। আপনার সিরিয়াল আহ্বান করা হবে।
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. ADD WALKIN MODAL                                                       */}
      {/* ========================================================================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs no-print">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-300 dark:border-gray-700">
            <h3 className="font-bold text-base text-gray-900 dark:text-white mb-4">
              নতুন ওয়াক-ইন রোগী সিরিয়াল যোগ করুন
            </h3>
            <form onSubmit={handleAddWalkin} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1">রোগীর নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: কামরুল হাসান"
                  value={walkinName}
                  onChange={(e) => setWalkinName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">বয়স</label>
                  <input
                    type="number"
                    placeholder="যেমন: 35"
                    value={walkinAge}
                    onChange={(e) => setWalkinAge(e.target.value ? Number(e.target.value) : '')}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">লিঙ্গ</label>
                  <select
                    value={walkinGender}
                    onChange={(e) => setWalkinGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="শিশু">শিশু</option>
                    <option value="অন্যান্য">অন্যান্য</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">মোবাইল নম্বর *</label>
                <input
                  type="tel"
                  required
                  placeholder="০১৭১১-XXXXXX"
                  value={walkinPhone}
                  onChange={(e) => setWalkinPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] font-mono"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">ঠিকানা</label>
                <input
                  type="text"
                  placeholder="উত্তরা, ঢাকা"
                  value={walkinAddress}
                  onChange={(e) => setWalkinAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">চিকিৎসক</label>
                <select
                  value={walkinDoctor}
                  onChange={(e) => setWalkinDoctor(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.specialties?.[0] || 'হোমিও বিশেষজ্ঞ'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1">সমস্যা / লক্ষণ</label>
                <textarea
                  rows={2}
                  placeholder="রোগীর প্রধান সমস্যা বা উপসর্গ লিখুন..."
                  value={walkinSymptoms}
                  onChange={(e) => setWalkinSymptoms(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 rounded-lg"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs transition"
                >
                  সিরিয়াল যুক্ত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
