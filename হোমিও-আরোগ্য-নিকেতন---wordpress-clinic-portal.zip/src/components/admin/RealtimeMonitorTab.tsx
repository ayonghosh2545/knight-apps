import React, { useState, useEffect } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  Activity,
  Users,
  Clock,
  CheckCircle,
  Volume2,
  RefreshCw,
  Wifi,
  Radio,
  Bell
} from 'lucide-react';

export const RealtimeMonitorTab: React.FC = () => {
  const { appointments, auditLogs, isOnline, updateAppointmentStatus, logAction } = useClinic();

  const [lastHeartbeat, setLastHeartbeat] = useState(new Date().toLocaleTimeString('bn-BD'));
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      setLastHeartbeat(new Date().toLocaleTimeString('bn-BD'));
    }, 4000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const activeInConsult = appointments.find((a) => a.status === 'in-consultation');
  const waitingPatients = appointments.filter((a) => a.status === 'confirmed' || a.status === 'pending');
  const completedToday = appointments.filter((a) => a.status === 'completed');

  const playChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.45);
    } catch {}
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <Activity className="w-5 h-5 text-emerald-600 animate-pulse" />
            <span>লাইভ চেম্বার ট্র্যাকিং ও রিয়েল-টাইম মনিটর</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            চেম্বারের ওয়েটিং রুম, ডাক্তারের কেবিন এবং রোগীর উপস্থিতির লাইভ পর্যবেক্ষণ।
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <button
            onClick={playChime}
            className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold rounded-lg flex items-center space-x-1"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>সাউন্ড চাইম পরীক্ষা</span>
          </button>

          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-mono">
            <Radio className="w-3.5 h-3.5 text-emerald-600 animate-ping" />
            <span>লাইভ সিগন্যাল: {lastHeartbeat}</span>
          </div>
        </div>
      </div>

      {/* Real-time Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* In Consultation Card */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border-2 border-emerald-500 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
              বর্তমান রোগী (Consulting Room)
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 animate-pulse">
              লাইভ
            </span>
          </div>
          {activeInConsult ? (
            <div className="space-y-2">
              <div className="text-3xl font-black text-emerald-700 dark:text-emerald-300 font-mono">
                #TK-{activeInConsult.tokenNumber}
              </div>
              <div className="font-bold text-base text-gray-900 dark:text-white">
                {activeInConsult.patientName}
              </div>
              <div className="text-xs text-gray-500">
                বয়স: {activeInConsult.patientAge} বছর | মোবাইল: {activeInConsult.phone}
              </div>
              <div className="text-xs text-emerald-800 dark:text-emerald-400 font-medium pt-1">
                চিকিৎসক: {activeInConsult.doctorName}
              </div>
            </div>
          ) : (
            <div className="text-xs text-gray-400 py-6 text-center">
              ডাক্তারের কেবিন এই মুহূর্তে খালি রয়েছে।
            </div>
          )}
        </div>

        {/* Waiting Room Queue */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              অপেক্ষমাণ সিরিয়াল তালিকা (Waiting Room)
            </span>
            <span className="text-xs font-bold font-mono text-amber-600">
              {waitingPatients.length} জন
            </span>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {waitingPatients.length > 0 ? (
              waitingPatients.map((apt) => (
                <div
                  key={apt.id}
                  className="p-2 rounded-lg bg-gray-50 dark:bg-[#151a1e] border border-gray-200 dark:border-gray-800 text-xs flex justify-between items-center"
                >
                  <div>
                    <span className="font-mono font-bold text-amber-600 mr-2">
                      #TK-{apt.tokenNumber}
                    </span>
                    <span className="font-bold text-gray-800 dark:text-gray-200">
                      {apt.patientName}
                    </span>
                  </div>
                  <span className="text-[10px] text-gray-500">{apt.timeSlot}</span>
                </div>
              ))
            ) : (
              <div className="text-xs text-gray-400 py-6 text-center">
                কোনো রোগী অপেক্ষমাণ নেই।
              </div>
            )}
          </div>
        </div>

        {/* Completed Today */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
              আজকের সম্পন্ন পরামর্শ
            </span>
            <span className="text-xs font-bold font-mono text-emerald-600">
              {completedToday.length} জন
            </span>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto text-xs">
            {completedToday.length > 0 ? (
              completedToday.map((apt) => (
                <div
                  key={apt.id}
                  className="p-2 rounded-lg bg-gray-50 dark:bg-[#151a1e] border border-gray-200 dark:border-gray-800 flex justify-between items-center"
                >
                  <span className="font-semibold text-gray-700 dark:text-gray-300">
                    {apt.patientName} (#TK-{apt.tokenNumber})
                  </span>
                  <span className="text-[10px] text-emerald-600 font-bold">সম্পন্ন ✓</span>
                </div>
              ))
            ) : (
              <div className="text-xs text-gray-400 py-6 text-center">
                এখনো সম্পন্ন হয়নি।
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Live Stream Logs */}
      <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
        <h3 className="font-bold text-sm text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
          <Activity className="w-4 h-4 text-emerald-600" />
          <span>রিয়েল-টাইম কার্যক্রম মনিটরিং স্ট্রীম</span>
        </h3>

        <div className="space-y-2 text-xs">
          {auditLogs.slice(0, 10).map((log) => (
            <div
              key={log.id}
              className="p-2.5 rounded-lg bg-gray-50 dark:bg-[#131b1e] border border-gray-200 dark:border-gray-800 flex justify-between items-center"
            >
              <div className="flex items-center space-x-2">
                <span className={`w-2 h-2 rounded-full ${
                  log.severity === 'success' ? 'bg-emerald-500' :
                  log.severity === 'warning' ? 'bg-amber-500' :
                  log.severity === 'security' ? 'bg-purple-500' : 'bg-sky-500'
                }`} />
                <span className="font-bold text-gray-800 dark:text-gray-200">{log.action}:</span>
                <span className="text-gray-600 dark:text-gray-400">{log.details}</span>
              </div>
              <span className="text-[10px] font-mono text-gray-400 shrink-0">{log.timestamp}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
