import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  Users,
  Settings,
  Activity,
  Database,
  Shield,
  History,
  Zap,
  Smartphone,
  ChevronRight,
  LogOut,
  Globe,
  Menu,
  X,
  UserCog,
  Stethoscope,
  Star,
  Bot
} from 'lucide-react';
import { DashboardTab } from './DashboardTab.tsx';
import { AppointmentsTab } from './AppointmentsTab.tsx';
import { PrescriptionsTab } from './PrescriptionsTab.tsx';
import { PatientsTab } from './PatientsTab.tsx';
import { DoctorsTab } from './DoctorsTab.tsx';
import { ReviewsTab } from './ReviewsTab.tsx';
import { ChatbotSettingsTab } from './ChatbotSettingsTab.tsx';
import { ChamberSettingsTab } from './ChamberSettingsTab.tsx';
import { AdminSettingsTab } from './AdminSettingsTab.tsx';
import { RealtimeMonitorTab } from './RealtimeMonitorTab.tsx';
import { BackupSyncTab } from './BackupSyncTab.tsx';
import { SecurityTab } from './SecurityTab.tsx';
import { AuditLogsTab } from './AuditLogsTab.tsx';
import { DatabaseOptimizeTab } from './DatabaseOptimizeTab.tsx';
import { MobileApkTab } from './MobileApkTab.tsx';

export const WpAdminLayout: React.FC = () => {
  const {
    adminSubTab,
    setAdminSubTab,
    setCurrentView,
    logoutMaster,
    settings,
    appointments,
    syncQueue,
    doctors,
    reviews
  } = useClinic();

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard, badge: null },
    {
      id: 'appointments',
      label: 'অ্যাপয়েন্টমেন্ট',
      icon: Calendar,
      badge: appointments.filter((a) => a.status === 'pending').length || null
    },
    { id: 'prescriptions', label: 'প্রেসক্রিপশন ও ওষুধ', icon: FileText, badge: null },
    { id: 'patients', label: 'রোগী ডাটাবেস', icon: Users, badge: null },
    { id: 'doctors', label: 'ডাক্তার প্রোফাইল', icon: Stethoscope, badge: `${doctors.length}` },
    { id: 'reviews', label: 'রিভিউ ও রেটিং', icon: Star, badge: `${reviews.length}` },
    { id: 'chatbot', label: 'চ্যাটবট কনফিগারেশন', icon: Bot, badge: 'AI' },
    { id: 'settings', label: 'চেম্বার সেটিংস', icon: Settings, badge: null },
    { id: 'admin-settings', label: 'অ্যাডমিন অ্যাকাউন্ট', icon: UserCog, badge: 'Edit' },
    { id: 'monitor', label: 'রিয়েল-টাইম মনিটর', icon: Activity, badge: 'Live' },
    {
      id: 'backup',
      label: 'ব্যাকআপ ও সিঙ্ক',
      icon: Database,
      badge: syncQueue.length ? `${syncQueue.length}` : null
    },
    { id: 'security', label: 'সিকিউরিটি ও 2FA', icon: Shield, badge: null },
    { id: 'audit', label: 'অডিট লগ রিপোর্ট', icon: History, badge: null },
    { id: 'database', label: 'ডাটাবেজ ও ক্যাশিং', icon: Zap, badge: null },
    { id: 'mobile-apk', label: 'মোবাইল অ্যাপ ও APK', icon: Smartphone, badge: 'APK' }
  ];

  const renderActiveTab = () => {
    switch (adminSubTab) {
      case 'dashboard':
        return <DashboardTab />;
      case 'appointments':
        return <AppointmentsTab />;
      case 'prescriptions':
        return <PrescriptionsTab />;
      case 'patients':
        return <PatientsTab />;
      case 'doctors':
        return <DoctorsTab />;
      case 'reviews':
        return <ReviewsTab />;
      case 'chatbot':
        return <ChatbotSettingsTab />;
      case 'settings':
        return <ChamberSettingsTab />;
      case 'admin-settings':
        return <AdminSettingsTab />;
      case 'monitor':
        return <RealtimeMonitorTab />;
      case 'backup':
        return <BackupSyncTab />;
      case 'security':
        return <SecurityTab />;
      case 'audit':
        return <AuditLogsTab />;
      case 'database':
        return <DatabaseOptimizeTab />;
      case 'mobile-apk':
        return <MobileApkTab />;
      default:
        return <DashboardTab />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f0f0f1] dark:bg-[#12171a] flex flex-col transition-colors">
      
      {/* Admin Sub-header for Mobile Navigation */}
      <div className="md:hidden bg-[#1d2327] text-white px-4 py-2.5 flex items-center justify-between border-b border-gray-800">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="flex items-center space-x-2 text-xs font-bold"
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5 text-gray-300" />}
          <span>ওয়ার্ডপ্রেস এডমিন মেনু</span>
        </button>

        <button
          onClick={() => setCurrentView('frontend')}
          className="px-2.5 py-1 bg-[#2271b1] text-white text-[11px] rounded font-bold"
        >
          ওয়েবসাইট দেখুন
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Sidebar (Iconic WordPress Admin Sidebar #1d2327) */}
        <aside
          className={`${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
          } fixed md:static inset-y-9 left-0 z-40 w-56 sm:w-60 bg-[#1d2327] text-[#c3c4c7] flex flex-col justify-between transition-transform duration-200 select-none shadow-lg border-r border-[#2c3338]`}
        >
          {/* Menu Items */}
          <div className="py-2 overflow-y-auto">
            
            {/* Chamber Profile in Sidebar */}
            <div className="px-4 py-3 border-b border-[#2c3338] mb-1">
              <div className="text-white font-bold text-xs truncate">
                {settings.chamberName}
              </div>
              <div className="text-[10px] text-emerald-400 mt-0.5">
                HomeoPress WP Admin
              </div>
            </div>

            <nav className="space-y-0.5">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = adminSubTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setAdminSubTab(item.id);
                      setIsSidebarOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs transition font-medium ${
                      isActive
                        ? 'bg-[#2271b1] text-white font-bold'
                        : 'hover:bg-[#2c3338] hover:text-[#72aee6] text-[#c3c4c7]'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#72aee6]'}`} />
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                          item.badge === 'Live'
                            ? 'bg-emerald-500 text-black animate-pulse'
                            : 'bg-[#d63638] text-white'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar Bottom: View Site & Logout */}
          <div className="p-3 border-t border-[#2c3338] bg-[#171c1f] space-y-1">
            <button
              onClick={() => setCurrentView('frontend')}
              className="w-full px-3 py-2 text-left text-xs text-[#72aee6] hover:bg-[#2c3338] hover:text-white rounded flex items-center space-x-2 transition"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>ওয়েবসাইট ভিজিট করুন</span>
            </button>

            <button
              onClick={logoutMaster}
              className="w-full px-3 py-2 text-left text-xs text-rose-400 hover:bg-rose-950/60 rounded flex items-center space-x-2 transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>লগআউট (মাস্টার সেশন)</span>
            </button>
          </div>
        </aside>

        {/* Main Content Area in WordPress light gray `#f0f0f1` */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl">
          {renderActiveTab()}
        </main>

      </div>

    </div>
  );
};
