import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import { Prescription, MedicineItem } from '../../types.ts';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Pill,
  Calendar,
  Eye,
  X,
  Edit2,
  Check,
  Save,
  UtensilsCrossed,
  Sparkles,
  Zap,
  Camera,
  Image,
  UploadCloud,
  Maximize2,
  Download
} from 'lucide-react';

// Typical Homeopathic Potencies for fast selection & datalist
const TYPICAL_POTENCIES = [
  'Q (Mother Tincture)',
  'Mother Tincture',
  '3X',
  '6X',
  '12X',
  '30X',
  '200X',
  '30C',
  '30CH',
  '200C',
  '200CH',
  '1M',
  '10M',
  '50M',
  'CM',
  '0/1',
  '0/2',
  '0/3',
  '0/4',
  '0/5',
  '0/6',
  'LM 0/1',
  'LM 0/2',
  'LM 0/3',
  'LM 0/6'
];

const QUICK_POTENCY_PILLS = ['Q', '6X', '12X', '30C', '200C', '1M', '10M', '0/1', '0/2', '0/3', 'CM'];

const COMMON_HOMEOPATHIC_REMEDIES = [
  'Arnica Montana',
  'Nux Vomica',
  'Bryonia Alba',
  'Belladonna',
  'Rhus Toxicodendron',
  'Arsenicum Album',
  'Lycopodium Clavatum',
  'Pulsatilla Nigricans',
  'Sulphur',
  'Calcarea Carbonica',
  'Thuja Occidentalis',
  'Silicea',
  'Hepar Sulphuris Calcareum',
  'Gelsemium Sempervirens',
  'Aconitum Napellus',
  'Causticum',
  'Natrum Muriaticum',
  'Ignatia Amara',
  'Carbo Vegetabilis',
  'Chamomilla',
  'Kali Bichromicum',
  'Sepia Officinalis',
  'Lachesis Mutus',
  'Phosphorus',
  'Colocynthis',
  'Dulcamara',
  'Mercurius Solubilis',
  'Allium Cepa',
  'Hypericum Perforatum',
  'Berberis Vulgaris',
  'Ruta Graveolens',
  'Ledum Palustre',
  'Staphysagria',
  'China Officinalis'
];

export const PrescriptionsTab: React.FC = () => {
  const {
    prescriptions,
    doctors,
    patients,
    addPrescription,
    updatePrescription,
    deletePrescription,
    setSelectedPrescriptionForView,
    setIsPrescriptionLookupOpen
  } = useClinic();

  const [activeSubView, setActiveSubView] = useState<'list' | 'create'>('list');
  const [searchFilter, setSearchFilter] = useState('');
  const [editingPrescriptionId, setEditingPrescriptionId] = useState<string | null>(null);

  // Quick Medicine Editor Modal State
  const [quickMedicineModalPrescription, setQuickMedicineModalPrescription] = useState<Prescription | null>(null);
  const [quickMedicines, setQuickMedicines] = useState<MedicineItem[]>([]);

  // Delete Confirmation Modal State
  const [deleteModalPrescription, setDeleteModalPrescription] = useState<Prescription | null>(null);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleDirectPrint = (rx: Prescription) => {
    setSelectedPrescriptionForView(rx);
    setIsPrescriptionLookupOpen(true);
    setTimeout(() => {
      window.print();
    }, 350);
  };

  const handleOpenDeleteConfirm = (rx: Prescription) => {
    setDeleteModalPrescription(rx);
  };

  const handleConfirmDelete = () => {
    if (!deleteModalPrescription) return;
    const code = deleteModalPrescription.prescriptionCode;
    deletePrescription(deleteModalPrescription.id);
    showToast(`প্রেসক্রিপশন "${code}" সফলভাবে মুছে ফেলা হয়েছে।`);
    setDeleteModalPrescription(null);
  };

  const handleOpenQuickMedicineEdit = (rx: Prescription) => {
    setQuickMedicineModalPrescription(rx);
    setQuickMedicines(
      rx.medicines && rx.medicines.length > 0
        ? JSON.parse(JSON.stringify(rx.medicines))
        : [
            {
              id: 'qm-' + Date.now(),
              name: '',
              potency: '30CH',
              dosage: '২ ফোঁটা',
              frequency: 'দিনে ৩ বার',
              duration: '১৫ দিন',
              timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে',
              instructions: ''
            }
          ]
    );
  };

  const handleQuickMedicineChange = (id: string, field: keyof MedicineItem, value: string) => {
    setQuickMedicines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  const handleAddQuickMedicineRow = () => {
    setQuickMedicines((prev) => [
      ...prev,
      {
        id: 'qm-' + Date.now(),
        name: '',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'দিনে ৩ বার',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে',
        instructions: ''
      }
    ]);
  };

  const handleRemoveQuickMedicineRow = (id: string) => {
    if (quickMedicines.length <= 1) return;
    setQuickMedicines((prev) => prev.filter((m) => m.id !== id));
  };

  const handleSaveQuickMedicines = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickMedicineModalPrescription) return;

    updatePrescription(quickMedicineModalPrescription.id, {
      medicines: quickMedicines
    });

    setSelectedPrescriptionForView({
      ...quickMedicineModalPrescription,
      medicines: quickMedicines
    });

    showToast(`প্রেসক্রিপশন "${quickMedicineModalPrescription.prescriptionCode}" এর ওষুধ সফলভাবে আপডেট করা হয়েছে!`);
    setQuickMedicineModalPrescription(null);
  };

  // Form State for Prescription
  const [patientName, setPatientName] = useState('');
  const [patientAddress, setPatientAddress] = useState('');
  const [registerPageNo, setRegisterPageNo] = useState(''); // খাতার পেজ নম্বর (Register / Ledger Book Page No.)
  const [patientAge, setPatientAge] = useState<number | ''>('');
  const [patientGender, setPatientGender] = useState<'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য'>('পুরুষ');
  const [patientPhone, setPatientPhone] = useState('');
  const [doctorId, setDoctorId] = useState(doctors[0]?.id || '');
  const [diagnosis, setDiagnosis] = useState('');
  const [symptomsText, setSymptomsText] = useState('');
  const [constitutionalState, setConstitutionalState] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  
  // Prescription Image Upload State
  const [prescriptionImage, setPrescriptionImage] = useState<string | null>(null);
  const [previewImageModalUrl, setPreviewImageModalUrl] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [showUrlInput, setShowUrlInput] = useState(false);

  // Dynamic Medicine List
  const [medicines, setMedicines] = useState<MedicineItem[]>([
    {
      id: 'm-1',
      name: 'Nux Vomica',
      potency: '200CH',
      dosage: '২ ফোঁটা',
      frequency: 'প্রতি রাতে ঘুমানোর পূর্বে',
      duration: '১৫ দিন',
      timing: 'খাবারের ৩০ মিনিট পর ১ চামচ পানিতে',
      instructions: 'অতিরিক্ত তেল-মসলা ও মানসিক উত্তেজনা পরিহার করুন'
    }
  ]);

  // Standard dietary restrictions list
  const standardRestrictions = [
    'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
    'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন',
    'ধূমপান, জর্দা ও তামাক জাতীয় দ্রব্য নিষিদ্ধ',
    'তেঁতুল, কাঁচা আম ও অতিরিক্ত টক খাবার বর্জনীয়',
    'অতিরিক্ত তেল-মসলাযুক্ত ও বাসি খাবার বর্জনীয়',
    'ফ্রিজের অতিরিক্ত ঠান্ডা পানি বা আইসক্রিম নিষিদ্ধ'
  ];

  // Active list of dietary guidelines available for selection/editing
  const [restrictionsList, setRestrictionsList] = useState<string[]>(standardRestrictions);

  // Diet Restrictions Checklist (Checked ones)
  const [selectedRestrictions, setSelectedRestrictions] = useState<string[]>([
    'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
    'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন'
  ]);

  // Custom blank input box state for adding new guideline
  const [customRestrictionInput, setCustomRestrictionInput] = useState('');

  // Inline edit state for existing guidelines
  const [editingRestrictionIndex, setEditingRestrictionIndex] = useState<number | null>(null);
  const [editingRestrictionText, setEditingRestrictionText] = useState('');

  // Dedicated blank text area box for free-form custom diet and physician advice
  const [dietNotes, setDietNotes] = useState('ওষুধ সেবনের ৩০ মিনিট পূর্বে ও পরে মুখ সম্পূর্ণ পরিষ্কার রাখবেন। কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করবেন।');

  const commonMedicinesSuggestions = [
    'Arnica Montana',
    'Nux Vomica',
    'Belladonna',
    'Aconite Napellus',
    'Bryonia Alba',
    'Thuja Occidentalis',
    'Rhus Toxicodendron',
    'Arsenicum Album',
    'Pulsatilla Nigricans',
    'Lycopodium Clavatum',
    'Carbo Vegetabilis',
    'Silicea',
    'Calcarea Carbonica',
    'Syzygium Jambolanum (Q)',
    'Crataegus Oxyacantha (Q)',
    'Justicia Adhatoda (Q)'
  ];

  const commonPresetSuggestions = [
    'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণ নিষেধ',
    'কফি ও কড়া লিকার চা পরিহার',
    'তেঁতুল, আচার ও অতি টক খাদ্য বর্জনীয়',
    'ধূমপান, জর্দা ও তামাক জাতীয় দ্রব্য নিষিদ্ধ',
    'হালকা সুপাচ্য পুষ্টিকর খাদ্য গ্রহণ',
    'কুসুম গরম পানি পর্যাপ্ত পান করুন',
    'ফ্রিজের অতিরিক্ত ঠান্ডা পানি বা আইসক্রিম নিষিদ্ধ',
    'কর্পূর, সুগন্ধি তেল ও তীব্র পারফিউম পরিহার'
  ];

  const handleAddMedicineRow = () => {
    setMedicines([
      ...medicines,
      {
        id: 'm-' + Date.now(),
        name: '',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'দিনে ৩ বার',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পূর্বে খালি পেটে',
        instructions: ''
      }
    ]);
  };

  const handleRemoveMedicineRow = (id: string) => {
    if (medicines.length <= 1) return;
    setMedicines(medicines.filter((m) => m.id !== id));
  };

  const handleMedicineChange = (id: string, field: keyof MedicineItem, value: string) => {
    setMedicines(
      medicines.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  const toggleRestriction = (item: string) => {
    if (selectedRestrictions.includes(item)) {
      setSelectedRestrictions(selectedRestrictions.filter((r) => r !== item));
    } else {
      setSelectedRestrictions([...selectedRestrictions, item]);
    }
  };

  // Add custom restriction from the blank input box
  const handleAddCustomRestriction = () => {
    const text = customRestrictionInput.trim();
    if (!text) return;
    if (!restrictionsList.includes(text)) {
      setRestrictionsList([...restrictionsList, text]);
    }
    if (!selectedRestrictions.includes(text)) {
      setSelectedRestrictions([...selectedRestrictions, text]);
    }
    setCustomRestrictionInput('');
  };

  // Add preset suggestion pill
  const handleAddPresetPill = (pill: string) => {
    if (!restrictionsList.includes(pill)) {
      setRestrictionsList([...restrictionsList, pill]);
    }
    if (!selectedRestrictions.includes(pill)) {
      setSelectedRestrictions([...selectedRestrictions, pill]);
    }
  };

  // Start inline editing of an existing restriction item
  const handleStartEditRestriction = (index: number, currentText: string) => {
    setEditingRestrictionIndex(index);
    setEditingRestrictionText(currentText);
  };

  // Save inline edit
  const handleSaveEditRestriction = (index: number) => {
    const updatedText = editingRestrictionText.trim();
    if (!updatedText) {
      setEditingRestrictionIndex(null);
      return;
    }
    const oldText = restrictionsList[index];
    const newList = [...restrictionsList];
    newList[index] = updatedText;
    setRestrictionsList(newList);

    if (selectedRestrictions.includes(oldText)) {
      setSelectedRestrictions(
        selectedRestrictions.map((item) => (item === oldText ? updatedText : item))
      );
    }
    setEditingRestrictionIndex(null);
    setEditingRestrictionText('');
  };

  // Cancel inline edit
  const handleCancelEditRestriction = () => {
    setEditingRestrictionIndex(null);
    setEditingRestrictionText('');
  };

  // Delete restriction item from list
  const handleDeleteRestriction = (itemToDelete: string) => {
    setRestrictionsList(restrictionsList.filter((item) => item !== itemToDelete));
    setSelectedRestrictions(selectedRestrictions.filter((item) => item !== itemToDelete));
  };

  // Handle image upload from computer or camera
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('অনুগ্রহ করে শুধুমাত্র ছবি ফাইল (JPG, PNG, JPEG, WebP) আপলোড করুন।');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('ছবির আকার সর্বোচ্চ ৫ মেগাবাইট (5MB) হতে পারে।');
      return;
    }

    setIsUploadingImage(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setPrescriptionImage(dataUrl);
      setIsUploadingImage(false);
      showToast('প্রেসক্রিপশনের ছবি সফলভাবে আপলোড হয়েছে!');
    };
    reader.onerror = () => {
      alert('ছবি রিড করতে ব্যর্থ হয়েছে। পুনরায় চেষ্টা করুন।');
      setIsUploadingImage(false);
    };
    reader.readAsDataURL(file);
  };

  const handleApplyImageUrl = () => {
    if (!imageUrlInput.trim()) return;
    setPrescriptionImage(imageUrlInput.trim());
    showToast('প্রেসক্রিপশন ছবির লিংক সফলভাবে সংযুক্ত হয়েছে!');
  };

  // Reset form to blank new prescription
  const handleResetForm = () => {
    setEditingPrescriptionId(null);
    setPatientName('');
    setPatientAddress('');
    setRegisterPageNo('');
    setPatientAge('');
    setPatientGender('পুরুষ');
    setPatientPhone('');
    setDoctorId(doctors[0]?.id || '');
    setDiagnosis('');
    setSymptomsText('');
    setConstitutionalState('');
    setFollowUpDate('');
    setPrescriptionImage(null);
    setImageUrlInput('');
    setShowUrlInput(false);
    setMedicines([
      {
        id: 'm-1',
        name: 'Nux Vomica',
        potency: '200CH',
        dosage: '২ ফোঁটা',
        frequency: 'প্রতি রাতে ঘুমানোর পূর্বে',
        duration: '১৫ দিন',
        timing: 'খাবারের ৩০ মিনিট পর ১ চামচ পানিতে',
        instructions: 'অতিরিক্ত তেল-মসলা ও মানসিক উত্তেজনা পরিহার করুন'
      }
    ]);
    setRestrictionsList(standardRestrictions);
    setSelectedRestrictions([
      'কাঁচা পিঁয়াজ ও কাঁচা রসুন সম্পূর্ণরূপে পরিহার্য',
      'তীব্র কফি ও অতিরিক্ত কড়া চা পান বন্ধ রাখবেন'
    ]);
    setCustomRestrictionInput('');
    setDietNotes('ওষুধ সেবনের ৩০ মিনিট পূর্বে ও পরে মুখ সম্পূর্ণ পরিষ্কার রাখবেন। কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করবেন।');
    setEditingRestrictionIndex(null);
  };

  // Edit existing prescription
  const handleEditPrescription = (rx: Prescription) => {
    setEditingPrescriptionId(rx.id);
    setPatientName(rx.patientName || '');
    setPatientAddress(rx.patientAddress || '');
    setRegisterPageNo(rx.registerPageNo || '');
    setPatientAge(rx.patientAge || '');
    setPatientGender(rx.patientGender || 'পুরুষ');
    setPatientPhone(rx.patientPhone || '');
    setDoctorId(rx.doctorId || doctors[0]?.id || '');
    setDiagnosis(rx.diagnosis || '');
    setSymptomsText((rx.symptoms || []).join(', '));
    setConstitutionalState(rx.constitutionalState || '');
    setPrescriptionImage(rx.prescriptionImage || null);
    setImageUrlInput(rx.prescriptionImage && !rx.prescriptionImage.startsWith('data:') ? rx.prescriptionImage : '');
    setMedicines(rx.medicines && rx.medicines.length > 0 ? rx.medicines : [
      {
        id: 'm-1',
        name: '',
        potency: '30CH',
        dosage: '২ ফোঁটা',
        frequency: 'দিনে ৩ বার',
        duration: '১৫ দিন',
        timing: 'খাবারের পূর্বে',
        instructions: ''
      }
    ]);
    const mergedRestrictions = Array.from(new Set([...standardRestrictions, ...(rx.dietRestrictions || [])]));
    setRestrictionsList(mergedRestrictions);
    setSelectedRestrictions(rx.dietRestrictions || []);
    setDietNotes(rx.notes || '');
    setFollowUpDate(rx.followUpDate || '');
    setActiveSubView('create');
  };

  const handleSavePrescription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !patientPhone.trim() || !diagnosis.trim()) {
      alert('রোগীর নাম, ফোন ও রোগ নির্ণয় আবশ্যক।');
      return;
    }

    const doc = doctors.find((d) => d.id === doctorId) || doctors[0];
    const today = new Date().toISOString().split('T')[0];

    if (editingPrescriptionId) {
      // Update existing prescription
      updatePrescription(editingPrescriptionId, {
        patientName: patientName.trim(),
        patientAddress: patientAddress.trim() || 'উত্তরা, ঢাকা',
        registerPageNo: registerPageNo.trim() || undefined,
        patientAge: Number(patientAge) || 30,
        patientGender,
        patientPhone: patientPhone.trim(),
        doctorId: doc.id,
        doctorName: doc.name,
        doctorQualification: doc.qualification,
        diagnosis: diagnosis.trim(),
        symptoms: symptomsText.split(',').map((s) => s.trim()).filter(Boolean),
        constitutionalState: constitutionalState.trim(),
        medicines,
        dietRestrictions: selectedRestrictions,
        lifestyleAdvice: ['পর্যাপ্ত পরিমাণে বিশুদ্ধ কুসুম গরম পানি পান করুন', 'নিয়মিত ও পর্যাপ্ত ঘুম নিশ্চিত করুন'],
        followUpDate: followUpDate || '১৫ দিন পর',
        notes: dietNotes.trim(),
        prescriptionImage: prescriptionImage || undefined
      });

      const updatedRx = prescriptions.find((r) => r.id === editingPrescriptionId);
      if (updatedRx) {
        setSelectedPrescriptionForView({
          ...updatedRx,
          patientName: patientName.trim(),
          patientAddress: patientAddress.trim() || 'উত্তরা, ঢাকা',
          registerPageNo: registerPageNo.trim() || undefined,
          diagnosis: diagnosis.trim(),
          medicines,
          dietRestrictions: selectedRestrictions,
          notes: dietNotes.trim(),
          followUpDate: followUpDate || '১৫ দিন পর',
          prescriptionImage: prescriptionImage || undefined
        });
      }

      setEditingPrescriptionId(null);
      setActiveSubView('list');
      setIsPrescriptionLookupOpen(true);
      return;
    }

    // Create new prescription
    const code = `RX-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    const newRx = addPrescription({
      prescriptionCode: code,
      patientId: 'pat-' + Date.now(),
      patientName: patientName.trim(),
      patientAddress: patientAddress.trim() || 'উত্তরা, ঢাকা',
      registerPageNo: registerPageNo.trim() || undefined,
      patientAge: Number(patientAge) || 30,
      patientGender,
      patientPhone: patientPhone.trim(),
      date: today,
      doctorId: doc.id,
      doctorName: doc.name,
      doctorQualification: doc.qualification,
      diagnosis: diagnosis.trim(),
      symptoms: symptomsText.split(',').map((s) => s.trim()).filter(Boolean),
      constitutionalState: constitutionalState.trim(),
      medicines,
      dietRestrictions: selectedRestrictions,
      lifestyleAdvice: ['পর্যাপ্ত পরিমাণে বিশুদ্ধ কুসুম গরম পানি পান করুন', 'নিয়মিত ও পর্যাপ্ত ঘুম নিশ্চিত করুন'],
      followUpDate: followUpDate || '১৫ দিন পর',
      notes: dietNotes.trim(),
      prescriptionImage: prescriptionImage || undefined
    });

    handleResetForm();
    setActiveSubView('list');
    setSelectedPrescriptionForView(newRx);
    setIsPrescriptionLookupOpen(true);
  };

  const filteredPrescriptions = prescriptions.filter(
    (rx) =>
      rx.prescriptionCode.toLowerCase().includes(searchFilter.toLowerCase()) ||
      rx.patientName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (rx.patientAddress && rx.patientAddress.toLowerCase().includes(searchFilter.toLowerCase())) ||
      (rx.registerPageNo && rx.registerPageNo.toLowerCase().includes(searchFilter.toLowerCase())) ||
      rx.patientPhone.includes(searchFilter) ||
      rx.diagnosis.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Title & Tabs */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <FileText className="w-5 h-5 text-[#2271b1]" />
            <span>ডিজিটাল প্রেসক্রিপশন ও ওষুধ রেজিস্ট্রি</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            অনলাইন প্রেসক্রিপশন তৈরি, পোটেন্সি নির্ধারণ ও ওষুধের সেবনবিধি পরিচালনা।
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => setActiveSubView('list')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              activeSubView === 'list'
                ? 'bg-[#2271b1] text-white'
                : 'bg-white dark:bg-[#1a2024] text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-700'
            }`}
          >
            প্রেসক্রিপশন তালিকা ({prescriptions.length})
          </button>
          <button
            onClick={() => {
              handleResetForm();
              setActiveSubView('create');
            }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 ${
              activeSubView === 'create' && !editingPrescriptionId
                ? 'bg-[#2271b1] text-white'
                : 'bg-white dark:bg-[#1a2024] text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-700'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>নতুন প্রেসক্রিপশন লিখুন</span>
          </button>
          {editingPrescriptionId && (
            <button
              onClick={() => setActiveSubView('create')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 bg-amber-500 text-white shadow-xs`}
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>প্রেসক্রিপশন ও পথ্য সম্পাদনা</span>
            </button>
          )}
        </div>
      </div>

      {activeSubView === 'create' ? (
        /* Prescription Creation / Editing Form */
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <form onSubmit={handleSavePrescription} className="space-y-6 text-xs">
            
            <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex justify-between items-center">
              <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-2">
                {editingPrescriptionId ? (
                  <>
                    <Edit2 className="w-4 h-4 text-amber-500" />
                    <span>প্রেসক্রিপশন ও পথ্য নির্দেশিকা সম্পাদনা (Edit Prescription & Diet)</span>
                  </>
                ) : (
                  <span>১. রোগীর মৌলিক তথ্য ও চিকিৎসক নির্বাচন</span>
                )}
              </h3>
              {editingPrescriptionId && (
                <span className="px-2.5 py-1 rounded-full text-[11px] font-mono bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 font-bold border border-amber-300">
                  সম্পাদনা মোড সক্রিয়
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              <div>
                <label className="block font-bold mb-1">রোগীর নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: কামরুল ইসলাম"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">রোগীর ঠিকানা</label>
                <input
                  type="text"
                  placeholder="যেমন: মিরপুর-১০, ঢাকা"
                  value={patientAddress}
                  onChange={(e) => setPatientAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-emerald-800 dark:text-emerald-300">
                    খাতার পেজ নম্বর
                  </label>
                  <span className="text-[10px] text-gray-400 font-medium">রেজিস্টার খাতা</span>
                </div>
                <input
                  type="text"
                  placeholder="যেমন: খাতা-১, পৃষ্ঠা ১২"
                  value={registerPageNo}
                  onChange={(e) => setRegisterPageNo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-emerald-300 dark:border-emerald-700 bg-emerald-50/40 dark:bg-emerald-950/20 font-bold text-emerald-900 dark:text-emerald-200"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">বয়স ও লিঙ্গ *</label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    placeholder="বয়স"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value ? Number(e.target.value) : '')}
                    className="w-16 px-2 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value as any)}
                    className="flex-1 px-2 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="শিশু">শিশু</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">মোবাইল নম্বর *</label>
                <input
                  type="tel"
                  required
                  placeholder="০১৭১২-৩৪৫৬৭৮"
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">চিকিৎসক *</label>
                <select
                  value={doctorId}
                  onChange={(e) => setDoctorId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Diagnosis & Symptoms */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div>
                <label className="block font-bold mb-1">রোগ নির্ণয় (Diagnosis) *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: Chronic Gastritis / Eczema"
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">লক্ষণসমূহ (কমা দিয়ে লিখুন)</label>
                <input
                  type="text"
                  placeholder="পেটে গ্যাস, অম্ল ঢেকুর, অস্থিরতা"
                  value={symptomsText}
                  onChange={(e) => setSymptomsText(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">মায়াজমেটিক স্টেজ / কন্সটিটিউশন</label>
                <input
                  type="text"
                  placeholder="যেমন: Psora / Sycosis / Nux Type"
                  value={constitutionalState}
                  onChange={(e) => setConstitutionalState(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                />
              </div>
            </div>

            {/* Medicines List Section */}
            <div className="pt-4 border-t border-gray-200 dark:border-gray-800">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-2">
                  <Pill className="w-4 h-4 text-emerald-600" />
                  <span>২. হোমিওপ্যাথিক ওষুধ ও সেবনবিধি (Prescribed Medicines)</span>
                </h3>
                <button
                  type="button"
                  onClick={handleAddMedicineRow}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center space-x-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>আরো ওষুধ যোগ করুন</span>
                </button>
              </div>

              {/* Datalists for Autocomplete */}
              <datalist id="potency-datalist">
                {TYPICAL_POTENCIES.map((pot) => (
                  <option key={pot} value={pot} />
                ))}
              </datalist>
              <datalist id="remedies-datalist">
                {COMMON_HOMEOPATHIC_REMEDIES.map((rem) => (
                  <option key={rem} value={rem} />
                ))}
              </datalist>

              {/* Medicine Table Inputs */}
              <div className="space-y-3">
                {medicines.map((med, index) => (
                  <div
                    key={med.id}
                    className="p-3.5 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-[#151a1e] space-y-2.5 shadow-2xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-start">
                      {/* Medicine Name */}
                      <div className="sm:col-span-4">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          ওষুধের নাম #{index + 1} *
                        </label>
                        <input
                          type="text"
                          required
                          list="remedies-datalist"
                          placeholder="যেমন: Arnica Montana / Nux Vomica"
                          value={med.name}
                          onChange={(e) => handleMedicineChange(med.id, 'name', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white font-medium focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      {/* Potency: Free-Type with Datalist & Quick-Pills */}
                      <div className="sm:col-span-3">
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300">
                            পোটেন্সি (টাইপ করুন বা নির্বাচন) *
                          </label>
                          <span className="text-[10px] text-purple-600 dark:text-purple-400 font-bold">
                            টাইপযোগ্য
                          </span>
                        </div>
                        <input
                          type="text"
                          required
                          list="potency-datalist"
                          placeholder="যেমন: 30C, 200, 1M, Q, 0/1, 6X"
                          value={med.potency}
                          onChange={(e) => handleMedicineChange(med.id, 'potency', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-purple-300 dark:border-purple-800 bg-purple-50/40 dark:bg-purple-950/20 text-xs font-mono font-bold text-purple-950 dark:text-purple-200 focus:bg-white focus:ring-2 focus:ring-purple-500"
                        />
                        {/* Quick Typical Potency Pills */}
                        <div className="flex flex-wrap items-center gap-1 mt-1.5">
                          <span className="text-[9px] text-gray-400 font-semibold">কুইক:</span>
                          {QUICK_POTENCY_PILLS.map((pill) => (
                            <button
                              key={pill}
                              type="button"
                              onClick={() => handleMedicineChange(med.id, 'potency', pill)}
                              className={`px-1.5 py-0.5 text-[9px] font-mono rounded transition border ${
                                med.potency === pill || med.potency.startsWith(pill)
                                  ? 'bg-purple-600 text-white border-purple-600 font-bold shadow-2xs'
                                  : 'bg-white dark:bg-[#1a2024] text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-purple-50 hover:border-purple-300'
                              }`}
                              title={`পোটেন্সি '${pill}' বসান`}
                            >
                              {pill}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Dosage */}
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          মাত্রা ও নিয়ম
                        </label>
                        <input
                          type="text"
                          placeholder="২ ফোঁটা / ৪টি গ্লোবিউলস"
                          value={med.dosage}
                          onChange={(e) => handleMedicineChange(med.id, 'dosage', e.target.value)}
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white"
                        />
                      </div>

                      {/* Timing & Duration */}
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          সময় ও সেবন নির্দেশ
                        </label>
                        <input
                          type="text"
                          placeholder="খাবারের ৩০ মিনিট পূর্বে"
                          value={med.timing}
                          onChange={(e) => handleMedicineChange(med.id, 'timing', e.target.value)}
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white"
                        />
                      </div>

                      {/* Remove Button */}
                      <div className="sm:col-span-1 text-right pt-6">
                        <button
                          type="button"
                          onClick={() => handleRemoveMedicineRow(med.id)}
                          disabled={medicines.length <= 1}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg disabled:opacity-30 transition"
                          title="ওষুধের সারিটি মুছুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Homeopathic Diet & Restrictions Section with Blank Box & Inline Edit */}
            <div className="pt-5 border-t border-gray-200 dark:border-gray-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-200 dark:border-gray-800 pb-2">
                <div>
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-2">
                    <UtensilsCrossed className="w-4 h-4 text-emerald-600" />
                    <span>৩. হোমিওপ্যাথিক পথ্য ও বর্জনীয় নির্দেশিকা (Dietary & Restrictions)</span>
                  </h3>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    হোমিওপ্যাথিক ওষুধের দ্রুত কার্যকারিতার জন্য রোগীর খাদ্যতালিকা ও বর্জনীয় বিষয়সমূহ ইনপুট ও এডিট করুন।
                  </p>
                </div>
                <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-md border border-emerald-200 dark:border-emerald-800 flex items-center space-x-1">
                  <Sparkles className="w-3 h-3" />
                  <span>তথ্য ইনপুট ও সম্পাদনা সক্রিয়</span>
                </div>
              </div>

              {/* A. Blank Input Box to type and add new guideline */}
              <div className="bg-emerald-50/70 dark:bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-800 space-y-2.5">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200">
                    নতুন পথ্য বা বর্জনীয় নির্দেশিকা ইনপুট বক্স (Blank Input Box):
                  </label>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-400">
                    বাংলায় টাইপ করে এন্টার চাপুন বা বোতামে ক্লিক করুন
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customRestrictionInput}
                    onChange={(e) => setCustomRestrictionInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomRestriction();
                      }
                    }}
                    placeholder="যেমন: কাঁচা পিঁয়াজ ও রসুন সম্পূর্ণরূপে পরিহার্য / কুসুম গরম পানি ও সুপাচ্য খাদ্য গ্রহণ করুন..."
                    className="flex-1 px-3 py-2 rounded-lg border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-[#131b1e] text-xs text-gray-900 dark:text-white shadow-xs focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomRestriction}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 shrink-0 shadow-xs transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>ইনপুট / যুক্ত করুন</span>
                  </button>
                </div>

                {/* Quick Homeopathic Preset Pills */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-gray-500 dark:text-gray-400 font-semibold mr-1">
                    কমন হোমিও পথ্য ও বর্জনীয়:
                  </span>
                  {commonPresetSuggestions.map((pill, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleAddPresetPill(pill)}
                      className="text-[10px] px-2 py-0.5 rounded-full bg-white dark:bg-gray-800 border border-emerald-200 dark:border-emerald-800 hover:border-emerald-500 hover:bg-emerald-50 text-gray-700 dark:text-gray-300 transition"
                      title="ক্লিক করে তালিকায় যোগ করুন"
                    >
                      + {pill}
                    </button>
                  ))}
                </div>
              </div>

              {/* B. Checklist of Guidelines with Inline Edit & Delete */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center space-x-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>পথ্য ও বর্জনীয় নির্দেশিকা তালিকা ({selectedRestrictions.length} টি প্রেসক্রিপশনে সক্রিয়):</span>
                  </span>
                  <span className="text-[10px] text-gray-400">
                    পেন্সিল আইকনে ক্লিক করে যেকোনো তথ্য সরাসরি এডিট করুন
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                  {restrictionsList.map((item, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition ${
                        selectedRestrictions.includes(item)
                          ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800/60'
                          : 'bg-gray-50 dark:bg-[#151a1e] border-gray-200 dark:border-gray-800 opacity-70'
                      }`}
                    >
                      {editingRestrictionIndex === idx ? (
                        /* Inline Edit Mode */
                        <div className="flex items-center space-x-1.5 w-full">
                          <input
                            type="text"
                            value={editingRestrictionText}
                            onChange={(e) => setEditingRestrictionText(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleSaveEditRestriction(idx);
                              }
                            }}
                            className="flex-1 px-2 py-1 rounded border border-[#2271b1] bg-white dark:bg-[#131b1e] text-xs text-gray-900 dark:text-white"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditRestriction(idx)}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[10px] flex items-center space-x-0.5"
                            title="সেভ করুন"
                          >
                            <Check className="w-3 h-3" />
                            <span>সেভ</span>
                          </button>
                          <button
                            type="button"
                            onClick={handleCancelEditRestriction}
                            className="p-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded"
                            title="বাতিল"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        /* Normal Checklist Item */
                        <>
                          <label className="flex items-center space-x-2 cursor-pointer flex-1 mr-1 select-none overflow-hidden">
                            <input
                              type="checkbox"
                              checked={selectedRestrictions.includes(item)}
                              onChange={() => toggleRestriction(item)}
                              className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 shrink-0"
                            />
                            <span
                              className={`truncate leading-snug ${
                                selectedRestrictions.includes(item)
                                  ? 'font-medium text-gray-900 dark:text-white'
                                  : 'text-gray-500'
                              }`}
                              title={item}
                            >
                              {item}
                            </span>
                          </label>

                          <div className="flex items-center space-x-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleStartEditRestriction(idx, item)}
                              className="p-1 text-[#2271b1] hover:bg-blue-100 dark:hover:bg-blue-950/50 rounded transition"
                              title="এই নির্দেশিকাটি এডিট করুন"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteRestriction(item)}
                              className="p-1 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/50 rounded transition"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* C. Dedicated Multi-line Free-Text Blank Box for Custom Diet & Instructions */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-xs text-gray-900 dark:text-white flex items-center space-x-1.5">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span>চিকিৎসকের উন্মুক্ত পথ্য ও বর্জনীয় বিবরণী বক্স (Free-text Blank Box):</span>
                  </label>
                  <span className="text-[10px] text-gray-400">
                    এখানে রোগীর জন্য বিশেষ খাদ্যতালিকা ও নির্দেশনা ইনপুট করুন
                  </span>
                </div>
                <textarea
                  rows={3}
                  value={dietNotes}
                  onChange={(e) => setDietNotes(e.target.value)}
                  placeholder="এখানে রোগীর পথ্য (কী কী খাবেন, কী নিয়ম মানবেন), বর্জনীয় খাদ্য ও পানীয়ের বিস্তারিত তালিকা, কিংবা চিকিৎসকের বিশেষ কোনো নির্দেশনাবলী সরাসরি বাংলায় ইনপুট করুন..."
                  className="w-full px-3 py-2.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-xs text-gray-900 dark:text-white leading-relaxed focus:bg-white focus:ring-2 focus:ring-emerald-500 shadow-xs"
                />
                <p className="text-[10px] text-gray-400 mt-1">
                  ✓ এই উন্মুক্ত বক্সে লেখা নির্দেশনাবলী রোগীর ডিজিটাল প্রেসক্রিপশনে এবং অনলাইন পোর্টালে বিশেষভাবে প্রদর্শিত ও প্রিন্ট হবে।
                </p>
              </div>

              {/* D. Prescription Photo / Scan Copy Upload (প্রেসক্রিপশন ছবি আপলোড সুবিধা) */}
              <div className="pt-3 border-t border-gray-200 dark:border-gray-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center space-x-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs sm:text-sm">
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span>৪. প্রেসক্রিপশন ছবি / স্ক্যান কপি আপলোড (Prescription Photo Upload)</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                    ক্যামেরা ও গ্যালারি সাপোর্ট
                  </span>
                </div>

                <p className="text-gray-500 dark:text-gray-400 text-[11px]">
                  হাতে লেখা প্রেসক্রিপশনের ছবি, রিপোর্টের ছবি বা প্রেসক্রিপশনের স্ক্যান কপি আপলোড করুন। রোগী ও ডাক্তার উভয়েই ডিজিটাল পোর্টাল থেকে ছবিটি দেখতে ও ডাউনলোড করতে পারবেন।
                </p>

                {prescriptionImage ? (
                  /* Uploaded Image Preview Box */
                  <div className="bg-emerald-50/50 dark:bg-emerald-950/20 border-2 border-emerald-300 dark:border-emerald-800/80 rounded-xl p-4 flex flex-col sm:flex-row items-center gap-4">
                    <div className="relative group shrink-0">
                      <img
                        src={prescriptionImage}
                        alt="Prescription Scan Preview"
                        className="w-28 h-28 sm:w-36 sm:h-36 object-cover rounded-lg border border-emerald-400 dark:border-emerald-700 shadow-sm cursor-pointer hover:opacity-90 transition"
                        onClick={() => setPreviewImageModalUrl(prescriptionImage)}
                      />
                      <button
                        type="button"
                        onClick={() => setPreviewImageModalUrl(prescriptionImage)}
                        className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition rounded-lg text-[11px] font-bold"
                      >
                        <Maximize2 className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-2 flex-1 text-center sm:text-left">
                      <div className="flex items-center justify-center sm:justify-start space-x-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>প্রেসক্রিপশনের ছবি সফলভাবে সংযুক্ত করা হয়েছে</span>
                      </div>
                      <p className="text-[11px] text-gray-500 dark:text-gray-400">
                        প্রেসক্রিপশনটি সংরক্ষণ করলে এই ছবিটি রোগীর ডিজিটাল পোর্টালে ও প্রিন্ট কপিতে স্বয়ংক্রিয়ভাবে প্রদর্শিত হবে।
                      </p>

                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setPreviewImageModalUrl(prescriptionImage)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center space-x-1 shadow-2xs transition"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                          <span>বড় করে দেখুন</span>
                        </button>

                        <label
                          htmlFor="rx-file-upload-replace"
                          className="px-3 py-1.5 bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-700 rounded-lg text-xs font-bold flex items-center space-x-1 cursor-pointer transition shadow-2xs"
                        >
                          <UploadCloud className="w-3.5 h-3.5 text-blue-500" />
                          <span>অন্য ছবি আপলোড করুন</span>
                          <input
                            id="rx-file-upload-replace"
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={handleImageFileUpload}
                            className="hidden"
                          />
                        </label>

                        <button
                          type="button"
                          onClick={() => setPrescriptionImage(null)}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 rounded-lg text-xs font-bold flex items-center space-x-1 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>ছবি মুছে ফেলুন</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Empty Upload Dropzone */
                  <div className="space-y-3">
                    <label
                      htmlFor="rx-file-upload"
                      className="border-2 border-dashed border-emerald-400/80 hover:border-emerald-600 dark:border-emerald-700 dark:hover:border-emerald-500 bg-emerald-50/30 hover:bg-emerald-50/60 dark:bg-emerald-950/10 dark:hover:bg-emerald-950/20 rounded-xl p-5 flex flex-col items-center justify-center cursor-pointer transition text-center group"
                    >
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center group-hover:scale-110 transition-transform mb-2">
                        <Camera className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <span className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white block">
                        প্রেসক্রিপশন ছবি বা স্ক্যান কপি আপলোড করতে এখানে ক্লিক করুন
                      </span>
                      <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 block">
                        মোবাইল থেকে সরাসরি ছবি তুলুন অথবা গ্যালারি / কম্পিউটার ফাইল থেকে নির্বাচন করুন (JPG, PNG, WebP)
                      </span>
                      <input
                        id="rx-file-upload"
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={handleImageFileUpload}
                        className="hidden"
                      />
                    </label>

                    {/* Alternative Image URL Input */}
                    <div className="flex items-center justify-between text-[11px] text-gray-500">
                      <span>অথবা আপনি চাইলে সরাসরি ছবির ওয়েব লিংক (URL) দিয়েও যুক্ত করতে পারেন:</span>
                      <button
                        type="button"
                        onClick={() => setShowUrlInput(!showUrlInput)}
                        className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                      >
                        {showUrlInput ? 'লিংক ইনপুট বন্ধ করুন' : '+ ছবি লিংক (URL) লিখুন'}
                      </button>
                    </div>

                    {showUrlInput && (
                      <div className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800">
                        <input
                          type="url"
                          value={imageUrlInput}
                          onChange={(e) => setImageUrlInput(e.target.value)}
                          placeholder="https://example.com/prescription-photo.jpg"
                          className="flex-1 px-3 py-1.5 text-xs rounded border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleApplyImageUrl}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-xs"
                        >
                          সংযুক্ত করুন
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* E. Follow-up Date */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1">
                    পরবর্তী সাক্ষাতের সম্ভাব্য তারিখ (Follow-up Date)
                  </label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
                  />
                </div>

                <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 text-[11px] flex items-center">
                  ✓ প্রেসক্রিপশন সংরক্ষিত হলে রোগী সরাসরি মোবাইল নম্বর, নাম, ঠিকানা বা প্রেসক্রিপশন কোড দিয়ে অনলাইন পোর্টাল থেকে দেখতে ও প্রিন্ট করতে পারবেন।
                </div>
              </div>
            </div>

            {/* Submit & Cancel Buttons */}
            <div className="pt-4 border-t border-gray-200 dark:border-gray-800 flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => {
                  handleResetForm();
                  setActiveSubView('list');
                }}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold rounded-lg transition"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-md transition flex items-center space-x-1.5"
              >
                {editingPrescriptionId ? (
                  <>
                    <Save className="w-4 h-4" />
                    <span>প্রেসক্রিপশন ও পথ্য আপডেট করুন</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>প্রেসক্রিপশন প্রকাশ ও সংরক্ষণ করুন</span>
                  </>
                )}
              </button>
            </div>

          </form>
        </div>
      ) : (
        /* Prescriptions List View */
        <div className="bg-white dark:bg-[#1a2024] rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs overflow-hidden">
          
          {/* Search Bar */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="রোগীর নাম, ঠিকানা, মোবাইল নম্বর বা প্রেসক্রিপশন কোড লিখুন..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e]"
              />
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2" />
            </div>

            <span className="text-xs text-gray-500 font-mono">
              মোট: {filteredPrescriptions.length} টি
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-gray-100 dark:bg-[#151a1e] text-gray-600 dark:text-gray-400 font-bold border-b border-gray-300 dark:border-gray-800">
                  <th className="p-3">প্রেসক্রিপশন কোড</th>
                  <th className="p-3">রোগীর নাম ও ঠিকানা</th>
                  <th className="p-3">মোবাইল</th>
                  <th className="p-3">তারিখ</th>
                  <th className="p-3">রোগ নির্ণয় (Diagnosis)</th>
                  <th className="p-3">ওষুধের তালিকা</th>
                  <th className="p-3">চিকিৎসক</th>
                  <th className="p-3 text-right">পদক্ষেপ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
                {filteredPrescriptions.map((rx) => (
                  <tr key={rx.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="p-3">
                      <div className="font-mono font-bold text-emerald-600">
                        {rx.prescriptionCode}
                      </div>
                      {rx.registerPageNo && (
                        <div className="text-[10px] text-amber-800 dark:text-amber-300 font-medium bg-amber-50 dark:bg-amber-950/60 px-1.5 py-0.5 rounded inline-block mt-0.5 border border-amber-200 dark:border-amber-900" title="রেজিস্টার খাতার পেজ নম্বর">
                          খাতা পেজ: {rx.registerPageNo}
                        </div>
                      )}
                      {rx.prescriptionImage && (
                        <div className="mt-1">
                          <button
                            type="button"
                            onClick={() => setPreviewImageModalUrl(rx.prescriptionImage || null)}
                            className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-[10px] font-bold hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition shadow-2xs"
                            title="প্রেসক্রিপশনের সংযুক্ত ছবি দেখুন"
                          >
                            <Camera className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                            <span>ছবি সংযুক্ত</span>
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-gray-900 dark:text-white">
                        {rx.patientName} ({rx.patientAge}ব, {rx.patientGender})
                      </div>
                      <div className="text-[11px] text-gray-500 truncate max-w-xs">
                        {rx.patientAddress || 'মিরপুর, ঢাকা'}
                      </div>
                    </td>
                    <td className="p-3 font-mono text-gray-500">{rx.patientPhone}</td>
                    <td className="p-3 font-mono text-gray-500">{rx.date}</td>
                    <td className="p-3 font-semibold text-gray-800 dark:text-gray-200">
                      {rx.diagnosis}
                    </td>
                    <td className="p-3 text-gray-600 dark:text-gray-400">
                      {rx.medicines.map((m) => `${m.name} (${m.potency})`).join(', ')}
                    </td>
                    <td className="p-3 text-gray-700 dark:text-gray-300">
                      {rx.doctorName}
                    </td>
                    <td className="p-3 text-right space-x-1 whitespace-nowrap">
                      {/* ১. প্রেসক্রিপশন ও পথ্য এডিট */}
                      <button
                        onClick={() => handleEditPrescription(rx)}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="সম্পূর্ণ প্রেসক্রিপশন ও পথ্য এডিট করুন"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>এডিট</span>
                      </button>

                      {/* ২. ওষুধ দ্রুত এডিট বাটন */}
                      <button
                        onClick={() => handleOpenQuickMedicineEdit(rx)}
                        className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="শুধুমাত্র ওষুধ ও পোটেন্সি দ্রুত এডিট করুন"
                      >
                        <Pill className="w-3 h-3" />
                        <span>ওষুধ এডিট</span>
                      </button>

                      {/* ৩. সরাসরি প্রিন্ট বাটন */}
                      <button
                        onClick={() => handleDirectPrint(rx)}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="প্রেসক্রিপশন সরাসরি প্রিন্ট করুন"
                      >
                        <Printer className="w-3 h-3" />
                        <span>প্রিন্ট</span>
                      </button>

                      {/* ৪. প্রিভিউ ও ভিউ বাটন */}
                      <button
                        onClick={() => {
                          setSelectedPrescriptionForView(rx);
                          setIsPrescriptionLookupOpen(true);
                        }}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[11px] inline-flex items-center space-x-1 transition shadow-xs"
                        title="প্রেসক্রিপশন দেখুন"
                      >
                        <Eye className="w-3 h-3" />
                        <span>ভিউ</span>
                      </button>

                      {/* ৫. ডিলেট বাটন */}
                      <button
                        onClick={() => handleOpenDeleteConfirm(rx)}
                        className="px-2 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-800 rounded font-bold text-[11px] inline-flex items-center space-x-0.5 transition"
                        title="প্রেসক্রিপশন মুছে ফেলুন"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>ডিলেট</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* QUICK MEDICINE EDITOR MODAL (ওষুধ ও পোটেন্সি দ্রুত সম্পাদনা মোডাল)           */}
      {/* ========================================================================= */}
      {quickMedicineModalPrescription && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-3xl w-full p-5 sm:p-6 shadow-2xl border border-gray-300 dark:border-gray-700 my-8 animate-scale-up">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold">
                  <Pill className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-gray-900 dark:text-white flex items-center space-x-2">
                    <span>ওষুধ ও পোটেন্সি সম্পাদনা (Edit Medicines & Potencies)</span>
                  </h3>
                  <p className="text-[11px] text-gray-500">
                    প্রেসক্রিপশন: <span className="font-mono font-bold text-emerald-600">{quickMedicineModalPrescription.prescriptionCode}</span> • রোগী: <span className="font-bold">{quickMedicineModalPrescription.patientName}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setQuickMedicineModalPrescription(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickMedicines} className="mt-4 space-y-4 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-gray-700 dark:text-gray-300">
                  নির্ধারিত ওষুধের তালিকা ({quickMedicines.length} টি)
                </span>
                <button
                  type="button"
                  onClick={handleAddQuickMedicineRow}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg text-xs flex items-center space-x-1 shadow-xs transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন ওষুধ যোগ করুন</span>
                </button>
              </div>

              <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
                {quickMedicines.map((med, index) => (
                  <div
                    key={med.id}
                    className="p-3.5 rounded-xl border border-purple-200 dark:border-purple-900/60 bg-purple-50/30 dark:bg-purple-950/20 space-y-2 shadow-2xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-start">
                      {/* Name */}
                      <div className="sm:col-span-4">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          ওষুধের নাম #{index + 1} *
                        </label>
                        <input
                          type="text"
                          required
                          list="remedies-datalist"
                          value={med.name}
                          onChange={(e) => handleQuickMedicineChange(med.id, 'name', e.target.value)}
                          placeholder="Arnica Montana / Nux Vomica"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white font-medium"
                        />
                      </div>

                      {/* Potency */}
                      <div className="sm:col-span-3">
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300">
                            পোটেন্সি *
                          </label>
                          <span className="text-[9px] text-purple-600 font-bold">টাইপযোগ্য</span>
                        </div>
                        <input
                          type="text"
                          required
                          list="potency-datalist"
                          value={med.potency}
                          onChange={(e) => handleQuickMedicineChange(med.id, 'potency', e.target.value)}
                          placeholder="30C, 200, 1M, Q"
                          className="w-full px-2.5 py-1.5 rounded-lg border border-purple-300 dark:border-purple-800 bg-white dark:bg-[#1a2024] font-mono font-bold text-purple-900 dark:text-purple-200 text-xs"
                        />
                        <div className="flex flex-wrap items-center gap-1 mt-1">
                          {QUICK_POTENCY_PILLS.slice(0, 7).map((pill) => (
                            <button
                              key={pill}
                              type="button"
                              onClick={() => handleQuickMedicineChange(med.id, 'potency', pill)}
                              className={`px-1 py-0.2 text-[9px] font-mono rounded border ${
                                med.potency === pill
                                  ? 'bg-purple-600 text-white border-purple-600 font-bold'
                                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                              }`}
                            >
                              {pill}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Dosage */}
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          মাত্রা ও নিয়ম
                        </label>
                        <input
                          type="text"
                          value={med.dosage}
                          onChange={(e) => handleQuickMedicineChange(med.id, 'dosage', e.target.value)}
                          placeholder="২ ফোঁটা / ৪টি বড়ি"
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white"
                        />
                      </div>

                      {/* Frequency & Timing */}
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                          সময় ও সেবনবিধি
                        </label>
                        <input
                          type="text"
                          value={med.timing}
                          onChange={(e) => handleQuickMedicineChange(med.id, 'timing', e.target.value)}
                          placeholder="খাবারের ৩০ মিনিট পূর্বে"
                          className="w-full px-2 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-xs text-gray-900 dark:text-white"
                        />
                      </div>

                      {/* Delete Row */}
                      <div className="sm:col-span-1 text-right pt-5">
                        <button
                          type="button"
                          onClick={() => handleRemoveQuickMedicineRow(med.id)}
                          disabled={quickMedicines.length <= 1}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg disabled:opacity-30 transition"
                          title="এই ওষুধটি মুছুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 flex justify-end space-x-2 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setQuickMedicineModalPrescription(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl font-bold transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs transition flex items-center space-x-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>ওষুধ সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DELETE CONFIRMATION MODAL (প্রেসক্রিপশন ডিলেট কনফার্মেশন)                     */}
      {/* ========================================================================= */}
      {deleteModalPrescription && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-300 dark:border-gray-700 text-center animate-scale-up">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-base text-gray-900 dark:text-white">
              প্রেসক্রিপশনটি মুছে ফেলতে চান?
            </h4>
            <div className="text-xs text-gray-500 mt-2 bg-gray-50 dark:bg-gray-800 p-2.5 rounded-xl border border-gray-200 dark:border-gray-700">
              <div>প্রেসক্রিপশন কোড: <span className="font-mono font-bold text-gray-800 dark:text-gray-200">{deleteModalPrescription.prescriptionCode}</span></div>
              <div>রোগীর নাম: <span className="font-bold text-gray-800 dark:text-gray-200">{deleteModalPrescription.patientName}</span></div>
              <div>রোগ নির্ণয়: <span className="text-gray-700 dark:text-gray-300">{deleteModalPrescription.diagnosis}</span></div>
            </div>
            <p className="text-[11px] text-rose-500 mt-2 font-medium">
              সতর্কতা: মুছে ফেললে রোগী অনলাইনে আর এই প্রেসক্রিপশনটি দেখতে পাবেন না।
            </p>
            <div className="mt-4 flex justify-center space-x-2">
              <button
                onClick={() => setDeleteModalPrescription(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold transition"
              >
                বাতিল
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>হ্যাঁ, মুছে ফেলুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FULL-SIZE PRESCRIPTION IMAGE PREVIEW MODAL                                */}
      {/* ========================================================================= */}
      {previewImageModalUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-4xl w-full p-4 sm:p-5 shadow-2xl border border-gray-300 dark:border-gray-700 flex flex-col max-h-[92vh]">
            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-gray-900 dark:text-white">
                    সংযুক্ত প্রেসক্রিপশনের ছবি / স্ক্যান কপি
                  </h4>
                  <p className="text-[11px] text-gray-500">
                    উচ্চ রেজোলিউশনে প্রেসক্রিপশন বা টেস্ট রিপোর্ট প্রদর্শন
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <a
                  href={previewImageModalUrl}
                  download="prescription-photo.png"
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center space-x-1 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>ডাউনলোড</span>
                </a>
                <button
                  onClick={() => setPreviewImageModalUrl(null)}
                  className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-2 flex items-center justify-center bg-gray-50 dark:bg-black/30 rounded-xl my-3">
              <img
                src={previewImageModalUrl}
                alt="Prescription Document Preview"
                className="max-h-[70vh] w-auto object-contain rounded-lg shadow-md"
              />
            </div>

            <div className="pt-2 text-center text-[11px] text-gray-500 flex items-center justify-between">
              <span>মাউস বা টাচ স্ক্রিনের মাধ্যমে সম্পূর্ণ ছবি পর্যবেক্ষণ করুন</span>
              <button
                onClick={() => setPreviewImageModalUrl(null)}
                className="px-4 py-1.5 bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg font-bold text-xs"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#135e96] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center space-x-2 border border-blue-400/30 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

    </div>
  );
};
