import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  Zap,
  Trash2,
  Database,
  Gauge,
  CheckCircle,
  HardDrive,
  Cpu,
  Layers
} from 'lucide-react';

export const DatabaseOptimizeTab: React.FC = () => {
  const { optimizeDatabase, clearCache, appointments, prescriptions, patients, auditLogs } = useClinic();

  const [feedback, setFeedback] = useState<string | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      const res = optimizeDatabase();
      setFeedback(res.message);
      setIsOptimizing(false);
      setTimeout(() => setFeedback(null), 4000);
    }, 600);
  };

  const handleClearCache = () => {
    clearCache();
    setFeedback('ক্যাশ মেমোরি ও টেম্পোরারি স্টেট সফলভাবে পরিষ্কার করা হয়েছে!');
    setTimeout(() => setFeedback(null), 3000);
  };

  const totalRecords = appointments.length + prescriptions.length + patients.length + auditLogs.length;

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
          <Zap className="w-5 h-5 text-amber-500" />
          <span>ডাটাবেজ অপ্টিমাইজেশন ও ক্যাশিং পারফরম্যান্স</span>
        </h2>
        <p className="text-xs text-gray-500 mt-0.5">
          অ্যাপ্লিকেশনের দ্রুত লোডিং গতি, ইনডেক্স সংকোচন ও ব্রাউজার ক্যাশ ব্যবস্থাপনা।
        </p>
      </div>

      {feedback && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800 text-xs flex items-center space-x-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-gray-500 uppercase">ডাটাবেজ প্রতিক্রিয়া গতি</span>
            <Gauge className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black text-emerald-600 font-mono">
            ১২ ms
          </div>
          <div className="text-[11px] text-gray-500 mt-1">
            ইন-মেমোরি আল্ট্রা ফাস্ট রিড
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-gray-500 uppercase">মোট সক্রিয় রেকর্ড</span>
            <Database className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-3xl font-black text-gray-900 dark:text-white font-mono">
            {totalRecords}
          </div>
          <div className="text-[11px] text-gray-500 mt-1">
            ইনডেক্সড ডাটা অবজেক্টস
          </div>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-gray-500 uppercase">ক্যাশিং স্টেটাস</span>
            <Layers className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-3xl font-black text-purple-600 font-mono">
            ১০০%
          </div>
          <div className="text-[11px] text-gray-500 mt-1">
            অফলাইন ও হট-ক্যাশ সক্রিয়
          </div>
        </div>

      </div>

      {/* Optimization Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="font-bold text-sm text-gray-900 dark:text-white mb-2 flex items-center space-x-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>ডাটাবেজ কম্প্যাক্ট ও ইনডেক্স অপ্টিমাইজেশন</span>
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              পুরনো লগ ডাটা ট্রিম করে এবং ইনডেক্স রিস্ট্রাকচার করে অ্যাপ্লিকেশনের কার্যক্ষমতা ও রেসপন্স টাইম বৃদ্ধি করুন।
            </p>
          </div>

          <button
            onClick={handleOptimize}
            disabled={isOptimizing}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center space-x-2"
          >
            <Zap className="w-4 h-4" />
            <span>{isOptimizing ? 'অপ্টিমাইজেশন চলছে...' : 'এখনই ডাটাবেজ অপ্টিমাইজ করুন'}</span>
          </button>
        </div>

        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="font-bold text-sm text-gray-900 dark:text-white mb-2 flex items-center space-x-2">
              <Trash2 className="w-4 h-4 text-rose-500" />
              <span>ক্যাশ মেমোরি ও বাফার ক্লিয়ার করুন</span>
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              ব্রাউজারে জমে থাকা অপ্রয়োজনীয় ক্যাশ ফাইল, প্রেসক্রিপশন টেম্পোরারি স্টেট এবং রেন্ডার বাফার মুছে ফ্রেশ করুন।
            </p>
          </div>

          <button
            onClick={handleClearCache}
            className="w-full py-2.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold text-xs rounded-xl border border-gray-300 dark:border-gray-700 transition flex items-center justify-center space-x-2"
          >
            <Trash2 className="w-4 h-4 text-rose-500" />
            <span>ক্যাশ ক্লিয়ার করুন</span>
          </button>
        </div>

      </div>

    </div>
  );
};
