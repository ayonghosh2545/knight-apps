import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext.tsx';
import {
  UserCheck,
  Save,
  KeyRound,
  Shield,
  Mail,
  Phone,
  GraduationCap,
  Award,
  CheckCircle,
  Eye,
  EyeOff,
  Camera,
  RefreshCw,
  Lock,
  UserCog,
  ShieldAlert,
  Settings,
  Stethoscope
} from 'lucide-react';

export const AdminSettingsTab: React.FC = () => {
  const { adminProfile, updateAdminProfile, setAdminSubTab } = useClinic();

  const [formData, setFormData] = useState({ ...adminProfile });
  const [newMasterCode, setNewMasterCode] = useState(adminProfile.masterSecurityCode || 'AYON540');
  const [confirmMasterCode, setConfirmMasterCode] = useState(adminProfile.masterSecurityCode || 'AYON540');
  const [showMasterCode, setShowMasterCode] = useState(false);
  const [new2faPin, setNew2faPin] = useState(adminProfile.twoFactorPin || '540540');

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const avatarPresets = [
    'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80'
  ];

  const handleChange = (field: keyof typeof adminProfile, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setFeedback(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim() || !formData.username.trim()) {
      setFeedback({ type: 'error', message: 'নাম, ব্যবহারকারীর নাম (ইউজারনেম) এবং ইমেইল ঠিকানা আবশ্যক।' });
      return;
    }

    if (newMasterCode.trim() !== confirmMasterCode.trim()) {
      setFeedback({ type: 'error', message: 'মাস্টার সিকিউরিটি কোড ও নিশ্চিতকরণ কোড দুটি মিলছে না।' });
      return;
    }

    if (!newMasterCode.trim()) {
      setFeedback({ type: 'error', message: 'মাস্টার সিকিউরিটি কোড খালি রাখা যাবে না।' });
      return;
    }

    updateAdminProfile({
      ...formData,
      masterSecurityCode: newMasterCode.trim(),
      twoFactorPin: new2faPin.trim() || '540540'
    });

    setFeedback({
      type: 'success',
      message: 'অভিনন্দন! আপনার অ্যাডমিন অ্যাকাউন্টের সকল তথ্য সফলভাবে সংরক্ষিত ও আপডেট হয়েছে।'
    });

    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Settings Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-gray-200 dark:border-gray-800 pb-3">
        <button
          type="button"
          onClick={() => setAdminSubTab('settings')}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-xs font-bold transition flex items-center space-x-2"
        >
          <Settings className="w-4 h-4 text-emerald-600" />
          <span>&larr; ১. চেম্বার তথ্য ও সিস্টেম কনফিগারেশন</span>
        </button>
        <button
          type="button"
          className="px-4 py-2 bg-[#2271b1] text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-2"
        >
          <UserCog className="w-4 h-4" />
          <span>২. অ্যাডমিন অ্যাকাউন্ট সেটিংস (প্রোফাইল এডিট)</span>
        </button>
        <button
          type="button"
          onClick={() => setAdminSubTab('doctors')}
          className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 rounded-lg text-xs font-bold transition flex items-center space-x-2 border border-emerald-200 dark:border-emerald-800"
        >
          <Stethoscope className="w-4 h-4 text-emerald-600" />
          <span>৩. ডাক্তার প্রোফাইল ও চেম্বার প্যানেল &rarr;</span>
        </button>
      </div>

      {/* Page Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
            <UserCog className="w-5 h-5 text-[#2271b1]" />
            <span>অ্যাডমিন অ্যাকাউন্ট সেটিংস ও প্রোফাইল ব্যবস্থাপনা</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            আপনার অ্যাডমিন প্রোফাইল, ব্যক্তিগত পরিচিতি, যোগাযোগের তথ্য ও মাস্টার সিকিউরিটি কোড এডিট করুন।
          </p>
        </div>

        {feedback && (
          <div
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 animate-in fade-in ${
              feedback.type === 'success'
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600" />
            ) : (
              <ShieldAlert className="w-4 h-4 text-rose-600" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        
        {/* Profile Card & Avatar */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
            
            {/* Avatar Preview */}
            <div className="flex flex-col items-center space-y-2 shrink-0">
              <div className="relative group">
                <img
                  src={formData.avatarUrl || avatarPresets[0]}
                  alt="Admin Avatar"
                  className="w-24 h-24 rounded-2xl object-cover border-4 border-emerald-500/30 shadow-md group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Camera className="w-6 h-6 text-white" />
                </div>
              </div>
              <span className="text-[10px] text-gray-400 font-medium">প্রোফাইল ফটো</span>
            </div>

            {/* Avatar URL & Quick Presets */}
            <div className="flex-1 w-full space-y-3">
              <div>
                <label className="block font-bold mb-1">
                  প্রোফাইল ছবির লিংক (Avatar Image URL)
                </label>
                <input
                  type="url"
                  value={formData.avatarUrl}
                  onChange={(e) => handleChange('avatarUrl', e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <span className="text-[11px] font-semibold text-gray-500 block mb-1.5">
                  ডিফল্ট ডক্টর অবতার নির্বাচন করুন:
                </span>
                <div className="flex items-center space-x-2">
                  {avatarPresets.map((preset, idx) => (
                    <img
                      key={idx}
                      src={preset}
                      alt={`Preset ${idx + 1}`}
                      onClick={() => handleChange('avatarUrl', preset)}
                      className={`w-9 h-9 rounded-lg object-cover cursor-pointer border-2 transition ${
                        formData.avatarUrl === preset
                          ? 'border-emerald-600 scale-105 shadow-sm'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 1. Personal & Contact Information */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center space-x-2 text-[#2271b1]">
            <UserCheck className="w-4 h-4" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ১. অ্যাডমিন অ্যাকাউন্ট ও ব্যক্তিগত তথ্য
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">অ্যাডমিনের পূর্ণ নাম *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="যেমন: ড. সুমন কুমার"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-medium"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">ব্যবহারকারীর নাম (Username) *</label>
              <input
                type="text"
                required
                value={formData.username}
                onChange={(e) => handleChange('username', e.target.value)}
                placeholder="যেমন: admin"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">ইমেইল ঠিকানা (Login & Notifications) *</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="sumonkumar.nc052@gmail.com"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">ব্যক্তিগত মোবাইল নম্বর *</label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="০১৭৭৫-৯৮৪৫২০"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold mb-1">পেশাগত পদবী (Designation)</label>
              <input
                type="text"
                value={formData.designation}
                onChange={(e) => handleChange('designation', e.target.value)}
                placeholder="চিফ কনসালট্যান্ট ও ক্লাসিকাল হোমিওপ্যাথি গবেষক"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-bold mb-1">ডিগ্রি ও শিক্ষাগত যোগ্যতা</label>
              <input
                type="text"
                value={formData.qualifications}
                onChange={(e) => handleChange('qualifications', e.target.value)}
                placeholder="BHMS (ঢাকা বিশ্ববিদ্যালয়), DHMS (গোল্ড মেডেলিস্ট), PGT (ভারত)"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold mb-1">সংক্ষিপ্ত পরিচিতি ও বায়ো (Bio)</label>
            <textarea
              rows={2}
              value={formData.bio}
              onChange={(e) => handleChange('bio', e.target.value)}
              placeholder="চিকিৎসকের অভিজ্ঞতা ও বিশেষজ্ঞ পরিচিতি..."
              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white"
            />
          </div>
        </div>

        {/* 2. Master Security Code & Credentials */}
        <div className="bg-white dark:bg-[#1a2024] p-6 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs space-y-4">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-3 flex items-center justify-between">
            <div className="flex items-center space-x-2 text-emerald-600">
              <KeyRound className="w-4 h-4" />
              <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                ২. মাস্টার সিকিউরিটি কোড ও পাসওয়ার্ড ব্যবস্থাপনা
              </h3>
            </div>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2 py-0.5 rounded font-bold">
              গোপনীয় ও সুরক্ষিত
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block font-bold">মাস্টার সিকিউরিটি কোড *</label>
                <button
                  type="button"
                  onClick={() => setShowMasterCode(!showMasterCode)}
                  className="text-gray-400 hover:text-gray-600 text-[11px] flex items-center space-x-1"
                >
                  {showMasterCode ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  <span>{showMasterCode ? 'লুকান' : 'দেখুন'}</span>
                </button>
              </div>
              <input
                type={showMasterCode ? 'text' : 'password'}
                required
                value={newMasterCode}
                onChange={(e) => setNewMasterCode(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono tracking-wider"
              />
              <span className="text-[10px] text-gray-400 mt-1 block">
                লগইন করার সময় এই কোডটি প্রবেশ করাতে হবে।
              </span>
            </div>

            <div>
              <label className="block font-bold mb-1">মাস্টার কোড নিশ্চিত করুন *</label>
              <input
                type={showMasterCode ? 'text' : 'password'}
                required
                value={confirmMasterCode}
                onChange={(e) => setConfirmMasterCode(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono tracking-wider"
              />
              <span className="text-[10px] text-gray-400 mt-1 block">
                পুনরায় একই মাস্টার কোড প্রবেশ করান।
              </span>
            </div>
          </div>

          {/* 2FA PIN */}
          <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
            <label className="block font-bold mb-1">
              টু-ফ্যাক্টর অথেনটিকেশন (2FA) স্ট্যাটিক ব্যাকআপ পিন
            </label>
            <input
              type="text"
              value={new2faPin}
              onChange={(e) => setNew2faPin(e.target.value)}
              placeholder="540540"
              className="w-full sm:w-60 px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono tracking-widest"
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              জরুরি মুহূর্তে ওটিপি না আসলে এই ৬-সংখ্যার পিন দিয়ে 2FA বাইপাস করে লগইন করা যাবে।
            </span>
          </div>
        </div>

        {/* 3. Role & Permissions Overview */}
        <div className="bg-white dark:bg-[#1a2024] p-5 rounded-xl border border-gray-300 dark:border-gray-800 shadow-xs">
          <div className="border-b border-gray-200 dark:border-gray-800 pb-2 mb-3 flex items-center space-x-2 text-purple-600">
            <Shield className="w-4 h-4" />
            <h3 className="font-bold text-sm text-gray-900 dark:text-white">
              ৩. ব্যবহারকারী ভূমিকা ও অনুমতি (Role & Privileges)
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-gray-50 dark:bg-[#131b1e] rounded-lg border border-gray-200 dark:border-gray-800">
              <span className="text-gray-500 block text-[10px] uppercase font-bold">ইউজার রোল</span>
              <span className="font-bold text-gray-900 dark:text-white text-sm">
                {formData.role || 'সুপার অ্যাডমিন'}
              </span>
            </div>

            <div className="p-3 bg-gray-50 dark:bg-[#131b1e] rounded-lg border border-gray-200 dark:border-gray-800">
              <span className="text-gray-500 block text-[10px] uppercase font-bold">অ্যাক্সেস লেভেল</span>
              <span className="font-bold text-emerald-600 text-sm">
                পূর্ণ প্রশাসনিক ক্ষমতা (Full Control)
              </span>
            </div>

            <div className="p-3 bg-gray-50 dark:bg-[#131b1e] rounded-lg border border-gray-200 dark:border-gray-800">
              <span className="text-gray-500 block text-[10px] uppercase font-bold">নিরাপত্তা এনক্রিপশন</span>
              <span className="font-bold text-purple-600 text-sm">
                AES-Salt এন্ড-টু-এন্ড সক্রিয়
              </span>
            </div>
          </div>
        </div>

        {/* Save Changes Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold rounded-lg shadow-md transition flex items-center space-x-2 text-sm"
          >
            <Save className="w-4 h-4" />
            <span>অ্যাকাউন্টের সকল তথ্য সেভ করুন (Save Account Settings)</span>
          </button>
        </div>

      </form>

    </div>
  );
};
