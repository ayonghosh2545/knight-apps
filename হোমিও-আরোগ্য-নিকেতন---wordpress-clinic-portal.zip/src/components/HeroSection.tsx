import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Calendar,
  FileSearch,
  Bot,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Search,
  Sparkles,
  Award,
  Users,
  Activity,
  ArrowRight,
  Clock
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const {
    settings,
    appointments,
    patients,
    prescriptions,
    setIsBookingModalOpen,
    setIsPrescriptionLookupOpen,
    setActiveLookupCodeOrPhone,
    setIsChatbotOpen
  } = useClinic();

  const [quickSearchInput, setQuickSearchInput] = useState('');

  const handleQuickLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickSearchInput.trim()) return;
    setActiveLookupCodeOrPhone(quickSearchInput.trim());
    setIsPrescriptionLookupOpen(true);
  };

  return (
    <section id="hero" className="relative bg-gradient-to-b from-emerald-50/50 via-white to-gray-50 dark:from-[#131b1e] dark:via-[#161c20] dark:to-[#1a2024] pt-8 pb-16 transition-colors">
      
      {/* Live Notice Banner */}
      {settings.noticeActive && settings.noticeText && (
        <div className="max-w-7xl mx-auto px-4 mb-8">
          <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 px-4 py-3 rounded-xl flex items-center justify-between shadow-xs">
            <div className="flex items-center space-x-2.5">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <p className="text-xs sm:text-sm font-medium">{settings.noticeText}</p>
            </div>
            <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider bg-amber-200/60 dark:bg-amber-900/60 px-2 py-0.5 rounded ml-2 shrink-0">
              নোটিশ
            </span>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Headlines, Highlights & Action */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center space-x-2 bg-emerald-100/80 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 px-3.5 py-1.5 rounded-full text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>ডিজিটাল হোমিওপ্যাথি আরোগ্য নিকেতন ও রোগী সেবা পোর্টাল</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-gray-900 dark:text-white leading-tight tracking-tight">
              প্রাকৃতিক ও ক্লাসিকাল পদ্ধতিতে{' '}
              <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 bg-clip-text text-transparent">
                স্থায়ী আরোগ্যের
              </span>{' '}
              বিশ্বস্ত ঠিকানা
            </h1>

            <p className="text-base sm:text-lg text-gray-600 dark:text-gray-300 leading-relaxed font-normal">
              অভিজ্ঞ চিকিৎসকের তত্ত্বাবধানে পার্শ্বপ্রতিক্রিয়াহীন বিশুদ্ধ হোমিওপ্যাথিক চিকিৎসা। ঘরে বসেই অনলাইন অ্যাপয়েন্টমেন্ট বুকিং, ওষুধের হিস্ট্রি পর্যবেক্ষণ এবং জরুরি স্বাস্থ্য পরামর্শ গ্রহণের সহজ ব্যবস্থা।
            </p>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setIsBookingModalOpen(true)}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md shadow-emerald-700/25 hover:shadow-lg transition-all flex items-center space-x-2 text-sm sm:text-base group"
              >
                <Calendar className="w-5 h-5" />
                <span>অনলাইন অ্যাপয়েন্টমেন্ট বুকিং</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setIsChatbotOpen(true)}
                className="px-5 py-3.5 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/60 text-teal-800 dark:text-teal-200 font-bold rounded-xl border border-teal-200 dark:border-teal-800 transition flex items-center space-x-2 text-sm sm:text-base"
              >
                <Bot className="w-5 h-5 text-teal-600" />
                <span>জরুরি হোমিও চ্যাটবট</span>
              </button>
            </div>

            {/* Quick Benefits Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-gray-200 dark:border-gray-800 text-xs text-gray-600 dark:text-gray-400">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>১০০% প্রাকৃতিক ওষুধ</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>অনলাইন প্রেসক্রিপশন আর্কাইভ</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>অফলাইন মোড ও ডাটা সিঙ্ক</span>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Patient Portal Lookup Card */}
          <div className="lg:col-span-5">
            <div className="bg-white dark:bg-[#1f262b] rounded-2xl shadow-xl border border-gray-200 dark:border-gray-800 p-6 sm:p-7 relative overflow-hidden">
              
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

              <div className="flex items-center space-x-3 mb-5">
                <div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-950/80 flex items-center justify-center text-teal-600 dark:text-teal-400">
                  <FileSearch className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900 dark:text-white">
                    রোগী সেবা ও প্রেসক্রিপশন ট্র্যাকার
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    পূর্ববর্তী প্রেসক্রিপশন ও ওষুধের ইতিহাস অনুসন্ধান করুন
                  </p>
                </div>
              </div>

              {/* Quick Search Form */}
              <form onSubmit={handleQuickLookup} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5 flex items-center justify-between">
                    <span>রোগীর নাম, ঠিকানা, মোবাইল নম্বর অথবা প্রেসক্রিপশন কোড</span>
                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded">৪-ইন-১ অনুসন্ধান</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="যেমন: আনোয়ারুল, মিরপুর, ০১৭২১... অথবা RX-2026-881"
                      value={quickSearchInput}
                      onChange={(e) => setQuickSearchInput(e.target.value)}
                      className="w-full px-3.5 py-3 pl-10 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                    />
                    <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-bold rounded-xl shadow transition text-sm flex items-center justify-center space-x-2"
                >
                  <Search className="w-4 h-4" />
                  <span>প্রেসক্রিপশন ও ওষুধ ইতিহাস খুঁজুন</span>
                </button>
              </form>

              {/* Sample Quick Demo Buttons */}
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800 text-xs text-gray-500 dark:text-gray-400">
                <span className="font-medium text-gray-700 dark:text-gray-300">দ্রুত অনুসন্ধানের ডেমো অপশন:</span>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setQuickSearchInput('আনোয়ারুল হক');
                      setActiveLookupCodeOrPhone('আনোয়ারুল হক');
                      setIsPrescriptionLookupOpen(true);
                    }}
                    className="px-2 py-1 bg-gray-100 hover:bg-emerald-100 dark:bg-gray-800 dark:hover:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-md font-medium text-[11px]"
                    title="নাম দিয়ে খুঁজুন"
                  >
                    নাম: আনোয়ারুল
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickSearchInput('মিরপুর');
                      setActiveLookupCodeOrPhone('মিরপুর');
                      setIsPrescriptionLookupOpen(true);
                    }}
                    className="px-2 py-1 bg-gray-100 hover:bg-emerald-100 dark:bg-gray-800 dark:hover:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-md font-medium text-[11px]"
                    title="ঠিকানা দিয়ে খুঁজুন"
                  >
                    ঠিকানা: মিরপুর
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickSearchInput('০১৭২১-৪৫৫৬৬৭');
                      setActiveLookupCodeOrPhone('০১৭২১-৪৫৫৬৬৭');
                      setIsPrescriptionLookupOpen(true);
                    }}
                    className="px-2 py-1 bg-gray-100 hover:bg-emerald-100 dark:bg-gray-800 dark:hover:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-md font-mono text-[11px]"
                    title="মোবাইল নম্বর দিয়ে খুঁজুন"
                  >
                    মোবাইল: ০১৭২১...
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickSearchInput('RX-2026-881');
                      setActiveLookupCodeOrPhone('RX-2026-881');
                      setIsPrescriptionLookupOpen(true);
                    }}
                    className="px-2 py-1 bg-gray-100 hover:bg-emerald-100 dark:bg-gray-800 dark:hover:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-md font-mono text-[11px]"
                    title="প্রেসক্রিপশন কোড দিয়ে খুঁজুন"
                  >
                    কোড: RX-2026-881
                  </button>
                </div>
              </div>

              {/* Real-time Chamber Counter Widget */}
              <div className="mt-5 grid grid-cols-3 gap-2 bg-gray-50 dark:bg-[#161c20] p-3 rounded-xl border border-gray-200 dark:border-gray-800 text-center">
                <div>
                  <div className="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono">
                    {patients.length + 1250}
                  </div>
                  <div className="text-[10px] text-gray-500 dark:text-gray-400">মোট রোগী</div>
                </div>
                <div>
                  <div className="text-lg font-black text-teal-600 dark:text-teal-400 font-mono">
                    {prescriptions.length + 840}
                  </div>
                  <div className="text-[10px] text-gray-500 dark:text-gray-400">প্রেসক্রিপশন</div>
                </div>
                <div>
                  <div className="text-lg font-black text-amber-600 dark:text-amber-400 font-mono">
                    {appointments.filter((a) => a.status !== 'cancelled').length}
                  </div>
                  <div className="text-[10px] text-gray-500 dark:text-gray-400">আজকের শিডিউল</div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>

    </section>
  );
};
