import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { PatientReview } from '../types.ts';
import { Star, CheckCircle, PlusCircle, Edit3, Trash2, X, Sparkles } from 'lucide-react';

export const PatientReviews: React.FC = () => {
  const { reviews, addReview, updateReview, deleteReview, isMasterAuthenticated } = useClinic();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<PatientReview | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    condition: '',
    text: '',
    rating: 5,
    date: ''
  });

  const handleOpenAddModal = () => {
    setEditingReview(null);
    setFormData({
      name: '',
      location: '',
      condition: '',
      text: '',
      rating: 5,
      date: new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (rev: PatientReview) => {
    setEditingReview(rev);
    setFormData({
      name: rev.name,
      location: rev.location,
      condition: rev.condition,
      text: rev.text,
      rating: rev.rating || 5,
      date: rev.date
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.text.trim()) {
      return;
    }

    if (editingReview) {
      updateReview(editingReview.id, {
        name: formData.name.trim(),
        location: formData.location.trim() || 'ঢাকা',
        condition: formData.condition.trim() || 'ক্রনিক স্বাস্থ্য সমস্যা',
        text: formData.text.trim(),
        rating: Number(formData.rating) || 5,
        date: formData.date.trim() || new Date().toLocaleDateString('bn-BD')
      });
    } else {
      addReview({
        name: formData.name.trim(),
        location: formData.location.trim() || 'ঢাকা',
        condition: formData.condition.trim() || 'ক্রনিক স্বাস্থ্য সমস্যা',
        text: formData.text.trim(),
        rating: Number(formData.rating) || 5,
        date: formData.date.trim() || new Date().toLocaleDateString('bn-BD')
      });
    }

    setIsModalOpen(false);
    setEditingReview(null);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`আপনি কি নিশ্চিত যে "${name}"-এর রিভিউটি মুছে ফেলতে চান?`)) {
      deleteReview(id);
    }
  };

  return (
    <section id="reviews-section" className="py-16 bg-white dark:bg-[#161c20] transition-colors border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-2 bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 px-3.5 py-1 rounded-full text-xs font-semibold mb-3 shadow-xs">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>আরোগ্যপ্রাপ্ত রোগীদের অভিজ্ঞতা ও রেটিং</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
            রোগীদের সাফল্যগাথা ও সন্তুষ্টি
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-600 dark:text-gray-400">
            হাজারো দীর্ঘমেয়াদী ক্রনিক রোগীর আস্থা ও নির্ভরতার গল্প।
          </p>

          {/* Admin Control Bar when Logged In */}
          {isMasterAuthenticated && (
            <div className="mt-5 inline-flex items-center gap-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 px-4 py-2 rounded-xl text-xs text-emerald-900 dark:text-emerald-200 shadow-xs">
              <span className="flex items-center gap-1 font-semibold text-emerald-800 dark:text-emerald-300">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                এডমিন মোড সক্রিয়: আপনি রেটিং ও রিভিউ এডিট বা নতুন রিভিউ যোগ করতে পারেন
              </span>
              <button
                onClick={handleOpenAddModal}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition shadow-xs text-xs"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>নতুন রিভিউ যোগ করুন</span>
              </button>
            </div>
          )}
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-gray-50 dark:bg-[#1a2024] p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xs flex flex-col justify-between relative hover:border-emerald-400/50 transition duration-200 group"
            >
              <div>
                {/* Admin Quick Action Buttons (Only when logged in) */}
                {isMasterAuthenticated && (
                  <div className="flex items-center justify-end space-x-1.5 mb-2 pb-2 border-b border-gray-200 dark:border-gray-800/80">
                    <span className="text-[10px] text-gray-600 dark:text-gray-400 mr-auto font-mono">
                      আইডি: {rev.id}
                    </span>
                    <button
                      onClick={() => handleOpenEditModal(rev)}
                      className="px-2 py-1 text-[11px] font-semibold bg-white dark:bg-gray-800 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 rounded-md hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition flex items-center space-x-1"
                      title="রিভিউ ও রেটিং এডিট করুন"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>এডিট</span>
                    </button>
                    <button
                      onClick={() => handleDelete(rev.id, rev.name)}
                      className="px-2 py-1 text-[11px] font-semibold bg-white dark:bg-gray-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 rounded-md hover:bg-rose-50 dark:hover:bg-rose-950/40 transition flex items-center space-x-1"
                      title="রিভিউ মুছে ফেলুন"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>মুছুন</span>
                    </button>
                  </div>
                )}

                {/* Rating Stars */}
                <div className="flex items-center space-x-1 text-amber-400 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < (rev.rating || 5) ? 'fill-amber-400 text-amber-400' : 'text-gray-300 dark:text-gray-600'}`}
                    />
                  ))}
                  <span className="text-xs font-bold text-gray-700 dark:text-gray-300 ml-1">
                    {(rev.rating || 5).toFixed(1)}/৫.০
                  </span>
                </div>

                <div className="text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-md inline-block mb-3">
                  সমস্যা: {rev.condition}
                </div>

                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 leading-relaxed italic mb-4">
                  "{rev.text}"
                </p>
              </div>

              <div className="pt-4 border-t border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-gray-900 dark:text-white flex items-center space-x-1.5">
                    <span>{rev.name}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                  </div>
                  <div className="text-[11px] text-gray-500 dark:text-gray-400">
                    {rev.location}
                  </div>
                </div>
                <div className="text-[10px] text-gray-400 font-mono">
                  {rev.date}
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Empty state if all deleted */}
        {reviews.length === 0 && (
          <div className="text-center py-12 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-dashed border-gray-300 dark:border-gray-800">
            <p className="text-gray-500 dark:text-gray-400 text-sm">কোনো রিভিউ পাওয়া যায়নি।</p>
            {isMasterAuthenticated && (
              <button
                onClick={handleOpenAddModal}
                className="mt-3 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold"
              >
                প্রথম রিভিউ যোগ করুন
              </button>
            )}
          </div>
        )}

      </div>

      {/* Edit / Add Review Modal (Available to Logged-in Admin) */}
      {isModalOpen && isMasterAuthenticated && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 animate-in fade-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 rounded-lg text-emerald-600 dark:text-emerald-400">
                  <Star className="w-5 h-5 fill-emerald-600 dark:fill-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    {editingReview ? 'রোগী রিভিউ ও রেটিং সম্পাদনা' : 'নতুন রোগী রিভিউ যুক্ত করুন'}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    এডমিন প্যানেলে সংরক্ষিত হয়ে ওয়েবসাইটে প্রদর্শিত হবে
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              
              {/* Rating Selector */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  রেটিং নির্বাচন করুন (১ থেকে ৫ স্টার)
                </label>
                <div className="flex items-center space-x-2 bg-gray-50 dark:bg-gray-900 p-2.5 rounded-xl border border-gray-200 dark:border-gray-800">
                  {[1, 2, 3, 4, 5].map((starVal) => (
                    <button
                      type="button"
                      key={starVal}
                      onClick={() => setFormData({ ...formData, rating: starVal })}
                      className="p-1 hover:scale-110 transition-transform focus:outline-none"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          starVal <= formData.rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-gray-300 dark:text-gray-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 ml-2">
                    {formData.rating}.০ স্টার রেটিং
                  </span>
                </div>
              </div>

              {/* Patient Name */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রোগীর নাম *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="যেমন: মোঃ হারুনুর রশীদ"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    ঠিকানা / এলাকা
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="যেমন: উত্তরা সেক্টর ৭, ঢাকা"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    তারিখ
                  </label>
                  <input
                    type="text"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    placeholder="যেমন: ১২ অক্টোবর, ২০২৬"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Condition / Disease */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  সমস্যা বা রোগ
                </label>
                <input
                  type="text"
                  value={formData.condition}
                  onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                  placeholder="যেমন: ৩ বছরের ক্রনিক একজিমা ও শুষ্ক চর্মরোগ"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* Review Text */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  রোগীর অভিজ্ঞতা ও মন্তব্য *
                </label>
                <textarea
                  rows={3}
                  required
                  value={formData.text}
                  onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                  placeholder="রোগীর চিকিৎসার অভিজ্ঞতা ও ফলাফল বিস্তারিত লিখুন..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                >
                  <span>{editingReview ? 'হালনাগাদ সংরক্ষণ করুন' : 'রিভিউ যুক্ত করুন'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </section>
  );
};
