import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { HeaderNavMenuLink } from '../types.ts';
import {
  Phone,
  Clock,
  MapPin,
  Calendar,
  FileSearch,
  Bot,
  Menu,
  X,
  Shield,
  HeartPulse,
  BookOpen,
  Edit3,
  SlidersHorizontal,
  Check,
  Plus,
  Trash2,
  ExternalLink
} from 'lucide-react';

export const FrontendNavbar: React.FC = () => {
  const {
    settings,
    updateChamberSettings,
    isMasterAuthenticated,
    setIsBookingModalOpen,
    setIsPrescriptionLookupOpen,
    setIsChatbotOpen,
    setIsLoginModalOpen,
    setCurrentView,
    addAuditLog
  } = useClinic();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isHeaderEditOpen, setIsHeaderEditOpen] = useState(false);
  const [activeEditTab, setActiveEditTab] = useState<'info' | 'nav'>('info');

  const defaultNavLinks: HeaderNavMenuLink[] = [
    { id: 'h-1', label: 'ডাক্তারবৃন্দ', actionType: 'section', target: 'doctors', enabled: true },
    { id: 'h-2', label: 'অ্যাপয়েন্টমেন্ট', actionType: 'modal', target: 'booking', enabled: true },
    { id: 'h-3', label: 'প্রেসক্রিপশন ও ওষুধ', actionType: 'modal', target: 'lookup', enabled: true },
    { id: 'h-4', label: 'হোমিও নির্দেশিকা', actionType: 'section', target: 'materia-medica', enabled: true },
    { id: 'h-5', label: 'জরুরি পরামর্শক', actionType: 'modal', target: 'chatbot', enabled: true }
  ];

  // Header Edit Form State
  const [headerFormData, setHeaderFormData] = useState({
    chamberName: settings.chamberName,
    tagline: settings.tagline,
    headerBadgeText: settings.headerBadgeText || 'ওয়ার্ডপ্রেস থিম',
    address: settings.address,
    city: settings.city,
    visitingHours: settings.visitingHours,
    emergencyPhone: settings.emergencyPhone,
    phone: settings.phone,
    email: settings.email,
    noticeActive: settings.noticeActive,
    noticeText: settings.noticeText
  });

  const [navLinksData, setNavLinksData] = useState<HeaderNavMenuLink[]>(
    settings.headerNavLinks && settings.headerNavLinks.length > 0
      ? settings.headerNavLinks
      : defaultNavLinks
  );

  const [newNavLink, setNewNavLink] = useState<{ label: string; actionType: 'section' | 'modal' | 'external'; target: string }>({
    label: '',
    actionType: 'section',
    target: ''
  });

  const handleOpenHeaderEdit = () => {
    setHeaderFormData({
      chamberName: settings.chamberName,
      tagline: settings.tagline,
      headerBadgeText: settings.headerBadgeText || 'ওয়ার্ডপ্রেস থিম',
      address: settings.address,
      city: settings.city,
      visitingHours: settings.visitingHours,
      emergencyPhone: settings.emergencyPhone,
      phone: settings.phone,
      email: settings.email,
      noticeActive: settings.noticeActive,
      noticeText: settings.noticeText
    });
    setNavLinksData(
      settings.headerNavLinks && settings.headerNavLinks.length > 0
        ? settings.headerNavLinks
        : defaultNavLinks
    );
    setActiveEditTab('info');
    setIsHeaderEditOpen(true);
  };

  const handleSaveHeader = (e: React.FormEvent) => {
    e.preventDefault();
    updateChamberSettings({
      chamberName: headerFormData.chamberName.trim() || settings.chamberName,
      tagline: headerFormData.tagline.trim(),
      headerBadgeText: headerFormData.headerBadgeText.trim() || 'ওয়ার্ডপ্রেস থিম',
      address: headerFormData.address.trim(),
      city: headerFormData.city.trim(),
      visitingHours: headerFormData.visitingHours.trim(),
      emergencyPhone: headerFormData.emergencyPhone.trim(),
      phone: headerFormData.phone.trim(),
      email: headerFormData.email.trim(),
      noticeActive: headerFormData.noticeActive,
      noticeText: headerFormData.noticeText.trim(),
      headerNavLinks: navLinksData
    });
    addAuditLog('হেডার অপশন আপডেট', 'অ্যাডমিন কর্তৃক হেডারের সকল তথ্য, ব্যানার ও মেনু লিংকসমূহ সফলভাবে আপডেট করা হয়েছে।', 'info');
    setIsHeaderEditOpen(false);
  };

  const handleToggleNavLink = (id: string) => {
    setNavLinksData(prev => prev.map(l => l.id === id ? { ...l, enabled: !l.enabled } : l));
  };

  const handleRemoveNavLink = (id: string) => {
    setNavLinksData(prev => prev.filter(l => l.id !== id));
  };

  const handleAddNavLink = () => {
    if (!newNavLink.label.trim() || !newNavLink.target.trim()) return;
    const newId = `h-${Date.now()}`;
    setNavLinksData(prev => [
      ...prev,
      {
        id: newId,
        label: newNavLink.label.trim(),
        actionType: newNavLink.actionType,
        target: newNavLink.target.trim(),
        enabled: true
      }
    ]);
    setNewNavLink({ label: '', actionType: 'section', target: '' });
  };

  const handleNavClick = (link: HeaderNavMenuLink) => {
    if (link.actionType === 'section') {
      const cleanTarget = link.target.replace(/^#/, '');
      scrollToSection(cleanTarget);
    } else if (link.actionType === 'modal') {
      if (link.target === 'booking') setIsBookingModalOpen(true);
      else if (link.target === 'lookup') setIsPrescriptionLookupOpen(true);
      else if (link.target === 'chatbot') setIsChatbotOpen(true);
      else scrollToSection(link.target);
    } else if (link.actionType === 'external') {
      window.open(link.target, '_blank');
    }
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="w-full bg-white dark:bg-[#1a1f24] border-b border-gray-200 dark:border-gray-800 transition-colors">
      
      {/* Top Notification / Hotline Strip */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-1.5">
          <div className="flex items-center space-x-4 flex-wrap justify-center">
            <span className="flex items-center space-x-1.5 text-emerald-100">
              <Clock className="w-3.5 h-3.5 text-emerald-300" />
              <span>{settings.visitingHours}</span>
            </span>
            <span className="hidden sm:flex items-center space-x-1.5 text-emerald-100">
              <MapPin className="w-3.5 h-3.5 text-emerald-300" />
              <span>{settings.address}</span>
            </span>
          </div>

          <div className="flex items-center space-x-3">
            {/* Header Edit Button when Admin Logged In */}
            {isMasterAuthenticated && (
              <button
                onClick={handleOpenHeaderEdit}
                className="flex items-center space-x-1 font-semibold text-emerald-200 hover:text-white bg-black/30 hover:bg-black/50 border border-emerald-400/40 px-2 py-0.5 rounded transition text-[11px] shadow-xs"
                title="হেডার তথ্য ও জরুরি ঘোষণা এডিট করুন"
              >
                <Edit3 className="w-3 h-3 text-emerald-300" />
                <span>হেডার এডিট</span>
              </button>
            )}

            <a
              href={`tel:${settings.emergencyPhone}`}
              className="flex items-center space-x-1 font-semibold text-amber-300 hover:text-white transition bg-black/20 px-2 py-0.5 rounded"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>জরুরি হটলাইন: {settings.emergencyPhone}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Chamber Header */}
      <div className="max-w-7xl mx-auto px-4 py-3.5">
        <div className="flex items-center justify-between">
          
          {/* Logo & Brand */}
          <div
            onClick={() => scrollToSection('hero')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
              <HeartPulse className="w-6 h-6 text-emerald-100" />
            </div>
            <div>
              <div className="font-extrabold text-xl text-gray-900 dark:text-white tracking-tight flex items-center gap-1.5 font-sans">
                {settings.chamberName}
                <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-1.5 py-0.5 rounded font-medium">
                  {settings.headerBadgeText || 'ওয়ার্ডপ্রেস থিম'}
                </span>
                {isMasterAuthenticated && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenHeaderEdit();
                    }}
                    className="p-1 text-gray-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
                    title="চেম্বারের নাম, ট্যাগলাইন ও হেডার অপশন এডিট করুন"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">
                {settings.tagline}
              </div>
            </div>
          </div>

          {/* Desktop Navigation Links (Dynamic from settings.headerNavLinks) */}
          <nav className="hidden lg:flex items-center space-x-5 text-sm font-medium text-gray-700 dark:text-gray-200">
            {(settings.headerNavLinks && settings.headerNavLinks.length > 0 ? settings.headerNavLinks : defaultNavLinks)
              .filter(link => link.enabled !== false)
              .map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link)}
                  className={`transition flex items-center space-x-1.5 ${
                    link.actionType === 'modal' && link.target === 'chatbot'
                      ? 'text-teal-700 dark:text-teal-300 font-semibold bg-teal-50 dark:bg-teal-950/60 px-2.5 py-1 rounded-full border border-teal-200 dark:border-teal-800 hover:bg-teal-100'
                      : 'hover:text-emerald-600 dark:hover:text-emerald-400'
                  }`}
                >
                  {link.actionType === 'modal' && link.target === 'booking' && <Calendar className="w-4 h-4 text-emerald-600" />}
                  {link.actionType === 'modal' && link.target === 'lookup' && <FileSearch className="w-4 h-4 text-teal-600" />}
                  {link.actionType === 'modal' && link.target === 'chatbot' && <Bot className="w-4 h-4 text-teal-600 animate-pulse" />}
                  {link.target === 'materia-medica' && <BookOpen className="w-4 h-4 text-indigo-500" />}
                  <span>{link.label}</span>
                </button>
              ))}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center space-x-2.5">
            <button
              onClick={() => setIsPrescriptionLookupOpen(true)}
              className="px-3 py-2 text-xs font-semibold text-gray-700 dark:text-gray-200 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition flex items-center space-x-1.5"
            >
              <FileSearch className="w-3.5 h-3.5 text-teal-600" />
              <span>প্রেসক্রিপশন চেক</span>
            </button>

            <button
              onClick={() => setIsBookingModalOpen(true)}
              className="px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-lg shadow-sm shadow-emerald-700/20 hover:shadow-md transition flex items-center space-x-1.5"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>বুকিং নিন</span>
            </button>

            {isMasterAuthenticated ? (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={handleOpenHeaderEdit}
                  className="px-2.5 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900 border border-emerald-300 dark:border-emerald-800 rounded-lg transition flex items-center space-x-1"
                  title="হেডারের সব অপশন ও মেনু এডিট করুন"
                >
                  <Edit3 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>হেডার এডিট</span>
                </button>
                <button
                  onClick={() => setCurrentView('wp-admin')}
                  className="px-3 py-2 text-xs font-bold text-white bg-[#1d2327] hover:bg-[#2c3338] rounded-lg border border-gray-700 transition flex items-center space-x-1"
                  title="ওয়ার্ডপ্রেস এডমিন প্যানেল"
                >
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                  <span>এডমিন</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="p-2 text-gray-400 hover:text-gray-700 dark:hover:text-white rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                title="ওয়ার্ডপ্রেস এডমিন প্রবেশ"
              >
                <Shield className="w-4 h-4 text-gray-400" />
              </button>
            )}
          </div>

          {/* Mobile Menu Hamburger */}
          <div className="flex items-center lg:hidden space-x-2">
            <button
              onClick={() => setIsBookingModalOpen(true)}
              className="px-2.5 py-1.5 text-xs font-bold text-white bg-emerald-600 rounded-md"
            >
              বুকিং
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

        {/* Mobile Menu Dropdown (Dynamic Links) */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 pt-3 border-t border-gray-200 dark:border-gray-800 space-y-2 text-sm">
            {isMasterAuthenticated && (
              <button
                onClick={() => {
                  handleOpenHeaderEdit();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 font-semibold flex items-center justify-between border border-emerald-300 dark:border-emerald-800"
              >
                <span>হেডারের সকল অপশন ও মেনু এডিট</span>
                <Edit3 className="w-4 h-4 text-emerald-600" />
              </button>
            )}
            
            {(settings.headerNavLinks && settings.headerNavLinks.length > 0 ? settings.headerNavLinks : defaultNavLinks)
              .filter(link => link.enabled !== false)
              .map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    handleNavClick(link);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 flex items-center justify-between font-medium"
                >
                  <span>{link.label}</span>
                  {link.actionType === 'modal' && link.target === 'booking' && <Calendar className="w-4 h-4 text-emerald-600" />}
                  {link.actionType === 'modal' && link.target === 'lookup' && <FileSearch className="w-4 h-4 text-teal-600" />}
                  {link.actionType === 'modal' && link.target === 'chatbot' && <Bot className="w-4 h-4 text-teal-600" />}
                  {link.actionType === 'external' && <ExternalLink className="w-4 h-4 text-gray-400" />}
                </button>
              ))}

            <button
              onClick={() => {
                if (isMasterAuthenticated) {
                  setCurrentView('wp-admin');
                } else {
                  setIsLoginModalOpen(true);
                }
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-semibold flex items-center justify-between"
            >
              <span>{isMasterAuthenticated ? 'ওয়ার্ডপ্রেস এডমিন প্যানেল' : 'এডমিন লগইন (মাস্টার কোড)'}</span>
              <Shield className="w-4 h-4 text-emerald-500" />
            </button>
          </div>
        )}

      </div>

      {/* Header Edit Modal (Available when Admin is Logged In) */}
      {isHeaderEditOpen && isMasterAuthenticated && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 rounded-lg text-emerald-600 dark:text-emerald-400">
                  <SlidersHorizontal className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    হেডার অপশন ও মেনু সম্পাদনা
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    হেডারের সকল তথ্য, ব্যানার, ব্যাজ এবং নেভিগেশন মেনু লিংক কাস্টমাইজ করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsHeaderEditOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex items-center gap-2 mt-4 border-b border-gray-200 dark:border-gray-800 pb-2">
              <button
                type="button"
                onClick={() => setActiveEditTab('info')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  activeEditTab === 'info'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200'
                }`}
              >
                ১. মৌলিক তথ্য ও নোটিশ
              </button>
              <button
                type="button"
                onClick={() => setActiveEditTab('nav')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  activeEditTab === 'nav'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200'
                }`}
              >
                ২. হেডার মেনু লিংক ও ব্যাজ ({navLinksData.length})
              </button>
            </div>

            <form onSubmit={handleSaveHeader} className="mt-4 space-y-4">
              
              {activeEditTab === 'info' && (
                <div className="space-y-4">
                  {/* Chamber Name & Tagline */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের পূর্ণ নাম *
                      </label>
                      <input
                        type="text"
                        required
                        value={headerFormData.chamberName}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, chamberName: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের ট্যাগলাইন / স্লোগান
                      </label>
                      <input
                        type="text"
                        value={headerFormData.tagline}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, tagline: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        হেডার ব্যাজ লেখা (নামের পাশে)
                      </label>
                      <input
                        type="text"
                        value={headerFormData.headerBadgeText}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, headerBadgeText: e.target.value })}
                        placeholder="যেমন: ওয়ার্ডপ্রেস থিম / ডিজিটাল হোমিও"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  {/* Address and City */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের ঠিকানা
                      </label>
                      <input
                        type="text"
                        value={headerFormData.address}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, address: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        শহর
                      </label>
                      <input
                        type="text"
                        value={headerFormData.city}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, city: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  {/* Visiting Hours */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      সাক্ষাতের সময়সূচী (হেডারের শীর্ষে প্রদর্শিত)
                    </label>
                    <input
                      type="text"
                      value={headerFormData.visitingHours}
                      onChange={(e) => setHeaderFormData({ ...headerFormData, visitingHours: e.target.value })}
                      placeholder="যেমন: শনি থেকে বৃহস্পতি: সকাল ১০:০০ - দুপুর ১:০০ এবং বিকাল ৫:০০ - রাত ১০:০০"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  {/* Phones & Hotline */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        জরুরি হটলাইন নম্বর (টপবার) *
                      </label>
                      <input
                        type="text"
                        required
                        value={headerFormData.emergencyPhone}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, emergencyPhone: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের সাধারণ ফোন নম্বর
                      </label>
                      <input
                        type="text"
                        value={headerFormData.phone}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, phone: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      অফিসিয়াল ইমেইল
                    </label>
                    <input
                      type="email"
                      value={headerFormData.email}
                      onChange={(e) => setHeaderFormData({ ...headerFormData, email: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  {/* Notice Toggle & Text */}
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-amber-900 dark:text-amber-200 cursor-pointer flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={headerFormData.noticeActive}
                          onChange={(e) => setHeaderFormData({ ...headerFormData, noticeActive: e.target.checked })}
                          className="rounded border-amber-400 text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                        />
                        <span>জরুরি ঘোষণা / নোটিশ সক্রিয় রাখুন</span>
                      </label>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${headerFormData.noticeActive ? 'bg-emerald-600 text-white' : 'bg-gray-300 text-gray-700 dark:bg-gray-700 dark:text-gray-300'}`}>
                        {headerFormData.noticeActive ? 'সক্রিয়' : 'বন্ধ'}
                      </span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-gray-700 dark:text-gray-300 mb-1">
                        ঘোষণা / নোটিশ বার্তা:
                      </label>
                      <textarea
                        rows={2}
                        value={headerFormData.noticeText}
                        onChange={(e) => setHeaderFormData({ ...headerFormData, noticeText: e.target.value })}
                        placeholder="যেমন: আগামী শুক্রবার চেম্বার বন্ধ থাকবে..."
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-amber-300 dark:border-amber-800 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeEditTab === 'nav' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-gray-700 dark:text-gray-300">
                      হেডারের নেভিগেশন লিংকসমূহ (নাম ও লক্ষ্য পরিবর্তন করুন):
                    </p>
                    <span className="text-[11px] text-gray-500">মোট: {navLinksData.length} টি</span>
                  </div>

                  <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
                    {navLinksData.map((link) => (
                      <div
                        key={link.id}
                        className={`p-3 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 ${
                          link.enabled ? 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700' : 'bg-gray-50 dark:bg-gray-950 opacity-60 border-dashed border-gray-300'
                        }`}
                      >
                        <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2 w-full">
                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">লেবেল (নাম):</label>
                            <input
                              type="text"
                              value={link.label}
                              onChange={(e) => {
                                const val = e.target.value;
                                setNavLinksData(prev => prev.map(l => l.id === link.id ? { ...l, label: val } : l));
                              }}
                              className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">টাইপ:</label>
                            <select
                              value={link.actionType}
                              onChange={(e) => {
                                const val = e.target.value as 'section' | 'modal' | 'external';
                                setNavLinksData(prev => prev.map(l => l.id === link.id ? { ...l, actionType: val } : l));
                              }}
                              className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                            >
                              <option value="section">সেকশন স্ক্রল (Section)</option>
                              <option value="modal">মডাল পপআপ (Modal)</option>
                              <option value="external">বহিরাগত লিংক (URL)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">টার্গেট / আইডি:</label>
                            <input
                              type="text"
                              value={link.target}
                              onChange={(e) => {
                                const val = e.target.value;
                                setNavLinksData(prev => prev.map(l => l.id === link.id ? { ...l, target: val } : l));
                              }}
                              placeholder="doctors, booking, lookup..."
                              className="w-full px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                            />
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 self-end sm:self-center">
                          <button
                            type="button"
                            onClick={() => handleToggleNavLink(link.id)}
                            className={`px-2 py-1 rounded text-[11px] font-bold ${
                              link.enabled ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-gray-200 text-gray-600'
                            }`}
                          >
                            {link.enabled ? 'সক্রিয়' : 'বন্ধ'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveNavLink(link.id)}
                            className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add New Link Box */}
                  <div className="p-3 bg-gray-50 dark:bg-gray-900/60 rounded-xl border border-gray-200 dark:border-gray-800 space-y-2">
                    <p className="text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1">
                      <Plus className="w-3.5 h-3.5 text-emerald-600" />
                      নতুন মেনু লিংক যুক্ত করুন:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        placeholder="মেনুর নাম (যেমন: রিভিউ)"
                        value={newNavLink.label}
                        onChange={(e) => setNewNavLink({ ...newNavLink, label: e.target.value })}
                        className="px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                      />
                      <select
                        value={newNavLink.actionType}
                        onChange={(e) => setNewNavLink({ ...newNavLink, actionType: e.target.value as any })}
                        className="px-2 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                      >
                        <option value="section">সেকশন স্ক্রল</option>
                        <option value="modal">মডাল পপআপ</option>
                        <option value="external">বহিরাগত লিংক</option>
                      </select>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          placeholder="আইডি বা লিঙ্ক (যেমন: reviews)"
                          value={newNavLink.target}
                          onChange={(e) => setNewNavLink({ ...newNavLink, target: e.target.value })}
                          className="flex-1 px-2.5 py-1 text-xs border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={handleAddNavLink}
                          className="px-3 py-1 bg-emerald-600 text-white rounded text-xs font-bold hover:bg-emerald-700 shrink-0"
                        >
                          যোগ
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-gray-200 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setIsHeaderEditOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>হেডারের সকল তথ্য সংরক্ষণ করুন</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
