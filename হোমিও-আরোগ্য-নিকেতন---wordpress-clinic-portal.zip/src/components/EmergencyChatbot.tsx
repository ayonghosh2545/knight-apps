import React, { useState, useRef, useEffect } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Bot,
  X,
  Send,
  Calendar,
  RefreshCw,
  Edit2
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export const EmergencyChatbot: React.FC = () => {
  const { 
    isChatbotOpen, 
    setIsChatbotOpen, 
    setIsBookingModalOpen, 
    settings, 
    isMasterAuthenticated,
    setCurrentView,
    setAdminSubTab 
  } = useClinic();

  const botConfig = settings.chatbotConfig;
  const botName = botConfig?.botName || 'জরুরি হোমিও পরামর্শক';
  const botSubtitle = botConfig?.botSubtitle || 'ক্লাসিকাল মেটেরিয়া মেডিকা ভিত্তিক এআই সহকারী';
  const welcomeText = botConfig?.welcomeMessage || 'আসসালামু আলাইকুম! আমি হোমিও আরোগ্য নিকেতনের জরুরি স্বাস্থ্য পরামর্শক এআই সহকারী। আপনার শারীরিক সমস্যা বা চেম্বার সংক্রান্ত যেকোনো প্রশ্ন করতে পারেন।';
  const quickPrompts = botConfig?.quickPrompts && botConfig.quickPrompts.length > 0
    ? botConfig.quickPrompts
    : [
        'হঠাৎ উচ্চ জ্বর ও শীতবোধ',
        'তীব্র গ্যাস, বুকজ্বালা ও অম্ল ঢেকুর',
        'পড়ে গিয়ে শরীরে ভোঁতা আঘাত ও ব্যথা',
        'চেম্বার খোলা ও ভিজিটিং সময়'
      ];
  const disclaimerText = botConfig?.disclaimerText || '⚠️ এটি প্রাথমিক দিকনির্দেশনা। সংকটজনক অবস্থায় দ্রুত চেম্বারে আসুন।';
  const bookingCtaText = botConfig?.bookingCtaText || 'সিরিয়াল নিন';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'bot',
      text: welcomeText,
      timestamp: 'এখন'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isChatbotOpen) {
      scrollToBottom();
    }
  }, [messages, isChatbotOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    // 1. Check custom Q&A rules configured by admin
    const lower = query.toLowerCase();
    const customRules = botConfig?.customQnA || [];
    const matchedRule = customRules.find(q => {
      if (q.enabled === false) return false;
      const terms = q.keyword.toLowerCase().split(/[|,]/).map(t => t.trim()).filter(Boolean);
      return terms.some(t => lower.includes(t));
    });

    if (matchedRule) {
      // Simulate slight delay for realistic natural response
      setTimeout(() => {
        const botMsg: ChatMessage = {
          id: 'msg-bot-' + Date.now(),
          sender: 'bot',
          text: matchedRule.answer,
          timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, botMsg]);
        setIsLoading(false);
      }, 400);
      return;
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query })
      });

      if (!response.ok) throw new Error('Network error');
      const data = await response.json();

      const botMsg: ChatMessage = {
        id: 'msg-bot-' + Date.now(),
        sender: 'bot',
        text: data.reply || 'দুঃখিত, কোনো উত্তর পাওয়া যায়নি।',
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      // Local fallback in case network call fails
      const botMsg: ChatMessage = {
        id: 'msg-bot-' + Date.now(),
        sender: 'bot',
        text: `🌿 **হোমিও প্রাথমিক পরামর্শ:**\nআপনার লক্ষণের প্রেক্ষিতে বিশ্রামে থাকুন এবং প্রচুর পানি পান করুন। আকস্মিক তীব্র লক্ষণে Aconite 30CH অথবা আঘাতের ক্ষেত্রে Arnica 200CH প্রাথমিক নির্দেশনা হিসেবে মেটেরিয়া মেডিকায় উল্লেখ আছে। স্থায়ী চিকিৎসার জন্য অনুগ্রহ করে চেম্বারে সরাসরি অ্যাপয়েন্টমেন্ট নিন।`,
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // If chatbot is disabled by admin and user is NOT master admin, don't show launcher
  if (botConfig?.botEnabled === false && !isMasterAuthenticated) {
    return null;
  }

  if (!isChatbotOpen) {
    return (
      /* Floating launcher button */
      <button
        onClick={() => setIsChatbotOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-3.5 rounded-full shadow-2xl hover:scale-105 transition-all flex items-center space-x-2 group border-2 border-white/40"
        title="জরুরি হোমিওপ্যাথিক পরামর্শক চ্যাটবট"
      >
        <Bot className="w-6 h-6 animate-bounce" />
        <span className="hidden sm:inline font-bold text-xs pr-1">{botName}</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 sm:bottom-6 right-4 sm:right-6 z-50 w-[94vw] sm:w-[430px] max-h-[85vh] h-[600px] bg-white dark:bg-[#1a2024] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
      
      {/* Chatbot Header */}
      <div className="bg-gradient-to-r from-teal-800 via-emerald-800 to-teal-900 text-white p-4 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
            <Bot className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <h4 className="font-bold text-sm flex items-center gap-1.5">
              {botName}
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </h4>
            <p className="text-[10px] text-emerald-200">
              {botSubtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Admin Direct Edit Button when Logged In */}
          {isMasterAuthenticated && (
            <button
              onClick={() => {
                setIsChatbotOpen(false);
                setCurrentView('wp-admin');
                setAdminSubTab('chatbot');
              }}
              className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-lg text-[11px] font-bold flex items-center gap-1 shadow transition"
              title="চ্যাটবট এডিট করুন (Admin)"
            >
              <Edit2 className="w-3 h-3" />
              <span>এডিট</span>
            </button>
          )}

          <button
            onClick={() => setIsChatbotOpen(false)}
            className="p-1 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-gray-50/50 dark:bg-[#151a1e]">
        
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-3 leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-emerald-600 text-white rounded-br-xs'
                  : 'bg-white dark:bg-[#20272c] text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-700 rounded-bl-xs shadow-xs'
              }`}
            >
              <div className="whitespace-pre-line">{m.text}</div>

              {/* Bot Appointment CTA if advice is given */}
              {m.sender === 'bot' && m.id !== 'msg-welcome' && (
                <div className="mt-2.5 pt-2 border-t border-gray-100 dark:border-gray-700/60 flex items-center justify-between">
                  <span className="text-[10px] text-gray-500 dark:text-gray-400">
                    চেম্বারে দেখাতে চান?
                  </span>
                  <button
                    onClick={() => {
                      setIsChatbotOpen(false);
                      setIsBookingModalOpen(true);
                    }}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-300 rounded font-bold text-[10px] flex items-center space-x-1"
                  >
                    <Calendar className="w-3 h-3" />
                    <span>{bookingCtaText}</span>
                  </button>
                </div>
              )}
            </div>
            <span className="text-[9px] text-gray-400 mt-0.5 px-1">{m.timestamp}</span>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center space-x-2 text-gray-400 text-xs p-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-500" />
            <span>হোমিওপ্যাথিক মেটেরিয়া মেডিকা বিশ্লেষণ করা হচ্ছে...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Chips */}
      <div className="p-2 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-[#1a2024] shrink-0">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full shrink-0 transition"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input Field */}
      <div className="p-3 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-[#1a2024] shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            placeholder="আপনার সমস্যা লিখুন (যেমন: পেট ফাঁপা ও গ্যাস)..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            disabled={isLoading}
            className="flex-1 px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim() || isLoading}
            className="p-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
        <p className="text-[9px] text-gray-400 dark:text-gray-500 text-center mt-1.5">
          {disclaimerText}
        </p>
      </div>

    </div>
  );
};
