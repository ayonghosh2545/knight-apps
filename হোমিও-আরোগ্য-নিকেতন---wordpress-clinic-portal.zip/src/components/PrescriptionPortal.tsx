import React, { useState, useEffect } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { Prescription } from '../types.ts';
import { verifyMasterSecurityCode } from '../utils/crypto.ts';
import {
  FileSearch,
  Search,
  Printer,
  Calendar,
  User,
  Phone,
  ShieldCheck,
  AlertTriangle,
  HeartPulse,
  Clock,
  Pill,
  X,
  Download,
  Share2,
  CheckCircle2,
  UtensilsCrossed,
  FileText,
  Lock,
  Unlock,
  KeyRound,
  Eye,
  EyeOff,
  Info,
  Edit2,
  Trash2,
  Camera,
  Image,
  Maximize2
} from 'lucide-react';

export const PrescriptionPortal: React.FC = () => {
  const {
    prescriptions,
    patients,
    settings,
    adminProfile,
    isMasterAuthenticated,
    logAction,
    isPrescriptionLookupOpen,
    setIsPrescriptionLookupOpen,
    activeLookupCodeOrPhone,
    setActiveLookupCodeOrPhone,
    selectedPrescriptionForView,
    setSelectedPrescriptionForView,
    deletePrescription,
    setCurrentView,
    setAdminSubTab
  } = useClinic();

  const [searchQuery, setSearchQuery] = useState(activeLookupCodeOrPhone || '');
  const [searchResults, setSearchResults] = useState<Prescription[]>([]);
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  // Master Security Code state for logged-out medicine view
  const [isMedicinesUnlocked, setIsMedicinesUnlocked] = useState(false);
  const [securityCodeInput, setSecurityCodeInput] = useState('');
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [securityError, setSecurityError] = useState('');

  // Prescription Photo Zoom Preview Modal State
  const [modalImagePreview, setModalImagePreview] = useState<string | null>(null);

  useEffect(() => {
    if (activeLookupCodeOrPhone) {
      setSearchQuery(activeLookupCodeOrPhone);
      performSearch(activeLookupCodeOrPhone);
    }
  }, [activeLookupCodeOrPhone]);

  const performSearch = (query: string) => {
    const q = query.trim().toLowerCase();
    if (!q) {
      setSearchResults([]);
      return;
    }

    // Cross-match matching patients by Name, Address, or Mobile
    const matchingPatientPhones = patients
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.address.toLowerCase().includes(q) ||
          p.phone.includes(q)
      )
      .map((p) => p.phone);

    const matches = prescriptions.filter(
      (rx) =>
        rx.prescriptionCode.toLowerCase().includes(q) ||
        rx.patientName.toLowerCase().includes(q) ||
        (rx.patientAddress && rx.patientAddress.toLowerCase().includes(q)) ||
        (rx.registerPageNo && rx.registerPageNo.toLowerCase().includes(q)) ||
        rx.patientPhone.replace(/\D/g, '').includes(q.replace(/\D/g, '')) ||
        rx.patientPhone.includes(q) ||
        matchingPatientPhones.includes(rx.patientPhone)
    );

    setSearchResults(matches);
    if (matches.length > 0) {
      setSelectedPrescriptionForView(matches[0]);
    }
  };

  const canViewMedicines = isMasterAuthenticated || isMedicinesUnlocked;

  const handleUnlockMedicines = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError('');
    if (!securityCodeInput.trim()) {
      setSecurityError('অনুগ্রহ করে চেম্বারের মাস্টার সিকিউরিটি কোড লিখুন।');
      return;
    }

    const isValid = verifyMasterSecurityCode(securityCodeInput, adminProfile.masterSecurityCode);
    if (isValid) {
      setIsMedicinesUnlocked(true);
      setSecurityError('');
      if (logAction) {
        logAction(
          'প্রেসক্রিপশন ওষুধ আনলক',
          `প্রেসক্রিপশন কোড: ${selectedPrescriptionForView?.prescriptionCode || searchResults[0]?.prescriptionCode || 'অজ্ঞাত'} এর ওষুধ তালিকা মাস্টার কোড দিয়ে সফলভাবে আনলক করা হয়েছে।`,
          'security'
        );
      }
    } else {
      setSecurityError('ভুল মাস্টার সিকিউরিটি কোড! সঠিক অনুমোদিত কোডটি প্রদান করুন।');
      if (logAction) {
        logAction(
          'ব্যর্থ ওষুধ আনলক চেষ্টা',
          `প্রেসক্রিপশন এর ওষুধ দেখতে ভুল মাস্টার সিকিউরিটি কোড প্রবেশ করানো হয়েছে।`,
          'warning'
        );
      }
    }
  };

  const handleLockMedicines = () => {
    setIsMedicinesUnlocked(false);
    setSecurityCodeInput('');
    setSecurityError('');
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(searchQuery);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isPrescriptionLookupOpen && !selectedPrescriptionForView) {
    return null;
  }

  const currentRx = selectedPrescriptionForView || searchResults[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-4xl w-full shadow-2xl border border-gray-200 dark:border-gray-800 my-6 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header (No-print) */}
        <div className="bg-[#1d2327] text-white px-6 py-3.5 flex items-center justify-between no-print shrink-0 border-b border-gray-700">
          <div className="flex items-center space-x-2.5">
            <FileSearch className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                অনলাইন প্রেসক্রিপশন ও ওষুধ ইতিহাস পোর্টাল
              </h3>
              <p className="text-[11px] text-gray-400">
                রোগীর নাম, ঠিকানা, মোবাইল নম্বর অথবা প্রেসক্রিপশন কোড দিয়ে সহজেই খুঁজুন
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsPrescriptionLookupOpen(false);
              setSelectedPrescriptionForView(null);
            }}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar Strip (No-print) */}
        <div className="bg-gray-50 dark:bg-[#161c20] p-4 border-b border-gray-200 dark:border-gray-800 no-print shrink-0 space-y-2.5">
          <form onSubmit={handleSearchSubmit} className="flex gap-2 max-w-3xl mx-auto">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="রোগীর নাম, ঠিকানা, মোবাইল নম্বর অথবা প্রেসক্রিপশন কোড (যেমন: আনোয়ারুল, মিরপুর, ০১৭১২... বা RX-2026-881)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1a2024] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl transition flex items-center space-x-1.5 shadow-xs"
            >
              <span>অনুসন্ধান</span>
            </button>
          </form>

          {/* Quick Filter Tag Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400">
            <span className="font-semibold text-gray-700 dark:text-gray-300">দ্রুত খুঁজুন:</span>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('আনোয়ারুল হক');
                performSearch('আনোয়ারুল হক');
              }}
              className="px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300"
            >
              নাম: আনোয়ারুল
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('মিরপুর');
                performSearch('মিরপুর');
              }}
              className="px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300"
            >
              ঠিকানা: মিরপুর
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('০১৭২১-৪৫৫৬৬৭');
                performSearch('০১৭২১-৪৫৫৬৬৭');
              }}
              className="px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono"
            >
              মোবাইল: ০১৭২১...
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('RX-2026-881');
                performSearch('RX-2026-881');
              }}
              className="px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono"
            >
              কোড: RX-2026-881
            </button>
          </div>

          {/* If multiple prescriptions found */}
          {searchResults.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto mt-3 pt-2 border-t border-gray-200 dark:border-gray-700 text-xs">
              <span className="text-gray-500 dark:text-gray-400 shrink-0 font-medium">পূর্ববর্তী প্রেসক্রিপশন সমূহ:</span>
              {searchResults.map((rx) => (
                <button
                  key={rx.id}
                  onClick={() => setSelectedPrescriptionForView(rx)}
                  className={`px-3 py-1 rounded-lg font-mono shrink-0 transition ${
                    currentRx?.id === rx.id
                      ? 'bg-emerald-600 text-white font-bold shadow-xs'
                      : 'bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-300'
                  }`}
                >
                  {rx.prescriptionCode} ({rx.date})
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {currentRx ? (
            /* Digital Homeopathic Prescription Document */
            <div
              id="printable-prescription"
              className="bg-white text-gray-900 rounded-xl p-6 sm:p-8 border border-gray-300 shadow-md font-sans max-w-3xl mx-auto"
            >
              
              {/* Prescription Header */}
              <div className="border-b-2 border-emerald-800 pb-4 mb-4">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-bold text-xl">
                      হো
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-emerald-900 tracking-tight">
                        {settings.chamberName}
                      </h2>
                      <div className="text-xs text-gray-600 font-medium">
                        {settings.tagline}
                      </div>
                      <div className="text-[11px] text-gray-500 mt-0.5">
                        {settings.address} | হটলাইন: {settings.phone}
                      </div>
                    </div>
                  </div>

                  <div className="text-right sm:text-right border-t sm:border-t-0 pt-2 sm:pt-0 w-full sm:w-auto">
                    <div className="font-bold text-base text-gray-900">
                      {currentRx.doctorName}
                    </div>
                    <div className="text-xs text-emerald-800 font-medium max-w-xs leading-tight">
                      {currentRx.doctorQualification}
                    </div>
                    <div className="text-[11px] text-gray-500 mt-1 font-mono">
                      চেম্বার রেজিস্টার নং: REG-BD-HOMEO-2026
                    </div>
                  </div>
                </div>
              </div>

              {/* Patient Meta Data Bar */}
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 grid grid-cols-2 sm:grid-cols-4 gap-3.5 text-xs mb-6">
                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">রোগীর পূর্ণ নাম:</span>
                  <span className="font-bold text-gray-900 text-sm">
                    {currentRx.patientName}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">রোগীর ঠিকানা:</span>
                  <span className="font-semibold text-gray-800 text-xs">
                    {currentRx.patientAddress || 'মিরপুর-১০, ঢাকা'}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">মোবাইল নম্বর:</span>
                  <span className="font-bold text-gray-900 text-xs font-mono">
                    {currentRx.patientPhone}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">প্রেসক্রিপশন কোড:</span>
                  <span className="font-bold text-emerald-700 text-sm font-mono">
                    {currentRx.prescriptionCode}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">খাতার পেজ নম্বর:</span>
                  <span className="font-bold text-amber-900 bg-amber-100/70 border border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800 px-2 py-0.5 rounded text-xs font-mono inline-block">
                    {currentRx.registerPageNo || 'পৃষ্ঠা: N/A'}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">বয়স ও লিঙ্গ:</span>
                  <span className="font-semibold text-gray-800 text-xs">
                    {currentRx.patientAge} বছর, {currentRx.patientGender}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">তারিখ:</span>
                  <span className="font-bold text-gray-900 text-xs font-mono">
                    {currentRx.date}
                  </span>
                </div>

                <div>
                  <span className="text-gray-500 block text-[11px] font-medium">চিকিৎসক:</span>
                  <span className="font-bold text-emerald-900 text-xs">
                    {currentRx.doctorName}
                  </span>
                </div>
              </div>

              {/* Clinical Impression & Symptoms */}
              <div className="mb-6 space-y-2">
                <div className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center space-x-1.5 text-emerald-800">
                  <HeartPulse className="w-4 h-4 text-emerald-700" />
                  <span>রোগ নির্ণয় ও ক্লিনিক্যাল অবজারভেশন (Diagnosis)</span>
                </div>
                <div className="bg-emerald-50/50 p-3 rounded-lg border border-emerald-100 text-xs sm:text-sm text-gray-800">
                  <div className="font-bold text-emerald-950 mb-1">
                    {currentRx.diagnosis}
                  </div>
                  {currentRx.symptoms && currentRx.symptoms.length > 0 && (
                    <div className="text-gray-700 text-xs">
                      <span className="font-semibold">প্রধান লক্ষণসমূহ:</span>{' '}
                      {currentRx.symptoms.join(', ')}
                    </div>
                  )}
                  {currentRx.constitutionalState && (
                    <div className="text-emerald-800 text-xs mt-1">
                      <span className="font-semibold">প্রকৃতি / মায়াজমেটিক স্টেজ:</span>{' '}
                      {currentRx.constitutionalState}
                    </div>
                  )}
                </div>
              </div>

              {/* Rx Prescription Medicine Section (Locked when logged out) */}
              <div className="mb-6">
                <div className="text-lg font-serif italic font-black text-emerald-900 mb-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl not-italic">℞</span>
                    <span className="text-sm font-sans font-bold not-italic tracking-normal">
                      হোমিওপ্যাথিক ওষুধের ব্যবস্থাপত্র ও সেবনবিধি
                    </span>
                  </div>

                  {/* Security / Auth Status Badges */}
                  {canViewMedicines ? (
                    isMasterAuthenticated ? (
                      <span className="text-[11px] font-sans not-italic font-bold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full flex items-center space-x-1 border border-emerald-300">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>ডাক্তার / এডমিন ভিউ (ওষুধ উন্মুক্ত)</span>
                      </span>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <span className="text-[11px] font-sans not-italic font-bold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full flex items-center space-x-1 border border-amber-300">
                          <Unlock className="w-3.5 h-3.5 text-amber-700" />
                          <span>মাস্টার কোডে আনলককৃত</span>
                        </span>
                        <button
                          type="button"
                          onClick={handleLockMedicines}
                          className="text-[11px] font-sans not-italic font-bold bg-gray-200 hover:bg-gray-300 text-gray-800 px-2.5 py-0.5 rounded-md flex items-center space-x-1 transition shadow-xs"
                          title="ওষুধ তালিকা পুনরায় লক করুন"
                        >
                          <Lock className="w-3 h-3 text-gray-600" />
                          <span>পুনরায় লক করুন</span>
                        </button>
                      </div>
                    )
                  ) : (
                    <span className="text-[11px] font-sans not-italic font-bold bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full flex items-center space-x-1 border border-rose-300">
                      <Lock className="w-3.5 h-3.5 text-rose-600" />
                      <span>লগআউট লক সক্রিয়</span>
                    </span>
                  )}
                </div>

                {canViewMedicines ? (
                  /* Unlocked Medicine Table */
                  <div className="overflow-x-auto border border-gray-300 rounded-lg">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-gray-100 text-gray-700 font-bold border-b border-gray-300">
                          <th className="p-2.5">নং</th>
                          <th className="p-2.5">ওষুধের নাম (Medicine Name)</th>
                          <th className="p-2.5">পোটেন্সি (Potency)</th>
                          <th className="p-2.5">মাত্রা ও সেবনবিধি (Dosage & Timing)</th>
                          <th className="p-2.5">মেয়াদ (Duration)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {currentRx.medicines.map((med, idx) => (
                          <tr key={med.id || idx} className="hover:bg-gray-50/70">
                            <td className="p-2.5 font-bold font-mono text-gray-500">
                              {idx + 1}
                            </td>
                            <td className="p-2.5">
                              <div className="font-bold text-emerald-950 text-sm">
                                {med.name}
                              </div>
                              {med.instructions && (
                                <div className="text-[11px] text-gray-600 mt-0.5">
                                  • {med.instructions}
                                </div>
                              )}
                            </td>
                            <td className="p-2.5 font-mono font-bold text-purple-900 bg-purple-50/50">
                              {med.potency}
                            </td>
                            <td className="p-2.5">
                              <div className="font-semibold text-gray-900">
                                {med.dosage} — {med.frequency}
                              </div>
                              <div className="text-[11px] text-emerald-800">
                                {med.timing}
                              </div>
                            </td>
                            <td className="p-2.5 font-medium text-gray-700">
                              {med.duration}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  /* Locked State View (When logged out) */
                  <div className="border-2 border-dashed border-amber-300 dark:border-amber-700 bg-gradient-to-b from-amber-50/90 to-orange-50/80 dark:from-amber-950/30 dark:to-orange-950/20 rounded-xl p-5 sm:p-6 text-center space-y-4">
                    <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 flex items-center justify-center shadow-inner">
                      <Lock className="w-7 h-7" />
                    </div>

                    <div className="max-w-md mx-auto space-y-1">
                      <h4 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white flex items-center justify-center space-x-2">
                        <span>🔒 ওষুধ তালিকা সুরক্ষিত ও লক করা (Medicines Protected)</span>
                      </h4>
                      <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                        লগআউট থাকা অবস্থায় হোমিওপ্যাথিক প্রেসক্রিপশনের ওষুধ ও সেবনবিধি গোপন রাখা হয়েছে। ওষুধসমূহ দেখতে হলে চেম্বারের <strong>মাস্টার সিকিউরিটি কোড (Master Security Code)</strong> প্রদান করুন।
                      </p>
                    </div>

                    {/* Master Security Code Input Form */}
                    <form onSubmit={handleUnlockMedicines} className="max-w-xs mx-auto space-y-3">
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-amber-600">
                          <KeyRound className="w-4 h-4" />
                        </div>
                        <input
                          type={showCodeInput ? 'text' : 'password'}
                          value={securityCodeInput}
                          onChange={(e) => {
                            setSecurityCodeInput(e.target.value);
                            setSecurityError('');
                          }}
                          placeholder="মাস্টার সিকিউরিটি কোড..."
                          className="w-full pl-9 pr-9 py-2 text-xs sm:text-sm font-mono tracking-wider rounded-xl border border-amber-300 dark:border-amber-700 bg-white dark:bg-[#1a2024] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-inner"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCodeInput(!showCodeInput)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                        >
                          {showCodeInput ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>

                      {securityError && (
                        <div className="text-xs text-rose-700 bg-rose-50 border border-rose-200 py-1.5 px-3 rounded-lg flex items-center justify-center space-x-1.5 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-rose-600" />
                          <span>{securityError}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center space-x-1.5"
                      >
                        <Unlock className="w-4 h-4" />
                        <span>ওষুধসমূহ আনলক করুন</span>
                      </button>
                    </form>

                    {/* Security confidentiality notice - Code is strictly hidden when logged out */}
                    <div className="pt-2 border-t border-amber-200 dark:border-amber-800 text-[11px] max-w-xs mx-auto text-center text-gray-500 dark:text-gray-400 flex items-center justify-center space-x-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                      <span>গোপন মাস্টার কোড কেবল চেম্বার কর্তৃপক্ষের নিয়ন্ত্রণে সংরক্ষিত।</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Diet Restrictions & Homeopathic Dos & Don'ts */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 text-xs">
                {currentRx.dietRestrictions && currentRx.dietRestrictions.length > 0 && (
                  <div className="bg-rose-50/70 border border-rose-200 rounded-lg p-3">
                    <div className="font-bold text-rose-900 flex items-center space-x-1.5 mb-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                      <span>হোমিওপ্যাথিক পথ্য ও বর্জনীয় (Dietary & Restrictions)</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-rose-800">
                      {currentRx.dietRestrictions.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {currentRx.lifestyleAdvice && currentRx.lifestyleAdvice.length > 0 && (
                  <div className="bg-teal-50/70 border border-teal-200 rounded-lg p-3">
                    <div className="font-bold text-teal-900 flex items-center space-x-1.5 mb-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                      <span>লাইফস্টাইল ও সাধারণ পরামর্শ</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-teal-800">
                      {currentRx.lifestyleAdvice.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Free-text Blank Box Notes from Doctor */}
                {currentRx.notes && (
                  <div className="sm:col-span-2 bg-amber-50/80 border border-amber-200 rounded-lg p-3 text-amber-900">
                    <div className="font-bold flex items-center space-x-1.5 mb-1.5 text-amber-950">
                      <FileText className="w-3.5 h-3.5 text-amber-600" />
                      <span>চিকিৎসকের বিশেষ পথ্য ও পালনীয় নির্দেশনাবলী (Doctor's Dietary Notes):</span>
                    </div>
                    <p className="whitespace-pre-line text-xs leading-relaxed text-amber-900 font-medium">
                      {currentRx.notes}
                    </p>
                  </div>
                )}
              </div>

              {/* Attached Prescription Photo / Scan Copy */}
              {currentRx.prescriptionImage && (
                <div className="mb-6 bg-gradient-to-br from-emerald-50/60 to-teal-50/40 dark:from-emerald-950/20 dark:to-teal-950/10 border border-emerald-200 dark:border-emerald-800 rounded-xl p-4">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-emerald-200 dark:border-emerald-800">
                    <div className="flex items-center space-x-2 text-emerald-950 dark:text-emerald-200 font-bold text-xs sm:text-sm">
                      <Camera className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span>প্রেসক্রিপশনের মূল ছবি / স্ক্যান কপি (Prescription Photo / Scan Copy)</span>
                    </div>
                    <div className="flex items-center space-x-2 no-print">
                      <button
                        type="button"
                        onClick={() => setModalImagePreview(currentRx.prescriptionImage || null)}
                        className="px-2.5 py-1 bg-white dark:bg-gray-800 hover:bg-emerald-50 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 rounded-md text-[11px] font-bold flex items-center space-x-1 shadow-2xs transition"
                        title="বড় করে সম্পূর্ণ ছবি দেখুন"
                      >
                        <Maximize2 className="w-3 h-3 text-emerald-600" />
                        <span>জুম / বড় ভিউ</span>
                      </button>
                      <a
                        href={currentRx.prescriptionImage}
                        download={`Prescription-${currentRx.prescriptionCode}.png`}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-[11px] font-bold flex items-center space-x-1 shadow-2xs transition"
                        title="প্রেসক্রিপশনের ছবি ডাউনলোড করুন"
                      >
                        <Download className="w-3 h-3" />
                        <span>ডাউনলোড</span>
                      </a>
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center p-2 bg-white dark:bg-black/20 rounded-lg border border-emerald-100 dark:border-emerald-900/60">
                    <img
                      src={currentRx.prescriptionImage}
                      alt="Prescription Document Photo"
                      className="max-h-80 w-auto object-contain rounded cursor-pointer hover:opacity-95 transition shadow-sm"
                      onClick={() => setModalImagePreview(currentRx.prescriptionImage || null)}
                    />
                    <span className="text-[10px] text-gray-400 mt-1.5 no-print">
                      (সম্পূর্ণ ছবি জুম করতে ছবির ওপর ক্লিক করুন)
                    </span>
                  </div>
                </div>
              )}

              {/* Followup & Signature */}
              <div className="border-t border-gray-200 pt-4 flex flex-col sm:flex-row justify-between items-center text-xs text-gray-600 gap-3">
                <div>
                  <span className="font-bold text-gray-800">পরবর্তী সাক্ষাতের সম্ভাব্য তারিখ:</span>{' '}
                  <span className="font-bold text-emerald-800 font-mono">
                    {currentRx.followUpDate || '১৫ দিন পর'}
                  </span>
                </div>

                <div className="text-center sm:text-right">
                  <div className="font-serif italic font-bold text-emerald-900 text-sm border-b border-gray-400 pb-1">
                    {currentRx.doctorName}
                  </div>
                  <div className="text-[10px] text-gray-500 mt-0.5">
                    ডিজিটালভাবে স্বাক্ষরিত ও সংরক্ষিত
                  </div>
                </div>
              </div>

            </div>
          ) : (
            /* Empty State */
            <div className="text-center py-12 space-y-3">
              <FileSearch className="w-12 h-12 text-gray-400 mx-auto" />
              <h4 className="text-lg font-bold text-gray-800 dark:text-gray-200">
                কোনো প্রেসক্রিপশন পাওয়া যায়নি
              </h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                অনুগ্রহ করে সঠিক মোবাইল নম্বর অথবা প্রেসক্রিপশন কোড দিয়ে পুনরায় সার্চ করুন (যেমন: 01721-455667 বা RX-2026-881)।
              </p>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer (No-print) */}
        {currentRx && (
          <div className="bg-gray-50 dark:bg-[#161c20] px-6 py-3 border-t border-gray-200 dark:border-gray-800 flex flex-col sm:flex-row justify-between items-center gap-2 no-print shrink-0">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                Rx Code: {currentRx.prescriptionCode}
              </span>
              {!canViewMedicines && (
                <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/60 px-2 py-0.5 rounded flex items-center space-x-1">
                  <Lock className="w-3 h-3 text-amber-600" />
                  <span>ওষুধ লক রয়েছে</span>
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Print Button (Available to both patients and doctors) */}
              <button
                onClick={handlePrint}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center space-x-1.5"
                title="প্রেসক্রিপশন প্রিন্ট করুন বা PDF ডাউনলোড করুন"
              >
                <Printer className="w-4 h-4" />
                <span>প্রেসক্রিপশন প্রিন্ট</span>
              </button>

              {/* Admin Actions: Edit & Delete */}
              {isMasterAuthenticated && (
                <>
                  <button
                    onClick={() => {
                      setIsPrescriptionLookupOpen(false);
                      setCurrentView('wp-admin');
                      setAdminSubTab('prescriptions');
                    }}
                    className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center space-x-1"
                    title="ওয়ার্ডপ্রেস এডমিনে প্রেসক্রিপশন ও ওষুধ এডিট করুন"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>এডিট করুন</span>
                  </button>

                  {isConfirmingDelete ? (
                    <div className="flex items-center space-x-1 bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 p-1 rounded-xl">
                      <span className="text-[11px] text-rose-700 dark:text-rose-300 font-bold px-1.5">মুছে ফেলবেন?</span>
                      <button
                        onClick={() => {
                          deletePrescription(currentRx.id);
                          setSelectedPrescriptionForView(null);
                          setIsConfirmingDelete(false);
                          setIsPrescriptionLookupOpen(false);
                        }}
                        className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] rounded-lg"
                      >
                        হ্যাঁ
                      </button>
                      <button
                        onClick={() => setIsConfirmingDelete(false)}
                        className="px-2 py-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-[11px] rounded-lg"
                      >
                        না
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsConfirmingDelete(true)}
                      className="px-3 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-800 font-bold text-xs rounded-xl transition flex items-center space-x-1"
                      title="প্রেসক্রিপশন স্থায়ীভাবে মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>ডিলেট</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* FULLSCREEN PRESCRIPTION IMAGE PREVIEW MODAL                               */}
        {/* ========================================================================= */}
        {modalImagePreview && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xs animate-in fade-in no-print">
            <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-4xl w-full p-4 sm:p-5 shadow-2xl border border-gray-300 dark:border-gray-700 flex flex-col max-h-[92vh]">
              <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white">
                      প্রেসক্রিপশনের মূল ছবি / স্ক্যান কপি
                    </h4>
                    <p className="text-[11px] text-gray-500">
                      কোড: <span className="font-mono font-bold text-emerald-600">{currentRx?.prescriptionCode}</span> • রোগী: <span className="font-bold">{currentRx?.patientName}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <a
                    href={modalImagePreview}
                    download={`Prescription-${currentRx?.prescriptionCode || 'scan'}.png`}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center space-x-1 shadow-2xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ডাউনলোড</span>
                  </a>
                  <button
                    onClick={() => setModalImagePreview(null)}
                    className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-2 flex items-center justify-center bg-gray-100 dark:bg-black/40 rounded-xl my-3">
                <img
                  src={modalImagePreview}
                  alt="Full-size Prescription Document"
                  className="max-h-[72vh] w-auto object-contain rounded-lg shadow-md"
                />
              </div>

              <div className="pt-2 text-center text-[11px] text-gray-500 flex items-center justify-between">
                <span>মাউস বা টাচ করে জুম ও নিখুঁতভাবে লেখা পর্যবেক্ষণ করুন</span>
                <button
                  onClick={() => setModalImagePreview(null)}
                  className="px-4 py-1.5 bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg font-bold text-xs"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
