import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { MATERIA_MEDICA_GUIDE } from '../utils/initialData.ts';
import { verifyMasterSecurityCode } from '../utils/crypto.ts';
import {
  BookOpen,
  Search,
  Pill,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  KeyRound,
  Eye,
  CheckCircle2
} from 'lucide-react';

export const MateriaMedicaGuide: React.FC = () => {
  const { isMasterAuthenticated, adminProfile, setIsLoginModalOpen } = useClinic();
  const [searchTerm, setSearchTerm] = useState('');

  // Local master security code unlock state (in addition to full master login)
  const [isLocalUnlocked, setIsLocalUnlocked] = useState(false);
  const [securityCodeInput, setSecurityCodeInput] = useState('');
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [securityError, setSecurityError] = useState('');

  const isAccessAllowed = isMasterAuthenticated || isLocalUnlocked;

  const handleUnlockWithCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!securityCodeInput.trim()) {
      setSecurityError('মাস্টার সিকিউরিটি কোড লিখুন।');
      return;
    }

    if (verifyMasterSecurityCode(securityCodeInput.trim(), adminProfile.masterSecurityCode)) {
      setIsLocalUnlocked(true);
      setShowCodeInput(false);
      setSecurityCodeInput('');
      setSecurityError('');
    } else {
      setSecurityError('ভুল মাস্টার সিকিউরিটি কোড! সঠিক অনুমোদিত কোড দিন।');
    }
  };

  const filteredMedicines = isAccessAllowed
    ? MATERIA_MEDICA_GUIDE.filter(
        (med) =>
          med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          med.commonName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          med.keyIndications.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  return (
    <section id="materia-medica" className="py-16 bg-gray-50 dark:bg-[#14191d] transition-colors border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-2 bg-indigo-100 dark:bg-indigo-950/80 text-indigo-800 dark:text-indigo-300 px-3.5 py-1 rounded-full text-xs font-semibold mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>হোমিওপ্যাথিক জ্ঞানকোষ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
            মেটেরিয়া মেডিকা ও লক্ষণ নির্দেশিকা
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-600 dark:text-gray-400">
            ক্লাসিকাল হোমিওপ্যাথির প্রধান মহৌষধসমূহের বৈশিষ্ট্য, কার্যকারিতা ও লক্ষণ ভিত্তিক প্রয়োগবিধি।
          </p>

          {/* If Authorized: Show Search Bar */}
          {isAccessAllowed && (
            <div className="mt-6 max-w-md mx-auto relative animate-fade-in">
              <input
                type="text"
                placeholder="ওষুধ বা লক্ষণের নাম অনুসন্ধান করুন (যেমন: Arnica, ব্যথা, গ্যাস্ট্রিক)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#1b2126] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
            </div>
          )}
        </div>

        {/* LOGGED OUT STATE: Zero medicines shown! Secure lock barrier */}
        {!isAccessAllowed ? (
          <div className="max-w-2xl mx-auto bg-white dark:bg-[#1a2024] rounded-3xl p-8 sm:p-10 border border-gray-200 dark:border-gray-800 shadow-lg text-center space-y-5 animate-scale-up">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 mx-auto flex items-center justify-center shadow-inner">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs font-bold border border-rose-200 dark:border-rose-900 mb-2">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>সংরক্ষিত হোমিওপ্যাথিক জ্ঞানকোষ</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
                লগআউট অবস্থায় মেটেরিয়া মেডিকা সুরক্ষিত
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 mt-2 max-w-lg mx-auto leading-relaxed">
                চিকিৎসা নিরাপত্তা ও গোপনীয়তার স্বার্থে লগআউট থাকা অবস্থায় মেটেরিয়া মেডিকার কোনো ওষুধ বা তথ্য প্রদর্শিত হবে না। মেটেরিয়া মেডিকার তথ্য ও লক্ষণ নির্দেশিকা দেখতে অনুমোদিত মাস্টার এডমিন লগইন সম্পন্ন করুন।
              </p>
            </div>

            {/* Actions for Authorized Doctor */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="w-full sm:w-auto px-6 py-2.5 bg-[#2271b1] hover:bg-[#135e96] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition flex items-center justify-center space-x-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>মাস্টার এডমিন লগইন</span>
              </button>

              <button
                onClick={() => setShowCodeInput(!showCodeInput)}
                className="w-full sm:w-auto px-5 py-2.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-bold text-xs sm:text-sm rounded-xl transition flex items-center justify-center space-x-2 border border-gray-300 dark:border-gray-700"
              >
                <Unlock className="w-4 h-4 text-amber-500" />
                <span>সিকিউরিটি কোডে আনলক</span>
              </button>
            </div>

            {/* Quick Master Security Code Unlock Box */}
            {showCodeInput && (
              <form onSubmit={handleUnlockWithCode} className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-800 max-w-md mx-auto space-y-3">
                <div className="flex gap-2">
                  <input
                    type="password"
                    placeholder="মাস্টার সিকিউরিটি কোড লিখুন..."
                    value={securityCodeInput}
                    onChange={(e) => {
                      setSecurityCodeInput(e.target.value);
                      setSecurityError('');
                    }}
                    className="flex-1 px-3 py-2 text-xs rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#131b1e] text-gray-900 dark:text-white font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    autoFocus
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl transition flex items-center space-x-1 shrink-0 shadow-xs"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>আনলক</span>
                  </button>
                </div>
                {securityError && (
                  <p className="text-xs text-rose-500 font-bold text-left">{securityError}</p>
                )}
              </form>
            )}
          </div>
        ) : (
          /* AUTHORIZED STATE: Full Materia Medica Grid */
          <div className="space-y-6 animate-fade-in">
            {/* Status bar */}
            <div className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-2xl border border-emerald-200 dark:border-emerald-800 max-w-xl mx-auto text-xs text-emerald-900 dark:text-emerald-300">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-bold">
                  মেটেরিয়া মেডিকা সক্রিয় ({filteredMedicines.length} টি মহৌষধ)
                </span>
              </div>
              {isLocalUnlocked && !isMasterAuthenticated && (
                <button
                  onClick={() => setIsLocalUnlocked(false)}
                  className="px-2.5 py-1 bg-gray-200 dark:bg-gray-800 hover:bg-rose-100 dark:hover:bg-rose-950 text-gray-700 dark:text-gray-300 hover:text-rose-600 rounded-lg text-[11px] font-bold transition flex items-center space-x-1"
                >
                  <Lock className="w-3 h-3" />
                  <span>পুনরায় লক করুন</span>
                </button>
              )}
            </div>

            {/* Medicines Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredMedicines.map((med, index) => (
                <div
                  key={index}
                  className="bg-white dark:bg-[#1a2024] rounded-2xl border border-gray-200 dark:border-gray-800 p-5 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded">
                        পোটেন্সি: {med.commonPotencies.join(', ')}
                      </span>
                      <Pill className="w-4 h-4 text-emerald-600" />
                    </div>

                    <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                      {med.name}
                    </h3>
                    <div className="text-xs text-gray-500 dark:text-gray-400 italic mb-3 font-medium">
                      {med.commonName}
                    </div>

                    <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed mb-3">
                      {med.keyIndications}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-gray-100 dark:border-gray-800 text-[11px] text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-[#151a1e] p-2.5 rounded-lg">
                    <span className="font-bold text-gray-800 dark:text-gray-200 block mb-0.5">
                      হ্রাস/বৃদ্ধি (Modalities):
                    </span>
                    {med.modalities}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
