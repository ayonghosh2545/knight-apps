import React from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Stethoscope,
  Calendar,
  Clock,
  Award,
  CheckCircle,
  Phone,
  Mail,
  GraduationCap
} from 'lucide-react';

export const DoctorProfilesSection: React.FC = () => {
  const { doctors, setIsBookingModalOpen, setSelectedDoctorForBooking } = useClinic();

  const handleBookDoctor = (doc: any) => {
    setSelectedDoctorForBooking(doc);
    setIsBookingModalOpen(true);
  };

  return (
    <section id="doctors" className="py-16 bg-white dark:bg-[#161c20] transition-colors border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-2 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 px-3.5 py-1 rounded-full text-xs font-semibold mb-3">
            <Stethoscope className="w-3.5 h-3.5" />
            <span>আমাদের বিশেষজ্ঞ প্যানেল</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
            অভিজ্ঞ হোমিওপ্যাথিক চিকিৎসকবৃন্দ
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-600 dark:text-gray-400">
            বিজ্ঞ ও অভিজ্ঞ ক্লাসিকাল হোমিওপ্যাথদের সার্বক্ষণিক তত্ত্বাবধানে বিজ্ঞানসম্মত রোগ বিশ্লেষণ ও স্থায়ী আরোগ্যের নিশ্চয়তা।
          </p>
        </div>

        {/* Doctor Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {doctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-gray-50 dark:bg-[#1a2024] rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col group"
            >
              
              {/* Doctor Avatar & Top Info */}
              <div className="p-6 pb-4 flex items-start space-x-4">
                <img
                  src={doc.avatar}
                  alt={doc.name}
                  className="w-20 h-20 rounded-2xl object-cover shadow-md border-2 border-emerald-500/30 group-hover:scale-105 transition-transform shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-lg text-gray-900 dark:text-white truncate">
                    {doc.name}
                  </h3>
                  <div className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5 line-clamp-1">
                    {doc.designation}
                  </div>
                  <div className="inline-flex items-center space-x-1 text-[11px] text-gray-500 dark:text-gray-400 mt-1.5 font-medium">
                    <Award className="w-3 h-3 text-amber-500" />
                    <span>{doc.experienceYears}+ বছর অভিজ্ঞতা</span>
                  </div>
                </div>
              </div>

              {/* Qualifications & Bio */}
              <div className="px-6 py-2 flex-1 space-y-3">
                <div className="flex items-start space-x-2 text-xs text-gray-600 dark:text-gray-300 bg-white dark:bg-[#131b1e] p-2.5 rounded-xl border border-gray-200 dark:border-gray-800">
                  <GraduationCap className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{doc.qualification}</span>
                </div>

                {/* Specialties Chips */}
                <div>
                  <span className="text-[11px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">
                    বিশেষজ্ঞ ক্ষেত্রসমূহ:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {doc.specialties.map((spec, i) => (
                      <span
                        key={i}
                        className="text-[11px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800 font-medium"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Visiting Schedule */}
                <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400 pt-1">
                  <div className="flex items-center space-x-1.5 font-medium">
                    <Clock className="w-3.5 h-3.5 text-teal-600" />
                    <span>সময়: {doc.visitingHours}</span>
                  </div>
                  <div className="text-[11px] text-gray-500 dark:text-gray-400 pl-5">
                    দিন: {doc.visitingDays.join(', ')}
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer: Fees & Action */}
              <div className="p-6 pt-4 border-t border-gray-200 dark:border-gray-800 bg-white/50 dark:bg-[#14191d]/50 flex items-center justify-between mt-auto">
                <div>
                  <span className="text-[10px] text-gray-500 dark:text-gray-400 block">পরামর্শ ফি</span>
                  <div className="text-base font-extrabold text-emerald-700 dark:text-emerald-400 font-mono">
                    ৳{doc.consultationFee} <span className="text-[11px] text-gray-500 font-sans font-normal">(ফলোআপ: ৳{doc.followupFee})</span>
                  </div>
                </div>

                <button
                  onClick={() => handleBookDoctor(doc)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>সিরিয়াল নিন</span>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
