import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Search,
  X,
  FileText,
  Calendar,
  User,
  Pill,
  Settings,
  ArrowRight
} from 'lucide-react';

export const GlobalSearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    appointments,
    prescriptions,
    patients,
    setSelectedPrescriptionForView,
    setIsPrescriptionLookupOpen,
    setCurrentView,
    setAdminSubTab,
    isMasterAuthenticated
  } = useClinic();

  const [query, setQuery] = useState('');

  if (!isSearchOpen) return null;

  const q = query.trim().toLowerCase();

  const matchedPatients = q
    ? patients.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.phone.includes(q) ||
          p.address.toLowerCase().includes(q)
      )
    : [];

  const matchedPrescriptions = q
    ? prescriptions.filter(
        (rx) =>
          rx.prescriptionCode.toLowerCase().includes(q) ||
          rx.patientName.toLowerCase().includes(q) ||
          (rx.patientAddress && rx.patientAddress.toLowerCase().includes(q)) ||
          (rx.registerPageNo && rx.registerPageNo.toLowerCase().includes(q)) ||
          rx.patientPhone.includes(q) ||
          rx.diagnosis.toLowerCase().includes(q) ||
          (isMasterAuthenticated && rx.medicines.some((m) => m.name.toLowerCase().includes(q)))
      )
    : [];

  const matchedAppointments = q
    ? appointments.filter(
        (apt) =>
          apt.patientName.toLowerCase().includes(q) ||
          (apt.address && apt.address.toLowerCase().includes(q)) ||
          apt.phone.includes(q) ||
          `#tk-${apt.tokenNumber}`.includes(q) ||
          apt.symptoms.toLowerCase().includes(q)
      )
    : [];

  const handleSelectPrescription = (rx: any) => {
    setSelectedPrescriptionForView(rx);
    setIsPrescriptionLookupOpen(true);
    setIsSearchOpen(false);
  };

  const handleGoToAdmin = (tab: string) => {
    if (isMasterAuthenticated) {
      setCurrentView('wp-admin');
      setAdminSubTab(tab);
      setIsSearchOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col max-h-[80vh]">
        
        {/* Search Input Bar */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex items-center space-x-3 bg-gray-50 dark:bg-[#161c20]">
          <Search className="w-5 h-5 text-gray-400 shrink-0" />
          <input
            type="text"
            placeholder="রোগীর নাম, ঠিকানা, মোবাইল নম্বর অথবা প্রেসক্রিপশন কোড দিয়ে খুঁজুন..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-sm sm:text-base text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none"
          />
          <button
            onClick={() => setIsSearchOpen(false)}
            className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm">
          {!query ? (
            <div className="text-center py-8 text-gray-400 space-y-2">
              <Search className="w-8 h-8 mx-auto text-gray-300 dark:text-gray-600" />
              <p>যেকোনো নাম, মোবাইল নম্বর, প্রেসক্রিপশন কোড (যেমন: RX-2026-881) লিখুন</p>
            </div>
          ) : (
            <>
              {/* Prescriptions Result */}
              {matchedPrescriptions.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                    <FileText className="w-3.5 h-3.5 text-teal-500" />
                    <span>প্রেসক্রিপশন ({matchedPrescriptions.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedPrescriptions.map((rx) => (
                      <div
                        key={rx.id}
                        onClick={() => handleSelectPrescription(rx)}
                        className="p-2.5 rounded-xl bg-gray-50 hover:bg-emerald-50 dark:bg-gray-800/60 dark:hover:bg-emerald-950/40 cursor-pointer border border-gray-200 dark:border-gray-700 transition flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-gray-900 dark:text-white flex items-center space-x-1.5">
                            <span>{rx.patientName}</span>
                            <span className="text-emerald-600 font-mono text-xs font-bold">{rx.prescriptionCode}</span>
                            {rx.registerPageNo && (
                              <span className="text-[10px] text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950 px-1.5 py-0.5 rounded font-mono border border-amber-200">
                                {rx.registerPageNo}
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {rx.diagnosis} ({rx.date})
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-emerald-600" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Appointments Result */}
              {matchedAppointments.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                    <Calendar className="w-3.5 h-3.5 text-sky-500" />
                    <span>অ্যাপয়েন্টমেন্ট ({matchedAppointments.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedAppointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-gray-900 dark:text-white">
                            {apt.patientName} <span className="font-mono text-emerald-600">#TK-{apt.tokenNumber}</span>
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            তারিখ: {apt.date} ({apt.timeSlot}) — {apt.doctorName}
                          </div>
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                          {apt.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Patients Result */}
              {matchedPatients.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                    <User className="w-3.5 h-3.5 text-amber-500" />
                    <span>নিবন্ধিত রোগী ({matchedPatients.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedPatients.map((pat) => (
                      <div
                        key={pat.id}
                        className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-gray-900 dark:text-white">
                            {pat.name} ({pat.age} বছর, {pat.gender})
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                            {pat.phone} — মোট ভিজিট: {pat.totalVisits}
                          </div>
                        </div>
                        <span className="text-xs text-gray-500">{pat.address}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {matchedPrescriptions.length === 0 &&
                matchedAppointments.length === 0 &&
                matchedPatients.length === 0 && (
                  <div className="text-center py-6 text-gray-400">
                    কোনো তথ্য খুঁজে পাওয়া যায়নি।
                  </div>
                )}
            </>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-3 bg-gray-100 dark:bg-[#161c20] border-t border-gray-200 dark:border-gray-800 text-[11px] text-gray-500 flex justify-between items-center">
          <span>ESC চেপে বন্ধ করুন</span>
          <span>দ্রুত শর্টকাট: Ctrl + K</span>
        </div>

      </div>
    </div>
  );
};
