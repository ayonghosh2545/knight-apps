import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { Appointment } from '../types.ts';
import {
  X,
  Calendar,
  Clock,
  User,
  Phone,
  MapPin,
  CheckCircle,
  Printer,
  Sparkles,
  Stethoscope,
  HeartPulse
} from 'lucide-react';

export const AppointmentBookingModal: React.FC = () => {
  const {
    doctors,
    isBookingModalOpen,
    setIsBookingModalOpen,
    selectedDoctorForBooking,
    setSelectedDoctorForBooking,
    bookAppointment
  } = useClinic();

  const [doctorId, setDoctorId] = useState<string>(
    selectedDoctorForBooking?.id || doctors[0]?.id || ''
  );
  const [date, setDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [timeSlot, setTimeSlot] = useState<string>('সন্ধ্যা ৬:০০ - সন্ধ্যা ৬:২০');
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState<number | ''>('');
  const [patientGender, setPatientGender] = useState<'পুরুষ' | 'মহিলা' | 'শিশু' | 'অন্যান্য'>('পুরুষ');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [chronicHistory, setChronicHistory] = useState('');
  const [consultationType, setConsultationType] = useState<'chamber' | 'online'>('chamber');

  const [bookedAppointment, setBookedAppointment] = useState<Appointment | null>(null);

  if (!isBookingModalOpen) return null;

  const currentSelectedDoctor = doctors.find((d) => d.id === doctorId) || doctors[0];

  const timeSlots = [
    'সকাল ১০:৩০ - সকাল ১০:৫০',
    'সকাল ১১:০০ - সকাল ১১:২০',
    'দুপুর ১২:০০ - দুপুর ১২:২০',
    'বিকাল ৫:৩০ - বিকাল ৫:৫০',
    'সন্ধ্যা ৬:০০ - সন্ধ্যা ৬:২০',
    'সন্ধ্যা ৬:৩০ - সন্ধ্যা ৬:৫০',
    'রাত ৭:০০ - রাত ৭:২০',
    'রাত ৭:৩০ - রাত ৭:৫০',
    'রাত ৮:০০ - রাত ৮:২০'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !phone.trim() || !symptoms.trim()) {
      alert('অনুগ্রহ করে নাম, মোবাইল নম্বর এবং সমস্যার বিবরণ লিখুন।');
      return;
    }

    const apt = bookAppointment({
      patientName: patientName.trim(),
      patientAge: Number(patientAge) || 30,
      patientGender,
      phone: phone.trim(),
      address: address.trim() || 'উত্তরা, ঢাকা',
      date,
      timeSlot,
      doctorId: currentSelectedDoctor.id,
      doctorName: currentSelectedDoctor.name,
      symptoms: symptoms.trim(),
      chronicHistory: chronicHistory.trim(),
      priority: 'normal',
      consultationType
    });

    setBookedAppointment(apt);
  };

  const handlePrintVoucher = () => {
    window.print();
  };

  const resetForm = () => {
    setBookedAppointment(null);
    setPatientName('');
    setPatientAge('');
    setPhone('');
    setSymptoms('');
    setChronicHistory('');
    setIsBookingModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full shadow-2xl border border-gray-200 dark:border-gray-800 my-8 overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <Calendar className="w-5 h-5 text-emerald-200" />
            <h3 className="font-bold text-lg">
              {bookedAppointment ? 'অ্যাপয়েন্টমেন্ট বুকিং নিশ্চিতকরণ' : 'অনলাইন অ্যাপয়েন্টমেন্ট বুকিং'}
            </h3>
          </div>
          <button
            onClick={resetForm}
            className="p-1 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {bookedAppointment ? (
            /* Booking Success Receipt Card */
            <div id="printable-prescription" className="space-y-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950/80 rounded-full flex items-center justify-center mx-auto text-emerald-600 dark:text-emerald-400">
                <CheckCircle className="w-9 h-9" />
              </div>

              <div>
                <h4 className="text-2xl font-black text-gray-900 dark:text-white">
                  বুকিং সফলভাবে সম্পন্ন হয়েছে!
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  আপনার অ্যাপয়েন্টমেন্ট টোকেন ও বিস্তারিত নিচে সংরক্ষিত হলো:
                </p>
              </div>

              {/* Token Slip Box */}
              <div className="bg-emerald-50 dark:bg-emerald-950/30 border-2 border-dashed border-emerald-300 dark:border-emerald-800 rounded-2xl p-5 text-left max-w-lg mx-auto">
                <div className="flex justify-between items-start border-b border-emerald-200 dark:border-emerald-800 pb-3 mb-3">
                  <div>
                    <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-400 uppercase">
                      রোগীর সিরিয়াল টোকেন
                    </span>
                    <div className="text-3xl font-black text-emerald-700 dark:text-emerald-300 font-mono">
                      #TK-{bookedAppointment.tokenNumber}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-500 dark:text-gray-400">তারিখ ও সময়</span>
                    <div className="font-bold text-sm text-gray-900 dark:text-white">
                      {bookedAppointment.date}
                    </div>
                    <div className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">
                      {bookedAppointment.timeSlot}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">রোগীর নাম:</span>
                    <div className="font-bold text-gray-900 dark:text-white">
                      {bookedAppointment.patientName} ({bookedAppointment.patientAge} বছর, {bookedAppointment.patientGender})
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">মোবাইল:</span>
                    <div className="font-bold text-gray-900 dark:text-white font-mono">
                      {bookedAppointment.phone}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">চিকিৎসক:</span>
                    <div className="font-bold text-emerald-800 dark:text-emerald-300">
                      {bookedAppointment.doctorName}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">পরামর্শের ধরন:</span>
                    <div className="font-bold text-gray-900 dark:text-white">
                      {bookedAppointment.consultationType === 'chamber' ? 'সরাসরি চেম্বার ভিজিট' : 'অনলাইন ভিডিও কনসাল্ট'}
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-emerald-200 dark:border-emerald-800 text-[11px] text-gray-600 dark:text-gray-400">
                  ⚠️ দয়া করে আপনার নির্ধারিত সময়ের ১৫ মিনিট পূর্বে চেম্বারে উপস্থিত হবেন। চেম্বার সিরিয়াল টোকেন নম্বর অনুযায়ী রোগী আহ্বান করা হবে।
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-center space-x-3 no-print">
                <button
                  onClick={handlePrintVoucher}
                  className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold rounded-xl transition flex items-center space-x-2 text-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>টোকেন প্রিন্ট করুন</span>
                </button>
                <button
                  onClick={resetForm}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition text-sm"
                >
                  সম্পন্ন হয়েছে
                </button>
              </div>
            </div>
          ) : (
            /* Booking Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Doctor Selection */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  চিকিৎসক নির্বাচন করুন *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {doctors.map((doc) => (
                    <div
                      key={doc.id}
                      onClick={() => setDoctorId(doc.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition text-left ${
                        doctorId === doc.id
                          ? 'border-emerald-600 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200'
                          : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                      }`}
                    >
                      <div className="font-bold text-xs">{doc.name}</div>
                      <div className="text-[10px] text-gray-500 dark:text-gray-400 truncate mt-0.5">
                        {doc.designation}
                      </div>
                      <div className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 mt-1">
                        ফি: ৳{doc.consultationFee}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    অ্যাপয়েন্টমেন্টের তারিখ *
                  </label>
                  <input
                    type="date"
                    value={date}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => setDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    সময়সূচী নির্বাচন করুন *
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Patient Personal Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    রোগীর সম্পূর্ণ নাম *
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: মো: আরিফুল ইসলাম"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    বয়স ও লিঙ্গ *
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      placeholder="বয়স"
                      min={1}
                      max={120}
                      value={patientAge}
                      onChange={(e) => setPatientAge(e.target.value ? Number(e.target.value) : '')}
                      required
                      className="w-20 px-2 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <select
                      value={patientGender}
                      onChange={(e) => setPatientGender(e.target.value as any)}
                      className="flex-1 px-2 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="পুরুষ">পুরুষ</option>
                      <option value="মহিলা">মহিলা</option>
                      <option value="শিশু">শিশু</option>
                      <option value="অন্যান্য">অন্যান্য</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Phone & Address */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    মোবাইল নম্বর (SMS ও কনফার্মেশন এর জন্য) *
                  </label>
                  <input
                    type="tel"
                    placeholder="০১৭১২-৩৪৫৬৭৮"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    ঠিকানা / এলাকা
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: উত্তরা, ঢাকা"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Symptoms / Chief Complaints */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  প্রধান উপসর্গ ও শারীরিক সমস্যা (লক্ষণ) *
                </label>
                <textarea
                  rows={2}
                  placeholder="যেমন: দীর্ঘদিন যাবত পেটে গ্যাস, অম্ল ঢেকুর, রাতে ঘুমাতে গেলে অস্বস্তি ইত্যাদি।"
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-sm rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#161c20] text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Consultation Type Selector */}
              <div className="flex items-center space-x-4 pt-1">
                <label className="flex items-center space-x-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
                  <input
                    type="radio"
                    name="consultationType"
                    checked={consultationType === 'chamber'}
                    onChange={() => setConsultationType('chamber')}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>সরাসরি চেম্বার ভিজিট</span>
                </label>
                <label className="flex items-center space-x-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
                  <input
                    type="radio"
                    name="consultationType"
                    checked={consultationType === 'online'}
                    onChange={() => setConsultationType('online')}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>অনলাইন ভিডিও কনসাল্ট (হোয়াটসঅ্যাপ)</span>
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-gray-200 dark:border-gray-800 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2.5 text-xs font-bold text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md shadow-emerald-700/20 transition flex items-center space-x-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>সিরিয়াল নিশ্চিত করুন</span>
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
