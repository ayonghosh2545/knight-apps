import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import {
  Globe,
  LayoutDashboard,
  Plus,
  Moon,
  Sun,
  Search,
  Wifi,
  WifiOff,
  RefreshCw,
  Lock,
  LogOut,
  User,
  ShieldCheck,
  Calendar,
  FileText,
  UserPlus,
  Smartphone,
  UserCog
} from 'lucide-react';

export const WpAdminBar: React.FC = () => {
  const {
    settings,
    adminProfile,
    isMasterAuthenticated,
    isOnline,
    isSyncing,
    syncQueue,
    isDarkMode,
    currentView,
    setCurrentView,
    setAdminSubTab,
    toggleDarkMode,
    setIsSearchOpen,
    setIsLoginModalOpen,
    setIsBookingModalOpen,
    logoutMaster,
    triggerManualSync
  } = useClinic();

  const [isWpMenuOpen, setIsWpMenuOpen] = useState(false);
  const [isNewMenuOpen, setIsNewMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-[#1d2327] text-[#c3c4c7] text-xs select-none shadow-md border-b border-[#2c3338]">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 h-9 flex items-center justify-between">
        
        {/* Left Section: WordPress Icon & Site Toggle */}
        <div className="flex items-center space-x-1 sm:space-x-2">
          {/* WordPress Icon Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsWpMenuOpen(!isWpMenuOpen)}
              onBlur={() => setTimeout(() => setIsWpMenuOpen(false), 200)}
              className="p-1 hover:bg-[#2271b1] hover:text-white rounded transition flex items-center justify-center font-bold text-sm px-2 text-white"
              title="WordPress HomeoPress"
            >
              <span className="w-5 h-5 rounded-full bg-white text-[#1d2327] font-serif font-black flex items-center justify-center text-xs">
                W
              </span>
            </button>

            {isWpMenuOpen && (
              <div className="absolute left-0 mt-1 w-48 bg-[#2c3338] text-[#c3c4c7] rounded shadow-xl py-1 z-50 border border-gray-700 text-xs">
                <div className="px-3 py-1 font-semibold text-white border-b border-gray-700">
                  HomeoPress CMS v1.0.4
                </div>
                <div className="px-3 py-1 text-gray-400">
                  হোমিও আরোগ্য নিকেতন ইঞ্জিন
                </div>
                <a
                  href="https://wordpress.org"
                  target="_blank"
                  rel="noreferrer"
                  className="block px-3 py-1.5 hover:bg-[#2271b1] hover:text-white transition"
                >
                  WordPress.org
                </a>
              </div>
            )}
          </div>

          {/* View Switcher: Frontend Website vs WP Admin */}
          <button
            onClick={() => {
              if (currentView === 'frontend') {
                if (isMasterAuthenticated) {
                  setCurrentView('wp-admin');
                } else {
                  setIsLoginModalOpen(true);
                }
              } else {
                setCurrentView('frontend');
              }
            }}
            className="flex items-center space-x-1.5 px-2 py-1 rounded hover:bg-[#2271b1] hover:text-white text-white font-medium transition"
          >
            {currentView === 'frontend' ? (
              <>
                <LayoutDashboard className="w-3.5 h-3.5 text-[#72aee6]" />
                <span className="hidden md:inline font-semibold">{settings.chamberName}</span>
                <span className="text-[#72aee6] text-[11px] bg-black/30 px-1.5 py-0.5 rounded">
                  {isMasterAuthenticated ? 'অ্যাডমিন ড্যাশবোর্ড' : 'এডমিন লগইন'}
                </span>
              </>
            ) : (
              <>
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-semibold text-white">ওয়েবসাইট দেখুন</span>
                <span className="text-emerald-400 text-[11px] bg-emerald-950/60 px-1.5 py-0.5 rounded">
                  ভিজিটর ভিউ
                </span>
              </>
            )}
          </button>

          {/* Quick "+ New" Dropdown */}
          <div className="relative hidden sm:block">
            <button
              onClick={() => setIsNewMenuOpen(!isNewMenuOpen)}
              onBlur={() => setTimeout(() => setIsNewMenuOpen(false), 200)}
              className="flex items-center space-x-1 px-2 py-1 rounded hover:bg-[#2271b1] hover:text-white transition"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
              <span>নতুন</span>
            </button>

            {isNewMenuOpen && (
              <div className="absolute left-0 mt-1 w-44 bg-[#2c3338] text-white rounded shadow-xl py-1 z-50 border border-gray-700 text-xs">
                <button
                  onClick={() => {
                    setIsBookingModalOpen(true);
                    setIsNewMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2271b1] flex items-center space-x-2"
                >
                  <Calendar className="w-3.5 h-3.5 text-sky-400" />
                  <span>অ্যাপয়েন্টমেন্ট বুকিং</span>
                </button>
                {isMasterAuthenticated && (
                  <>
                    <button
                      onClick={() => {
                        setCurrentView('wp-admin');
                        setAdminSubTab('prescriptions');
                        setIsNewMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-[#2271b1] flex items-center space-x-2"
                    >
                      <FileText className="w-3.5 h-3.5 text-emerald-400" />
                      <span>প্রেসক্রিপশন তৈরি</span>
                    </button>
                    <button
                      onClick={() => {
                        setCurrentView('wp-admin');
                        setAdminSubTab('patients');
                        setIsNewMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-[#2271b1] flex items-center space-x-2"
                    >
                      <UserPlus className="w-3.5 h-3.5 text-amber-400" />
                      <span>নতুন রোগী নিবন্ধন</span>
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Section: Sync Status, Search, Dark Mode, Profile */}
        <div className="flex items-center space-x-1 sm:space-x-2.5">
          
          {/* Sync & Online / Offline Badge */}
          <button
            onClick={triggerManualSync}
            title={isOnline ? 'অনলাইন মোড সক্রিয় (ক্লিক করে সিঙ্ক করুন)' : 'অফলাইন মোড সক্রিয় (ডাটা লোকাল স্টোরেজে জমা হচ্ছে)'}
            className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[11px] transition ${
              isOnline
                ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800 hover:bg-emerald-900/80'
                : 'bg-amber-950/70 text-amber-300 border border-amber-800 hover:bg-amber-900/80'
            }`}
          >
            {isSyncing ? (
              <RefreshCw className="w-3 h-3 animate-spin text-sky-300" />
            ) : isOnline ? (
              <Wifi className="w-3 h-3 text-emerald-400" />
            ) : (
              <WifiOff className="w-3 h-3 text-amber-400" />
            )}
            <span className="hidden sm:inline font-mono">
              {isSyncing ? 'সিঙ্ক হচ্ছে...' : isOnline ? 'অনলাইন' : 'অফলাইন'}
            </span>
            {syncQueue.length > 0 && (
              <span className="bg-amber-500 text-black px-1 rounded-full text-[9px] font-bold">
                {syncQueue.length}
              </span>
            )}
          </button>

          {/* Global Quick Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="flex items-center space-x-1 px-2 py-1 rounded hover:bg-[#2271b1] hover:text-white transition text-gray-300"
            title="সার্চ করুন (Ctrl + K)"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">সার্চ</span>
            <kbd className="hidden lg:inline text-[9px] bg-black/40 px-1 py-0.5 rounded text-gray-400 border border-gray-700">
              Ctrl K
            </kbd>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-1.5 rounded hover:bg-[#2271b1] hover:text-white text-gray-300 transition"
            title={isDarkMode ? 'লাইট মোড করুন' : 'ডার্ক মোড করুন'}
          >
            {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5 text-indigo-300" />}
          </button>

          {/* User Profile / Master Security Access */}
          <div className="relative">
            {isMasterAuthenticated ? (
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                onBlur={() => setTimeout(() => setIsUserMenuOpen(false), 200)}
                className="flex items-center space-x-1.5 px-2 py-1 rounded bg-[#2c3338] hover:bg-[#2271b1] text-white transition"
              >
                <div className="w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-[10px] font-bold text-white">
                  ✓
                </div>
                <span className="font-semibold text-[11px] truncate max-w-[120px]">{adminProfile.name || 'এডমিন'}</span>
              </button>
            ) : (
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="flex items-center space-x-1 px-2.5 py-1 rounded bg-[#2271b1] hover:bg-[#135e96] text-white font-medium transition text-[11px]"
              >
                <Lock className="w-3 h-3 text-white" />
                <span>ওয়ার্ডপ্রেস লগইন</span>
              </button>
            )}

            {isUserMenuOpen && isMasterAuthenticated && (
              <div className="absolute right-0 mt-1 w-56 bg-[#2c3338] text-white rounded shadow-xl py-1 z-50 border border-gray-700 text-xs">
                <div className="px-3 py-2 border-b border-gray-700 flex items-center space-x-2.5">
                  <img
                    src={adminProfile.avatarUrl || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80'}
                    alt="Admin"
                    className="w-8 h-8 rounded-full object-cover border border-emerald-400"
                  />
                  <div className="overflow-hidden">
                    <div className="font-semibold text-white truncate">{adminProfile.name}</div>
                    <div className="text-[10px] text-gray-400 truncate">@{adminProfile.username}</div>
                    <div className="text-[10px] text-emerald-400 flex items-center space-x-1">
                      <ShieldCheck className="w-3 h-3 shrink-0" />
                      <span>{adminProfile.role || 'সুপার অ্যাডমিন'}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setCurrentView('wp-admin');
                    setAdminSubTab('dashboard');
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-[#2271b1] flex items-center space-x-2"
                >
                  <LayoutDashboard className="w-3.5 h-3.5 text-sky-400" />
                  <span>এডমিন কন্ট্রোল প্যানেল</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentView('wp-admin');
                    setAdminSubTab('admin-settings');
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-[#2271b1] flex items-center space-x-2 text-amber-300 font-medium bg-amber-950/20"
                >
                  <UserCog className="w-3.5 h-3.5 text-amber-400" />
                  <span>অ্যাডমিন অ্যাকাউন্ট সেটিংস (Edit Profile)</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentView('wp-admin');
                    setAdminSubTab('mobile-apk');
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-[#2271b1] flex items-center space-x-2"
                >
                  <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                  <span>মোবাইল অ্যাপ ও APK</span>
                </button>

                <button
                  onClick={() => {
                    logoutMaster();
                    setIsUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-rose-300 hover:bg-rose-950/80 flex items-center space-x-2 border-t border-gray-700"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>লগআউট করুন</span>
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
