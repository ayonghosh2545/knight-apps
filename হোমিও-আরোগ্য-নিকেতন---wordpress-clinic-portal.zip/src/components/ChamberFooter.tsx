import React, { useState } from 'react';
import { useClinic } from '../context/ClinicContext.tsx';
import { FooterQuickLink } from '../types.ts';
import {
  HeartPulse,
  MapPin,
  Phone,
  Clock,
  Mail,
  Shield,
  Download,
  Calendar,
  FileSearch,
  Wifi,
  WifiOff,
  Globe,
  Edit3,
  X,
  Check,
  Plus,
  Trash2,
  ExternalLink,
  BookOpen,
  ChevronRight,
  Sliders,
  Sparkles
} from 'lucide-react';

export const ChamberFooter: React.FC = () => {
  const {
    settings,
    updateChamberSettings,
    isOnline,
    isMasterAuthenticated,
    setIsBookingModalOpen,
    setIsPrescriptionLookupOpen,
    setIsLoginModalOpen,
    setCurrentView
  } = useClinic();

  const [isFooterEditOpen, setIsFooterEditOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'general' | 'contact' | 'links' | 'app' | 'bottom'>('general');

  // Default Quick Links fallback
  const defaultQuickLinks: FooterQuickLink[] = [
    { id: 'f-link-1', label: 'অনলাইন অ্যাপয়েন্টমেন্ট বুকিং', actionType: 'booking', enabled: true },
    { id: 'f-link-2', label: 'প্রেসক্রিপশন ও ওষুধের ইতিহাস অনুসন্ধান', actionType: 'lookup', enabled: true },
    { id: 'f-link-3', label: 'ডাক্তারদের প্রোফাইল ও সময়সূচী', actionType: 'doctors', url: '#doctors', enabled: true },
    { id: 'f-link-4', label: 'হোমিও মেটেরিয়া মেডিকা হ্যান্ডবুক', actionType: 'materia-medica', url: '#materia-medica', enabled: true }
  ];

  // Footer Options State
  const [footerFormData, setFooterFormData] = useState({
    chamberName: settings.chamberName,
    footerBio: settings.footerBio || 'ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।',
    footerContactHeading: settings.footerContactHeading || 'যোগাযোগ ও চেম্বার ঠিকানা',
    address: settings.address,
    city: settings.city,
    phone: settings.phone,
    emergencyPhone: settings.emergencyPhone,
    email: settings.email,
    visitingHours: settings.visitingHours,
    footerQuickLinksHeading: settings.footerQuickLinksHeading || 'রোগী সেবা ও পোর্টাল',
    footerQuickLinks: (settings.footerQuickLinks && settings.footerQuickLinks.length > 0)
      ? settings.footerQuickLinks
      : defaultQuickLinks,
    footerAppHeading: settings.footerAppHeading || 'মোবাইল অ্যাপ ও ডাউনলোড',
    footerAppDesc: settings.footerAppDesc || 'এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন অথবা বিল্ড ফোল্ডার থেকে APK ডাউনলোড করুন।',
    footerAppBtnText: settings.footerAppBtnText || 'ডাউনলোড APK (v1.0.4)',
    copyrightText: settings.copyrightText || `${settings.chamberName} — সর্বস্বত্ব সংরক্ষিত।`,
    footerBottomTagline: settings.footerBottomTagline || 'অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ',
    footerBottomBadge: settings.footerBottomBadge || 'WordPress 6.7 & HomeoPress Theme'
  });

  // State for new quick link input
  const [newLinkLabel, setNewLinkLabel] = useState('');
  const [newLinkType, setNewLinkType] = useState<FooterQuickLink['actionType']>('custom');
  const [newLinkUrl, setNewLinkUrl] = useState('');

  const handleOpenFooterEdit = (tab: 'general' | 'contact' | 'links' | 'app' | 'bottom' = 'general') => {
    setActiveTab(tab);
    setFooterFormData({
      chamberName: settings.chamberName,
      footerBio: settings.footerBio || 'ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।',
      footerContactHeading: settings.footerContactHeading || 'যোগাযোগ ও চেম্বার ঠিকানা',
      address: settings.address,
      city: settings.city,
      phone: settings.phone,
      emergencyPhone: settings.emergencyPhone,
      email: settings.email,
      visitingHours: settings.visitingHours,
      footerQuickLinksHeading: settings.footerQuickLinksHeading || 'রোগী সেবা ও পোর্টাল',
      footerQuickLinks: (settings.footerQuickLinks && settings.footerQuickLinks.length > 0)
        ? settings.footerQuickLinks
        : defaultQuickLinks,
      footerAppHeading: settings.footerAppHeading || 'মোবাইল অ্যাপ ও ডাউনলোড',
      footerAppDesc: settings.footerAppDesc || 'এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন অথবা বিল্ড ফোল্ডার থেকে APK ডাউনলোড করুন।',
      footerAppBtnText: settings.footerAppBtnText || 'ডাউনলোড APK (v1.0.4)',
      copyrightText: settings.copyrightText || `${settings.chamberName} — সর্বস্বত্ব সংরক্ষিত।`,
      footerBottomTagline: settings.footerBottomTagline || 'অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ',
      footerBottomBadge: settings.footerBottomBadge || 'WordPress 6.7 & HomeoPress Theme'
    });
    setIsFooterEditOpen(true);
  };

  const handleSaveFooter = (e: React.FormEvent) => {
    e.preventDefault();
    updateChamberSettings({
      chamberName: footerFormData.chamberName.trim() || settings.chamberName,
      footerBio: footerFormData.footerBio.trim(),
      footerContactHeading: footerFormData.footerContactHeading.trim() || 'যোগাযোগ ও চেম্বার ঠিকানা',
      address: footerFormData.address.trim(),
      city: footerFormData.city.trim(),
      phone: footerFormData.phone.trim(),
      emergencyPhone: footerFormData.emergencyPhone.trim(),
      email: footerFormData.email.trim(),
      visitingHours: footerFormData.visitingHours.trim(),
      footerQuickLinksHeading: footerFormData.footerQuickLinksHeading.trim() || 'রোগী সেবা ও পোর্টাল',
      footerQuickLinks: footerFormData.footerQuickLinks,
      footerAppHeading: footerFormData.footerAppHeading.trim() || 'মোবাইল অ্যাপ ও ডাউনলোড',
      footerAppDesc: footerFormData.footerAppDesc.trim(),
      footerAppBtnText: footerFormData.footerAppBtnText.trim() || 'ডাউনলোড APK (v1.0.4)',
      copyrightText: footerFormData.copyrightText.trim(),
      footerBottomTagline: footerFormData.footerBottomTagline.trim(),
      footerBottomBadge: footerFormData.footerBottomBadge.trim()
    });
    setIsFooterEditOpen(false);
  };

  const handleDownloadApk = () => {
    window.location.href = '/api/download-apk';
  };

  const handleLinkClick = (link: FooterQuickLink) => {
    if (link.actionType === 'booking') {
      setIsBookingModalOpen(true);
    } else if (link.actionType === 'lookup') {
      setIsPrescriptionLookupOpen(true);
    } else if (link.actionType === 'doctors') {
      const el = document.getElementById('doctors');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (link.actionType === 'materia-medica') {
      const el = document.getElementById('materia-medica');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (link.url) {
      if (link.url.startsWith('#')) {
        const target = document.querySelector(link.url);
        if (target) target.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.open(link.url, '_blank');
      }
    }
  };

  // Helper to add new quick link
  const handleAddLink = () => {
    if (!newLinkLabel.trim()) return;
    const newLink: FooterQuickLink = {
      id: 'f-link-' + Date.now(),
      label: newLinkLabel.trim(),
      actionType: newLinkType,
      url: newLinkUrl.trim() || (newLinkType === 'doctors' ? '#doctors' : newLinkType === 'materia-medica' ? '#materia-medica' : '#'),
      enabled: true
    };
    setFooterFormData((prev) => ({
      ...prev,
      footerQuickLinks: [...prev.footerQuickLinks, newLink]
    }));
    setNewLinkLabel('');
    setNewLinkUrl('');
  };

  const handleRemoveLink = (id: string) => {
    setFooterFormData((prev) => ({
      ...prev,
      footerQuickLinks: prev.footerQuickLinks.filter((l) => l.id !== id)
    }));
  };

  const handleToggleLink = (id: string) => {
    setFooterFormData((prev) => ({
      ...prev,
      footerQuickLinks: prev.footerQuickLinks.map((l) => (l.id === id ? { ...l, enabled: !l.enabled } : l))
    }));
  };

  const handleUpdateLinkLabel = (id: string, label: string) => {
    setFooterFormData((prev) => ({
      ...prev,
      footerQuickLinks: prev.footerQuickLinks.map((l) => (l.id === id ? { ...l, label } : l))
    }));
  };

  const displayQuickLinks = (settings.footerQuickLinks && settings.footerQuickLinks.length > 0)
    ? settings.footerQuickLinks
    : defaultQuickLinks;

  return (
    <footer className="bg-[#1d2327] text-[#c3c4c7] text-xs border-t border-[#2c3338] transition-colors relative">
      
      {/* Admin Quick Edit Bar (When Logged In) */}
      {isMasterAuthenticated && (
        <div className="bg-[#15191c] border-b border-emerald-900/50 py-2 px-4 shadow-inner">
          <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2 text-[11px]">
            <span className="text-emerald-400 flex items-center space-x-1.5 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>এডমিন মুড সক্রিয়: ফুটারের কলাম শিরোনাম, লিংক অপশন, পরিচিতি ও বটম বার এডিট করতে পারেন</span>
            </span>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleOpenFooterEdit('links')}
                className="px-2.5 py-1 bg-gray-800 hover:bg-gray-700 text-emerald-300 font-semibold rounded-md border border-gray-700 transition"
              >
                লিংক অপশন এডিট
              </button>
              <button
                onClick={() => handleOpenFooterEdit('general')}
                className="inline-flex items-center space-x-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-md transition shadow-xs"
              >
                <Sliders className="w-3 h-3" />
                <span>ফুটার অপশনসমূহ সম্পাদনা</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Column 1: Chamber Bio */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2.5 text-white">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center shadow-md">
                <HeartPulse className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-white tracking-tight flex items-center gap-1.5">
                  {settings.chamberName}
                  {isMasterAuthenticated && (
                    <button
                      onClick={() => handleOpenFooterEdit('general')}
                      className="p-1 text-gray-500 hover:text-emerald-400 transition rounded"
                      title="চেম্বার পরিচিতি ও নাম এডিট করুন"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </h4>
                <div className="text-[10px] text-emerald-400 font-medium">
                  HomeoCare Research Center
                </div>
              </div>
            </div>

            <p className="text-gray-400 leading-relaxed text-xs">
              {settings.footerBio || `${settings.tagline}। ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।`}
            </p>

            <div className="flex items-center space-x-2 pt-1">
              <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-mono ${
                isOnline ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'
              }`}>
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                <span>{isOnline ? 'অনলাইন সার্ভার সক্রিয়' : 'অফলাইন লোকাল ডাটাবেস সক্রিয়'}</span>
              </span>
            </div>
          </div>

          {/* Column 2: Chamber Address & Contact */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-gray-700 pb-2">
              <h5 className="font-bold text-white text-sm uppercase tracking-wider">
                {settings.footerContactHeading || 'যোগাযোগ ও চেম্বার ঠিকানা'}
              </h5>
              {isMasterAuthenticated && (
                <button
                  onClick={() => handleOpenFooterEdit('contact')}
                  className="text-[11px] text-emerald-400 hover:underline flex items-center space-x-1"
                  title="যোগাযোগ ও ঠিকানা অপশন এডিট করুন"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>এডিট</span>
                </button>
              )}
            </div>
            <ul className="space-y-2.5 text-gray-400">
              <li className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>চেম্বার ফোন: {settings.phone}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>জরুরি হটলাইন: {settings.emergencyPhone}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                <span>ইমেইল: {settings.email}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-teal-400 shrink-0" />
                <span>{settings.visitingHours}</span>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Links & Patient Portal Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-gray-700 pb-2">
              <h5 className="font-bold text-white text-sm uppercase tracking-wider">
                {settings.footerQuickLinksHeading || 'রোগী সেবা ও পোর্টাল'}
              </h5>
              {isMasterAuthenticated && (
                <button
                  onClick={() => handleOpenFooterEdit('links')}
                  className="text-[11px] text-emerald-400 hover:underline flex items-center space-x-1"
                  title="ফুটার মেনু লিংকসমূহ এডিট করুন"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>লিংক এডিট</span>
                </button>
              )}
            </div>
            <ul className="space-y-2 text-gray-400">
              {displayQuickLinks.filter((link) => link.enabled !== false).map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => handleLinkClick(link)}
                    className="hover:text-emerald-400 transition flex items-center space-x-1.5 text-left text-xs"
                  >
                    {link.actionType === 'booking' && <Calendar className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
                    {link.actionType === 'lookup' && <FileSearch className="w-3.5 h-3.5 text-teal-500 shrink-0" />}
                    {link.actionType === 'doctors' && <ChevronRight className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                    {link.actionType === 'materia-medica' && <BookOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    {link.actionType === 'custom' && <ExternalLink className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Mobile App & Download Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-gray-700 pb-2">
              <h5 className="font-bold text-white text-sm uppercase tracking-wider">
                {settings.footerAppHeading || 'মোবাইল অ্যাপ ও ডাউনলোড'}
              </h5>
              {isMasterAuthenticated && (
                <button
                  onClick={() => handleOpenFooterEdit('app')}
                  className="text-[11px] text-emerald-400 hover:underline flex items-center space-x-1"
                  title="মোবাইল অ্যাপ সেকশন এডিট করুন"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>এডিট</span>
                </button>
              )}
            </div>
            <p className="text-gray-400 text-xs">
              {settings.footerAppDesc || 'এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন অথবা বিল্ড ফোল্ডার থেকে APK ডাউনলোড করুন।'}
            </p>

            <button
              onClick={handleDownloadApk}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl shadow transition flex items-center justify-center space-x-2 text-xs"
            >
              <Download className="w-4 h-4" />
              <span>{settings.footerAppBtnText || 'ডাউনলোড APK (v1.0.4)'}</span>
            </button>

            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => {
                  if (isMasterAuthenticated) {
                    setCurrentView('wp-admin');
                  } else {
                    setIsLoginModalOpen(true);
                  }
                }}
                className="inline-flex items-center space-x-1.5 text-gray-500 hover:text-gray-300 transition text-[11px]"
              >
                <Shield className="w-3.5 h-3.5 text-gray-400" />
                <span>{isMasterAuthenticated ? 'ওয়ার্ডপ্রেস এডমিন ড্যাশবোর্ড' : 'ওয়ার্ডপ্রেস এডমিন লগইন'}</span>
              </button>

              {isMasterAuthenticated && (
                <button
                  onClick={() => handleOpenFooterEdit('general')}
                  className="inline-flex items-center space-x-1 text-emerald-400 hover:text-emerald-300 transition text-[11px]"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>ফুটার এডিট</span>
                </button>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Sub-footer */}
      <div className="bg-[#15191c] py-4 px-4 border-t border-[#262c31] text-[11px] text-gray-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span>
              © {new Date().getFullYear()} {settings.copyrightText || `${settings.chamberName} — সর্বস্বত্ব সংরক্ষিত।`}
            </span>
            {isMasterAuthenticated && (
              <button
                onClick={() => handleOpenFooterEdit('bottom')}
                className="text-gray-500 hover:text-emerald-400"
                title="কপিরাইট ও ফুটার বার এডিট করুন"
              >
                <Edit3 className="w-3 h-3" />
              </button>
            )}
          </div>

          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <Globe className="w-3.5 h-3.5 text-[#2271b1]" />
              <span>{settings.footerBottomBadge || 'WordPress 6.7 & HomeoPress Theme'}</span>
            </span>
            <span>{settings.footerBottomTagline || 'অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ'}</span>
          </div>
        </div>
      </div>

      {/* Comprehensive Footer & Options Edit Modal (When Admin is Logged In) */}
      {isFooterEditOpen && isMasterAuthenticated && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-[#1a2024] rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-200 dark:border-gray-800 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150 text-gray-900 dark:text-white">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 rounded-lg text-emerald-600 dark:text-emerald-400">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">
                    ফুটার অপশন ও তথ্য সম্পাদনা (Footer Settings & Options)
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    ফুটারের সকল কলাম, শিরোনাম, কুইক লিংক, মোবাইল অ্যাপ ও বটম বার নিয়ন্ত্রণ করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsFooterEditOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex items-center space-x-1.5 border-b border-gray-200 dark:border-gray-800 pt-3 pb-2 overflow-x-auto text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('general')}
                className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                  activeTab === 'general'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                ১. সাধারণ ও পরিচিতি
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('contact')}
                className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                  activeTab === 'contact'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                ২. যোগাযোগ ঠিকানা
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('links')}
                className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                  activeTab === 'links'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                ৩. কুইক লিংক অপশন
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('app')}
                className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                  activeTab === 'app'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                ৪. মোবাইল অ্যাপ অপশন
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('bottom')}
                className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap ${
                  activeTab === 'bottom'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                ৫. কপিরাইট ও বটম বার
              </button>
            </div>

            <form onSubmit={handleSaveFooter} className="mt-4 space-y-4">
              
              {/* TAB 1: General & Bio */}
              {activeTab === 'general' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      চেম্বারের নাম *
                    </label>
                    <input
                      type="text"
                      required
                      value={footerFormData.chamberName}
                      onChange={(e) => setFooterFormData({ ...footerFormData, chamberName: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      ফুটার পরিচিতি / সংক্ষিপ্ত বিবরণ (Footer Bio)
                    </label>
                    <textarea
                      rows={3}
                      value={footerFormData.footerBio}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerBio: e.target.value })}
                      placeholder="যেমন: ক্লাসিকাল হোমিওপ্যাথির মাধ্যমে দীর্ঘমেয়াদী এবং জটিল রোগের পার্শ্বপ্রতিক্রিয়াহীন প্রাকৃতিক আরোগ্য বিধান।"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                    />
                  </div>
                </div>
              )}

              {/* TAB 2: Contact Options */}
              {activeTab === 'contact' && (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      কলাম ২ শিরোনাম (Contact Column Heading)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerContactHeading}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerContactHeading: e.target.value })}
                      placeholder="যোগাযোগ ও চেম্বার ঠিকানা"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের ঠিকানা
                      </label>
                      <input
                        type="text"
                        value={footerFormData.address}
                        onChange={(e) => setFooterFormData({ ...footerFormData, address: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        শহর
                      </label>
                      <input
                        type="text"
                        value={footerFormData.city}
                        onChange={(e) => setFooterFormData({ ...footerFormData, city: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের সাধারণ ফোন
                      </label>
                      <input
                        type="text"
                        value={footerFormData.phone}
                        onChange={(e) => setFooterFormData({ ...footerFormData, phone: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        জরুরি হটলাইন নম্বর
                      </label>
                      <input
                        type="text"
                        value={footerFormData.emergencyPhone}
                        onChange={(e) => setFooterFormData({ ...footerFormData, emergencyPhone: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        চেম্বারের ইমেইল
                      </label>
                      <input
                        type="email"
                        value={footerFormData.email}
                        onChange={(e) => setFooterFormData({ ...footerFormData, email: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        সাক্ষাতের সময়সূচী
                      </label>
                      <input
                        type="text"
                        value={footerFormData.visitingHours}
                        onChange={(e) => setFooterFormData({ ...footerFormData, visitingHours: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: Quick Links & Menu Options */}
              {activeTab === 'links' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      কলাম ৩ শিরোনাম (Quick Links Column Heading)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerQuickLinksHeading}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerQuickLinksHeading: e.target.value })}
                      placeholder="রোগী সেবা ও পোর্টাল"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  {/* Existing Links List */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                      বর্তমান লিংক অপশনসমূহ (নাম এডিট বা সক্রিয়/নিষ্ক্রিয় করুন):
                    </label>
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {footerFormData.footerQuickLinks.map((link, idx) => (
                        <div
                          key={link.id}
                          className="flex items-center space-x-2 bg-gray-50 dark:bg-gray-900 p-2 rounded-lg border border-gray-200 dark:border-gray-800 text-xs"
                        >
                          <span className="font-mono text-gray-400 text-[11px] w-5">
                            {idx + 1}.
                          </span>
                          <input
                            type="text"
                            value={link.label}
                            onChange={(e) => handleUpdateLinkLabel(link.id, e.target.value)}
                            className="flex-1 px-2.5 py-1 text-xs rounded border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800"
                          />
                          <button
                            type="button"
                            onClick={() => handleToggleLink(link.id)}
                            className={`px-2 py-1 rounded text-[10px] font-bold transition ${
                              link.enabled !== false
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-gray-200 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                            }`}
                          >
                            {link.enabled !== false ? 'সক্রিয়' : 'বন্ধ'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveLink(link.id)}
                            className="p-1 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/50 rounded"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Add New Link Box */}
                  <div className="bg-emerald-50/70 dark:bg-emerald-950/20 p-3 rounded-xl border border-emerald-200 dark:border-emerald-800 space-y-2">
                    <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 block">
                      + নতুন ফুটার মেনু লিংক যোগ করুন:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={newLinkLabel}
                        onChange={(e) => setNewLinkLabel(e.target.value)}
                        placeholder="লিংকের শিরোনাম / নাম"
                        className="px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-gray-900"
                      />
                      <select
                        value={newLinkType}
                        onChange={(e) => setNewLinkType(e.target.value as any)}
                        className="px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200"
                      >
                        <option value="custom">কাস্টম লিংক (Custom URL)</option>
                        <option value="booking">অ্যাপয়েন্টমেন্ট বুকিং মডাল</option>
                        <option value="lookup">প্রেসক্রিপশন চেক মডাল</option>
                        <option value="doctors">ডাক্তারদের প্রোফাইল (#doctors)</option>
                        <option value="materia-medica">হোমিও নির্দেশিকা (#materia-medica)</option>
                      </select>
                      <button
                        type="button"
                        onClick={handleAddLink}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center justify-center space-x-1 transition shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>লিংক যুক্ত করুন</span>
                      </button>
                    </div>
                    {newLinkType === 'custom' && (
                      <input
                        type="text"
                        value={newLinkUrl}
                        onChange={(e) => setNewLinkUrl(e.target.value)}
                        placeholder="URL বা সেকশন আইডি (যেমন: https://example.com বা #hero)"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-gray-900"
                      />
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: Mobile App Options */}
              {activeTab === 'app' && (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      কলাম ৪ শিরোনাম (App Column Heading)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerAppHeading}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerAppHeading: e.target.value })}
                      placeholder="মোবাইল অ্যাপ ও ডাউনলোড"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      অ্যাপ সেকশনের বিবরণ (App Description Text)
                    </label>
                    <textarea
                      rows={2}
                      value={footerFormData.footerAppDesc}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerAppDesc: e.target.value })}
                      placeholder="এক ক্লিকে আপনার অ্যান্ড্রয়েড ফোনে অ্যাপ ইনস্টল করুন অথবা বিল্ড ফোল্ডার থেকে APK ডাউনলোড করুন।"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      ডাউনলোড বাটন টেক্সট (Button Label)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerAppBtnText}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerAppBtnText: e.target.value })}
                      placeholder="ডাউনলোড APK (v1.0.4)"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                </div>
              )}

              {/* TAB 5: Bottom Bar Options */}
              {activeTab === 'bottom' && (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      কপিরাইট নোটিশ (Copyright Notice Text)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.copyrightText}
                      onChange={(e) => setFooterFormData({ ...footerFormData, copyrightText: e.target.value })}
                      placeholder="যেমন: হোমিও আরোগ্য নিকেতন ও রিসার্চ সেন্টার — সর্বস্বত্ব সংরক্ষিত।"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      বটম বার থিম / প্ল্যাটফর্ম ট্যাগ (Bottom Badge)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerBottomBadge}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerBottomBadge: e.target.value })}
                      placeholder="WordPress 6.7 & HomeoPress Theme"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      বটম বার সাব-ট্যাগলাইন (Bottom Tagline)
                    </label>
                    <input
                      type="text"
                      value={footerFormData.footerBottomTagline}
                      onChange={(e) => setFooterFormData({ ...footerFormData, footerBottomTagline: e.target.value })}
                      placeholder="অফলাইন লোকাল স্টোরেজ ও ক্লাউড সিঙ্ক সমৃদ্ধ"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Form Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-800">
                <span className="text-[11px] text-gray-400">
                  সংরক্ষণ করলে ওয়েবসাইটে তাৎক্ষণিক কার্যকর হবে
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsFooterEditOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition flex items-center space-x-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>ফুটার অপশনসমূহ সংরক্ষণ করুন</span>
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

    </footer>
  );
};
