import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'HomeoCare Clinic Server', timestamp: new Date().toISOString() });
});

// APK Download Route
app.get('/api/download-apk', (req, res) => {
  const candidatePaths = [
    path.resolve(process.cwd(), 'public/build/HomeoCare-Chamber.apk'),
    path.resolve(process.cwd(), 'build/HomeoCare-Chamber.apk'),
    path.resolve(process.cwd(), 'public/build/HomeoCare-Chamber-AYON540.apk'),
    path.resolve(process.cwd(), 'build/HomeoCare-Chamber-AYON540.apk')
  ];

  const fileToServe = candidatePaths.find(p => fs.existsSync(p));

  if (fileToServe) {
    res.setHeader('Content-Disposition', 'attachment; filename="HomeoCare-Chamber.apk"');
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    fs.createReadStream(fileToServe).pipe(res);
  } else {
    res.status(404).json({ error: 'APK file not found in build directory' });
  }
});

// Emergency Homeopathic Consultation Chatbot API
app.post('/api/chat', async (req, res) => {
  const { message, history } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  const apiKey = process.env.GEMINI_API_KEY;

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `You are a qualified senior classical Homeopathic Consultant for 'হোমিও আরোগ্য নিকেতন' (HomeoCare Clinic).
A patient or visitor is asking an emergency consultation or health symptom question in Bengali or English:
"${message}"

Instructions:
1. Reply warmly in fluent, compassionate Bengali (বাংলা).
2. Ask about main symptoms, modalities (what makes it better or worse), onset (sudden or gradual), and mental state if relevant.
3. Suggest 1 or 2 classical homeopathic remedies often indicated in Materia Medica (e.g. Arnica 200 for trauma, Aconite 30 for sudden fever/chill, Nux Vomica 30 for indigestion/gastric trouble, Belladonna 30 for high burning fever, Arsenic Alb 30 for food poisoning/burning thirst, Bryonia 30, Rhus Tox 200, etc.) with standard dilution potencies and directions.
4. Always provide an explicit Medical Disclaimer: এটি প্রাথমিক হোমিওপ্যাথিক পথনির্দেশ। সংকটজনক বা তীব্র লক্ষণে অবিলম্বে চেম্বারে ডাক্তার দেখান বা জরুরি চিকিৎসালয়ে যোগাযোগ করুন।
5. Keep it concise, structured, and easy to read on mobile.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      return res.json({ reply: response.text });
    } catch (err: any) {
      console.warn('Gemini API call failed, falling back to local Materia Medica engine:', err?.message);
    }
  }

  // Built-in intelligent Materia Medica emergency rule-based fallback
  const query = message.toLowerCase();
  let reply = '';

  if (query.includes('জ্বর') || query.includes('fever') || query.includes('গরম')) {
    reply = `🌿 **হোমিও প্রাথমিক পরামর্শ (জ্বর / Fever):**\n\n• **Aconite Napellus 30CH**: যদি ঠান্ডা বাতাসে হঠাৎ উচ্চ জ্বর, শুষ্ক ত্বক ও তীব্র অস্থিরতা থাকে, তবে শুরুতে ২ ফোঁটা করে দিনে ৩ বার পানির সাথে।\n• **Belladonna 30CH**: যদি মুখমণ্ডল লাল হয়ে দপদপ করা মাথাব্যথা ও প্রচণ্ড উত্তাপ থাকে।\n\n⚠️ **সতর্কতা:** রোগীর তাপমাত্রা ১০৩°F এর বেশি হলে বা খিঁচুনি দেখা দিলে অবিলম্বে হাসপাতালে নিন। চেম্বারে ড. সুমন কুমারের সরাসরি অ্যাপয়েন্টমেন্ট বুক করুন।`;
  } else if (query.includes('গ্যাস') || query.includes('বদহজম') || query.includes('পেট') || query.includes('gastric') || query.includes('acidity')) {
    reply = `🌿 **হোমিও প্রাথমিক পরামর্শ (গ্যাসট্রিক ও এসিডিটি):**\n\n• **Nux Vomica 30CH**: ভারী বা মসলাযুক্ত খাবারের পর বুকজ্বালা, অম্ল ঢেকুর ও পেটভার হলে রাতে ঘুমানোর পূর্বে ২ ফোঁটা।\n• **Carbo Veg 30CH**: পেটের উপরিভাগে বায়ু জমে পেট ফাঁপা ও ক্রমাগত ঢেকুর ওঠা উপশমে কার্যকর।\n• **পথ্য ও নিয়ম:** কাঁচা পেঁয়াজ ও অতিরিক্ত চা-কফি পরিহার করুন, কুসুম গরম পানি পান করুন।`;
  } else if (query.includes('আঘাত') || query.includes('ব্যথা') || query.includes('injury') || query.includes('pain') || query.includes('পড়ে')) {
    reply = `🌿 **হোমিও প্রাথমিক পরামর্শ (আঘাত ও মাংসপেশির ব্যথা):**\n\n• **Arnica Montana 200CH**: যেকোনো ভোঁতা আঘাত, কালশিটে পড়া বা তীব্র শরীরের ব্যথায় দিনে ২ বার ৩ দিন।\n• **Rhus Toxicodendron 200CH**: পেশি টান, মচকানো বা প্রথম নড়াচড়ায় ব্যথা বৃদ্ধি পেলে।\n\n⚠️ হাড় ভাঙা বা গভীর রক্তপাত থাকলে তাৎক্ষণিক জরুরি ক্লিনিকে যান।`;
  } else if (query.includes('কাশি') || query.includes('শ্বাসকষ্ট') || query.includes('cough') || query.includes('cold')) {
    reply = `🌿 **হোমিও প্রাথমিক পরামর্শ (সর্দি, কাশি ও হাঁপানি):**\n\n• **Bryonia Alba 30CH**: শুষ্ক খসখসে কাশি, নড়াচড়া করলে কাশি বাড়ে এবং প্রচুর পানি পিপাসা থাকলে।\n• **Drosera Rotundifolia 30CH**: রাতে শুইলে ক্রমাগত দম বন্ধ করা খিঁচুনির মতো কাশি হলে।\n• **Justicia Adhatoda Q**: কফ তরল করে বের করতে দিনে ৩ বার ৫ ফোঁটা হালকা গরম পানিতে।`;
  } else {
    reply = `🌿 **হোমিও আরোগ্য নিকেতন কনসালটেশন:**\n\nআপনার লক্ষণটি বিস্তারিত পেয়েছি। হোমিওপ্যাথিক চিকিৎসায় ব্যক্তির সামগ্রিক লক্ষণ ও প্রকৃতি (Constitution) অনুযায়ী সঠিক ওষুধ ও পোটেন্সি নির্বাচন করা হয়।\n\n• প্রাথমিক স্বাস্থ্যবিধিতে প্রচুর বিশুদ্ধ পানি পান করুন এবং বিশ্রাম নিন।\n• সঠিক ও দীর্ঘস্থায়ী আরোগ্যের জন্য সরাসরি আমাদের অভিজ্ঞ হোমিওপ্যাথিক চিকিৎসকের শরণাপন্ন হতে নিচে "অনলাইন অ্যাপয়েন্টমেন্ট" বাটনে ক্লিক করুন অথবা চেম্বার হটলাইনে কল করুন।`;
  }

  return res.json({ reply });
});

// Cloud Sync Backup Mock / Receiver
app.post('/api/cloud-backup', (req, res) => {
  const { data, timestamp } = req.body;
  // In a production setup this connects to cloud storage. Here we confirm receipt and return signed snapshot token
  res.json({
    success: true,
    snapshotId: `SNAP-${Date.now()}`,
    savedAt: timestamp || new Date().toISOString(),
    status: 'Cloud vault encrypted & synchronized'
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HomeoCare WordPress Clinic server running on port ${PORT}`);
  });
}

startServer();
